from . import (
    annotations as annotations,
    constraints,
    categories,
    extra_salesforce,
    foreign_keys,
    overrides,
    types,
)


def from_tooling(fields, global_value_sets=None):
    """Legacy compatibility view; current reports project native metadata directly.

    Lake definitions belong in APMP and validation requirements belong in Ops.
    """
    import pandas as pd
    from salesforce.transforms.tooling import column, field_columns

    fields = field_columns(fields)
    target = pd.DataFrame(index=fields.index)
    target["name"] = column(
        fields, "EntityParticle.QualifiedApiName", "FieldDefinition.QualifiedApiName"
    )
    target["title"] = column(fields, "EntityParticle.Label", "FieldDefinition.Label")
    target = types.from_sf_to_dp(fields, target)
    target = categories.from_sf_to_dp(fields, target, global_value_sets)
    target = constraints.from_sf_to_dp(fields, target)
    target = foreign_keys.from_sf_to_dp(fields, target)
    target = extra_salesforce.from_sf_to_dp(fields, target)
    return overrides.update(target)

