from salesforce.transforms.tooling import column


def _values(values):
    if values is None:
        return None
    categories = []
    for item in values:
        value = item.get("valueName", item.get("fullName", item.get("value")))
        if value is not None:
            category = {"value": value}
            if item.get("label") is not None:
                category["label"] = item["label"]
            categories.append(category)
    return categories or None


def from_sf_to_dp(fields_df, target_df, global_value_sets=None):
    target_df = target_df.copy()
    catalogs = global_value_sets or {}

    def categories(value_set):
        if not isinstance(value_set, dict):
            return None
        definition = value_set.get("valueSetDefinition")
        if isinstance(definition, dict):
            return _values(definition.get("value"))
        name = value_set.get("valueSetName")
        metadata = catalogs.get(name)
        return _values(metadata.get("customValue")) if metadata else None

    target_df["categories"] = column(
        fields_df, "FieldDefinition.Metadata.valueSet"
    ).map(categories)
    return target_df
