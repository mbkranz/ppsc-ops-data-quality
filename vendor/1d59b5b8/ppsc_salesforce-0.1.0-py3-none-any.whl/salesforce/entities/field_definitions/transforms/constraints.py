import pandas as pd

from salesforce.transforms.tooling import column


def to_total_digits(fields_df, target_df):
    target_df = target_df.copy()
    digits = pd.to_numeric(
        column(fields_df, "EntityParticle.Digits", "FieldDefinition.Precision"),
        errors="coerce",
    ).astype("Int64")
    target_df["constraints.totalDigits"] = digits.where(target_df["type"].eq("integer"))
    return target_df


def to_fraction_digits(fields_df, target_df):
    target_df = target_df.copy()
    scale = pd.to_numeric(
        column(fields_df, "EntityParticle.Scale", "FieldDefinition.Scale"),
        errors="coerce",
    ).astype("Int64")
    target_df["constraints.fractionDigits"] = scale.where(
        target_df["type"].eq("number")
    )
    return target_df


def to_unique(fields_df, target_df):
    target_df = target_df.copy()
    target_df["constraints.unique"] = column(fields_df, "EntityParticle.IsUnique")
    return target_df


def to_required(fields_df, target_df):
    target_df = target_df.copy()
    target_df["constraints.required"] = column(
        fields_df, "EntityParticle.IsNillable", "FieldDefinition.IsNillable"
    ).map({True: False, False: True})
    return target_df


def to_max_length(fields_df, target_df):
    target_df = target_df.copy()
    target_df["constraints.maxLength"] = pd.to_numeric(
        column(fields_df, "EntityParticle.Length", "FieldDefinition.Length"),
        errors="coerce",
    ).astype("Int64")
    return target_df


def to_pattern(fields_df, target_df):
    target_df = target_df.copy()
    target_df["constraints.pattern"] = pd.Series(
        None, index=fields_df.index, dtype=object
    )
    autonumber = column(fields_df, "EntityParticle.IsAutonumber").eq(True)
    target_df.loc[autonumber, "constraints.pattern"] = r"^[A-Za-z0-9-]+$"
    is_id = column(fields_df, "EntityParticle.DataType").eq("id")
    prefix = column(fields_df, "EntityDefinition.KeyPrefix").astype("string")
    target_df.loc[is_id, "constraints.pattern"] = prefix + "[A-Za-z0-9]+"
    return target_df


def to_jsonschema(fields_df, target_df):
    target_df = target_df.copy()
    target_df["constraints.jsonschema"] = pd.Series(
        None, index=fields_df.index, dtype=object
    )
    components = fields_df.loc[column(fields_df, "EntityParticle.IsComponent").eq(True)]
    if components.empty:
        return target_df
    for (entity, parent), group in components.groupby([
        "EntityDefinition.QualifiedApiName",
        "FieldDefinition.QualifiedApiName",
    ]):
        key = f"{entity}.{parent}"
        if key in target_df.index:
            target_df.at[key, "constraints.jsonschema"] = {
                "type": "object",
                "properties": {
                    target_df.at[index, "name"]: {"type": target_df.at[index, "type"]}
                    for index in group.index
                },
            }
    return target_df


def from_sf_to_dp(fields_df, target_df):
    for transform in (
        to_total_digits,
        to_fraction_digits,
        to_unique,
        to_required,
        to_pattern,
        to_max_length,
        to_jsonschema,
    ):
        target_df = transform(fields_df, target_df)
    return target_df
