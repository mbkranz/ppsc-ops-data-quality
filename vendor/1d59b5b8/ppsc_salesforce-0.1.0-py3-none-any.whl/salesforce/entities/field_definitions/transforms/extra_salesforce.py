from salesforce.transforms.tooling import column

salesforce_specific_field_mappings = {
    "salesforce.objectName": ("EntityDefinition.QualifiedApiName",),
    "salesforce.relationshipName": (
        "EntityParticle.RelationshipName",
        "FieldDefinition.RelationshipName",
    ),
    "salesforce.durableId": ("EntityParticle.DurableId",),
    "salesforce.soapType": (),
    "salesforce.extraTypeInfo": (
        "EntityParticle.ExtraTypeInfo",
        "FieldDefinition.ExtraTypeInfo",
    ),
    "salesforce.isCompound": ("EntityParticle.IsCompound",),
    "salesforce.dataType": ("FieldDefinition.DataType",),
    "salesforce.description": (
        "FieldDefinition.Description",
        "FieldDefinition.Metadata.description",
    ),
    "salesforce.calculatedFormula": ("FieldDefinition.Metadata.formula",),
    "salesforce.defaultValueFormula": (
        "FieldDefinition.Metadata.defaultValueFormula",
        "EntityParticle.DefaultValueFormula",
    ),
    "salesforce.inlineHelpText": (
        "EntityParticle.InlineHelpText",
        "FieldDefinition.Metadata.inlineHelpText",
    ),
    "salesforce.permissionable": ("EntityParticle.IsPermissionable",),
    "salesforce.updateable": ("EntityParticle.IsUpdatable",),
    "salesforce.createable": ("EntityParticle.IsCreatable",),
    "salesforce.groupable": (
        "EntityParticle.IsApiGroupable",
        "FieldDefinition.IsApiGroupable",
    ),
    "salesforce.filterable": (
        "EntityParticle.IsApiFilterable",
        "FieldDefinition.IsApiFilterable",
    ),
    "salesforce.aggregatable": (),
    "salesforce.sortable": (
        "EntityParticle.IsApiSortable",
        "FieldDefinition.IsApiSortable",
    ),
    "salesforce.lastModifiedDate": ("FieldDefinition.LastModifiedDate",),
    "salesforce.lastModifiedBy.Id": ("FieldDefinition.LastModifiedById",),
    "salesforce.lastModifiedBy.Name": ("FieldDefinition.LastModifiedBy.Name",),
    "salesforce.keyPrefix": ("EntityDefinition.KeyPrefix",),
}


def from_sf_to_dp(fields_df, target_df):
    target_df = target_df.copy()
    for target, sources in salesforce_specific_field_mappings.items():
        target_df[target] = column(fields_df, *sources)
    target_df["salesforce.compoundFieldName"] = column(
        fields_df, "FieldDefinition.QualifiedApiName"
    ).where(column(fields_df, "EntityParticle.IsComponent").eq(True))
    target_df["pdm.source.apis"] = (
        "tooling/EntityDefinition,tooling/FieldDefinition,tooling/EntityParticle"
    )
    metadata = fields_df.filter(regex=r"^FieldDefinition\.Metadata\.")
    has_metadata = metadata.notna().any(axis=1)
    target_df.loc[has_metadata, "pdm.source.apis"] += (
        ",tooling/FieldDefinition.Metadata"
    )
    return target_df
