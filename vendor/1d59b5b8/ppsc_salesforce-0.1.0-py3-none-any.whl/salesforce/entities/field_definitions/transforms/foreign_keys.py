from salesforce.transforms.tooling import column


def from_sf_to_dp(fields_df, target_df):
    target_df = target_df.copy()

    def references(value):
        if not isinstance(value, dict):
            return None
        names = value.get("referenceTo")
        if names is None:
            return None
        return [{"resource": name, "fields": ["Id"]} for name in names] or None

    target_df["foreignKeys"] = column(
        fields_df, "EntityParticle.ReferenceTo", "FieldDefinition.ReferenceTo"
    ).map(references)
    return target_df
