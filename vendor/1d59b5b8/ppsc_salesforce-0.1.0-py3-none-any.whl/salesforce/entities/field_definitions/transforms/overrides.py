import pandas as pd


pid_pattern = {"constraints.pattern": r"^P\d+$", "constraints.maxLength": 10}
bid_pattern = {"constraints.pattern": r"^[T|A]\d+$", "constraints.maxLength": 10}
state_id_cats = {"categories":[
    {"value": 1, "label": "Alabama"},
    {"value": 2, "label": "Alaska"},
    {"value": 3, "label": "American Samoa"},
    {"value": 4, "label": "Arizona"},
    {"value": 5, "label": "Arkansas"},
    {"value": 6, "label": "California"},
    {"value": 7, "label": "Colorado"},
    {"value": 8, "label": "Connecticut"},
    {"value": 9, "label": "Delaware"},
    {"value": 10, "label": "District of Columbia"},
    {"value": 11, "label": "Federated Micronesia"},
    {"value": 12, "label": "Florida"},
    {"value": 13, "label": "Georgia"},
    {"value": 14, "label": "Guam"},
    {"value": 15, "label": "Hawaii"},
    {"value": 16, "label": "Idaho"},
    {"value": 17, "label": "Illinois"},
    {"value": 18, "label": "Indiana"},
    {"value": 19, "label": "Iowa"},
    {"value": 20, "label": "Kansas"},
    {"value": 21, "label": "Kentucky"},
    {"value": 22, "label": "Louisiana"},
    {"value": 23, "label": "Maine"},
    {"value": 24, "label": "Marshall Islands"},
    {"value": 25, "label": "Maryland"},
    {"value": 26, "label": "Massachusetts"},
    {"value": 27, "label": "Michigan"},
    {"value": 28, "label": "Minnesota"},
    {"value": 29, "label": "Mississippi"},
    {"value": 30, "label": "Missouri"},
    {"value": 31, "label": "Montana"},
    {"value": 32, "label": "Nebraska"},
    {"value": 33, "label": "Nevada"},
    {"value": 34, "label": "New Hampshire"},
    {"value": 35, "label": "New Jersey"},
    {"value": 36, "label": "New Mexico"},
    {"value": 37, "label": "New York"},
    {"value": 38, "label": "North Carolina"},
    {"value": 39, "label": "North Dakota"},
    {"value": 40, "label": "Northern Mariana Islands"},
    {"value": 41, "label": "Ohio"},
    {"value": 42, "label": "Oklahoma"},
    {"value": 43, "label": "Oregon"},
    {"value": 44, "label": "Palau"},
    {"value": 45, "label": "Pennsylvania"},
    {"value": 46, "label": "Puerto Rico"},
    {"value": 47, "label": "Rhode Island"},
    {"value": 48, "label": "South Carolina"},
    {"value": 49, "label": "South Dakota"},
    {"value": 50, "label": "Tennessee"},
    {"value": 51, "label": "Texas"},
    {"value": 52, "label": "Utah"},
    {"value": 53, "label": "Vermont"},
    {"value": 54, "label": "Virginia"},
    {"value": 55, "label": "US Virgin Islands"},
    {"value": 56, "label": "Washington"},
    {"value": 57, "label": "West Virginia"},
    {"value": 58, "label": "Wisconsin"},
    {"value": 59, "label": "Wyoming"},
]}
overrides = [
    {
        "match": {"column": "name", "value": "Participant_ID__c"},
        "updates": {
            "constraints.pattern": r"^P\d+$",
            "constraints.maxLength": 10
        }
    },
    {
        "match": {"column": "name", "value": "Legacy_Participant_ID__c"},
        "updates": {
            "constraints.pattern": r"^P\d+$",
            "constraints.maxLength": 10
        }
    },
    {
        "match": {"column": "name", "value": "BioBank_ID__c"},
        "updates": {
            "constraints.pattern": r"^[T|A]\d+$",
            "constraints.maxLength": 10
        }
    },
    {
        "match": {"column": "name", "value": "Legacy_BioBank_ID__c"},
        "updates": {
            "constraints.pattern": r"^[T|A]\d+$",
            "constraints.maxLength": 10
        }
    },
    {
        "match": {"column": "Field", "value": "Account.Primary_Residence__pc"},
        "updates": {
            "categories": state_id_cats["categories"]
        }
    },
    {
        "match": {"column": "Field", "value": "Account.Primary_Healthcare__pc"},
        "updates": {
            "categories": state_id_cats["categories"]
        }
    },
    {
        "match": {"column": "Field", "value": "Contact.Primary_Residence__c"},
        "updates": {
            "categories": state_id_cats["categories"]
        }
    },
    {
        "match": {"column": "Field", "value": "Contact.Primary_Healthcare__c"},
        "updates": {
            "categories": state_id_cats["categories"]
        }
    }
]


def update(target_df):
    target_df = target_df.copy()
    # Reapply overrides using the new structure
    for rule in overrides:
        col = rule["match"]["column"]
        val = rule["match"]["value"]

        if col == target_df.index.name:
            mask = target_df.index == val
        else:
            mask = target_df[col] == val

        for update_col, update_val in rule["updates"].items():
            loc_update = target_df.loc[mask, update_col]
            loc_update = pd.Series(
                [update_val] * len(loc_update), index=loc_update.index, dtype="object"
            )
    return target_df

