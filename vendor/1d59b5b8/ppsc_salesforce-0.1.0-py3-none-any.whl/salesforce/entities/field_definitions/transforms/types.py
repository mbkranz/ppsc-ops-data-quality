from salesforce.transforms.tooling import column

# Preserve the serialized API value: multi-select picklists are semicolon-delimited
# strings; compound locations are latitude/longitude objects, not GeoJSON.
sf_data_types_to_dp_type = {
    "boolean": "boolean",
    "string": "string",
    "reference": "string",
    "datetime": "datetime",
    "picklist": "string",
    "id": "string",
    "textarea": "string",
    "integer": "integer",
    "double": "number",
    "date": "date",
    "url": "string",
    "currency": "number",
    "complexvalue": "object",
    "phone": "string",
    "multipicklist": "string",
    "percent": "number",
    "email": "string",
    "address": "object",
    "json": "object",
    "time": "time",
    "base64": "string",
    "long": "integer",
    "anytype": "any",
    "int": "integer",
    "combobox": "string",
    "encryptedstring": "string",
    "location": "object",
}


def from_sf_to_dp(fields_df, target_df):
    target_df = target_df.copy()
    data_type = (
        column(fields_df, "EntityParticle.DataType").astype("string").str.lower()
    )
    target_df["type"] = data_type.map(sf_data_types_to_dp_type).fillna("any")
    target_df["default"] = column(fields_df, "FieldDefinition.Metadata.defaultValue")
    target_df["format"] = data_type.map({
        "phone": "phone",
        "email": "email",
        "url": "uri",
    })
    formats = {
        "date": "yyyy-MM-dd",
        "datetime": "yyyy-MM-ddTHH:mm:ss+000",
        "time": "HH:mm:ss.SSS+000",
    }
    for name, value in formats.items():
        target_df.loc[target_df["type"].eq(name), "format"] = value
    target_df["pandas.format"] = target_df["type"].map({
        "date": "%Y-%m-%d",
        "datetime": "%Y-%m-%dT%H:%M:%SZ",
        "time": "%H:%M:%SZ",
    })
    return target_df
