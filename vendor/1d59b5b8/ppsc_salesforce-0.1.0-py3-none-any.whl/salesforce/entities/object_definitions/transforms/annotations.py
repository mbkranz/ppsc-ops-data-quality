import pandas as pd
from salesforce.transforms.tooling import object_columns


# %%
class Condition:
    def __init__(self, name, condition, title=None, description=None):
        self.name = name
        self.title = title
        self.description = description
        self.condition = condition


class Note(Condition):
    def __init__(self, name, condition, description, title=None):
        super().__init__(name, condition, title, description)


original_core_objects = """Account
AccountContactRelation
Contact
Journey_Attribution_Log__c
Journey_Attribution_Milestone__c
OperatingHours
Participant_ID_Verification
Participant_Journey_Item__c
Postal_Code__c
Request_ID__c
Survey__c
Survey_Result__c
TimeSlot
User
WorkTypeGroup
Task
Event
ServiceAppointment
ServiceResource
WorkType
Compensation__c
Order
Participant_Data_Log__c
Physical_Measurement__c
Portal_Verification_Log__c
PersonAccount
Fitbit_Log__c
Assignment__c
Assignment_Activity__c
Case_Comment__c
Disposition__c
Disposition_Item__c
Sample_Status_Log__c""".split("\n")


def add_annotations(target_object_df, **source_dfs):
    target_object_df = target_object_df.copy()
    objects_df = object_columns(source_dfs["objects"])
    # fields_df = source_dfs["fields"]
    object_permission_df = source_dfs["object_permissions"]
    field_permission_df = source_dfs["field_permissions"]
    # Precompute sets for membership checks
    objects_df["EntityDefinition.QualifiedApiName"] = objects_df.index.to_series()
    exported_object_records_set = set(["Survey__c", "RecordType"])
    object_perm_set = set(object_permission_df.reset_index().SobjectType)
    field_perm_set = set(
        field_permission_df.reset_index().Field.astype("string").str.split(".").str[0]
    )
    # Platform events: https://salesforce.stackexchange.com/questions/101844/what-are-the-object-and-field-name-suffixes-that-salesforce-uses-such-as-c-an

    note_conditions = notes = [
        Note(
            name="core",
            title="Core Data Model",
            description="Core data model object (ie the original set of objects in the IBM dev data dictionary)",
            condition=objects_df["EntityDefinition.QualifiedApiName"]
            .isin(original_core_objects)
            .fillna(False),
        ),
        Note(
            name="healthcloud",
            title="Health Cloud Care Program",
            description="Health Cloud Care Program? (id'ed with Care Program,ActionPlan, Treatment objects or essential inputs like the Task object)",
            condition=objects_df["EntityDefinition.QualifiedApiName"].str.contains(
                "CareProgram|ActionPlan|Treatment|Task$", na=False
            ),
        ),
        Note(
            name="exported_records",
            description="See exported records",
            condition=objects_df["EntityDefinition.QualifiedApiName"]
            .isin(exported_object_records_set)
            .fillna(False),
        ),
        Note(
            name="has_object_permissions",
            description="Has object permissions",
            condition=objects_df["EntityDefinition.QualifiedApiName"]
            .isin(object_perm_set)
            .fillna(False),
        ),
        Note(
            name="has_field_permissions",
            description="Has field permissions",
            condition=objects_df["EntityDefinition.QualifiedApiName"]
            .isin(field_perm_set)
            .fillna(False),
        ),
        Note(
            name="marketingcloud",
            title="Marketing Cloud Package",
            description="et4ae5 denotes Installed Marketing Cloud Package (et4ae5 in namespace prefix = Marketing Cloud installed package)",
            condition=objects_df["EntityDefinition.NamespacePrefix"]
            .eq("et4ae5")
            .fillna(False),
        ),
        Note(
            name="platform_event",
            title="Platform Event",
            description="__e denotes platform event",
            condition=objects_df["EntityDefinition.QualifiedApiName"]
            .str.endswith("__e")
            .fillna(False),
        ),
        Note(
            name="custom",
            title="Custom",
            description="__c denotes custom object",
            condition=objects_df["EntityDefinition.QualifiedApiName"]
            .str.endswith("__c")
            .fillna(False),
        ),
    ]

    # Build list of notes by iterating dictionary
    notes = [
        [note.description for note in note_conditions if note.condition.iloc[i]]
        for i in range(len(objects_df))
    ]
    object_types = [
        ",".join([
            note.title
            for note in note_conditions
            if note.condition.iloc[i]
            and note.name in ["core", "healthcloud", "marketingcloud"]
        ])
        for i in range(len(objects_df))
    ]

    target_object_df["pdm.objectType"] = pd.Series(object_types, index=objects_df.index)
    target_object_df["pdm.objectType"] = target_object_df["pdm.objectType"].replace(
        "", pd.NA
    )
    target_object_df["pdm.notes"] = pd.Series(notes, index=objects_df.index)
    # target_object_df["pdm.source.apiTitle"] = ""
    # target_object_df["pdm.source.apiTitle"] += objects_df.name.notna()
    # target_object_df["pdm.source.apiTitle"] = objects_df.name.case_when(lambda s:s.notna(),"Sobjects Describe")

    # %%
    target_object_df = target_object_df.sort_values(by=["pdm.objectType", "name"])
    return target_object_df


# Compatibility for callers of the old report helper; this does not convert schemas.
from_dp_add_annotations = add_annotations

