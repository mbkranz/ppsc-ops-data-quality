import pandas as pd

from salesforce.transforms.tooling import column, object_columns
from salesforce.transforms.pandas import apply_mapping, bfill_if_dataframe

salesforce_object_transformers = {
    "title": ("EntityDefinition.Label",),
    "salesforce.description": ("EntityDefinition.Description",),
    "salesforce.durableId": ("EntityDefinition.DurableId",),
    "salesforce.recordCount": ("RecordCount.count",),
    "salesforce.keyPrefix": ("EntityDefinition.KeyPrefix",),
    "salesforce.isTriggerable": ("EntityDefinition.IsTriggerable",),
    "salesforce.isCustomizable": ("EntityDefinition.IsCustomizable",),
    "salesforce.isDeletable": ("EntityDefinition.IsEverDeletable",),
    "salesforce.isQueryable": ("EntityDefinition.IsQueryable",),
    "salesforce.isReportingEnabled": ("EntityDefinition.IsReportingEnabled",),
    "salesforce.lastModifiedBy.Name": ("EntityDefinition.LastModifiedBy.Name",),
    "salesforce.isDeprecatedAndHidden": ("EntityDefinition.IsDeprecatedAndHidden",),
    "salesforce.deploymentStatus": ("EntityDefinition.DeploymentStatus",),
}


def format_api_sources(frame):
    result = pd.Series("tooling/EntityDefinition", index=frame.index)
    result.loc[column(frame, "RecordCount.count").notna()] += ",limits/recordCount"
    return result


salesforce_object_transformers = [
    {"target": {"name": target}, "source": {"name": list(sources)}}
    for target, sources in salesforce_object_transformers.items()
] + [
    {
        "target": {"name": "pdm.source.apis"},
        "source": {
            "name": ["EntityDefinition.QualifiedApiName", "RecordCount.count"],
            "steps": [{"function": format_api_sources}],
        },
    }
]


def from_sf_to_dp(objects_df, steps=salesforce_object_transformers):
    frame = object_columns(objects_df)
    required = []
    for step in steps:
        names = step["source"]["name"]
        required.extend([names] if isinstance(names, str) else names)
    frame = frame.reindex(columns=list(dict.fromkeys([*frame.columns, *required])))
    return pd.concat(
        [
            apply_mapping(frame, step, fillna_function=bfill_if_dataframe)
            for step in steps
        ],
        axis=1,
    )
