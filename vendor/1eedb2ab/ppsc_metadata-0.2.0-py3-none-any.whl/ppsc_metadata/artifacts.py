"""Verify an explicit, versioned contract/native-metadata input set offline."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Literal

from open_data_contract_standard.model import OpenDataContractStandard
from pydantic import BaseModel, ConfigDict, Field, model_validator

from .contracts import parse_contract


class MetadataArtifact(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    path: str = Field(min_length=1)
    role: Literal["contract", "flow", "source", "rollup"]
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")


class MetadataManifest(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    version: Literal["projection-inputs/v1"] = "projection-inputs/v1"
    org: str = Field(min_length=1)
    flow_name: str = Field(min_length=1)
    flow_version_id: str = Field(min_length=1)
    source_revision: str = Field(pattern=r"^[0-9a-f]{40}$")
    provisional: bool
    coverage: str = Field(min_length=1)
    artifacts: tuple[MetadataArtifact, ...] = Field(min_length=2)

    @model_validator(mode="after")
    def validate_selection(self):
        paths = [item.path for item in self.artifacts]
        if len(paths) != len(set(paths)):
            raise ValueError("Metadata artifact paths must be unique")
        for role in ("contract", "flow"):
            if sum(item.role == role for item in self.artifacts) != 1:
                raise ValueError(f"Select exactly one {role} artifact")
        if sum(item.role == "rollup" for item in self.artifacts) > 1:
            raise ValueError("Select at most one native rollup artifact")
        return self


class MetadataBundle(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    manifest: MetadataManifest
    manifest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    contract: OpenDataContractStandard
    flow: dict[str, Any]
    rollups: dict[str, dict[str, Any]] = Field(default_factory=dict)


class MetadataReceipt(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    manifest: MetadataManifest
    manifest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    compiler_version: str
    contract_id: str
    contract_version: str


def load_metadata_bundle(root: Path, manifest_path: Path) -> MetadataBundle:
    """Read checked artifacts only; never fetch source files or resolve a service."""
    payload = manifest_path.read_bytes()
    manifest = MetadataManifest.model_validate_json(payload)
    selected = {}
    for artifact in manifest.artifacts:
        path = (root / artifact.path).resolve()
        if not path.is_relative_to(root.resolve()):
            raise ValueError(f"Metadata artifact escapes its root: {artifact.path}")
        content = path.read_bytes()
        if hashlib.sha256(content).hexdigest() != artifact.sha256:
            raise ValueError(f"Metadata artifact hash mismatch: {artifact.path}")
        if artifact.role in {"contract", "flow", "rollup"}:
            selected[artifact.role] = content
    flow = json.loads(selected["flow"])
    if (
        flow.get("Id") != manifest.flow_version_id
        or flow.get("FullName") != manifest.flow_name
    ):
        raise ValueError("Selected Flow identity does not match its manifest")
    if not isinstance(flow.get("Metadata"), dict):
        raise ValueError("Selected Flow must retain its native Metadata")
    rollups = json.loads(selected["rollup"]) if "rollup" in selected else {}
    if not isinstance(rollups, dict) or any(
        not isinstance(name, str) or not isinstance(value, dict)
        for name, value in rollups.items()
    ):
        raise ValueError("Selected rollups must map field names to native metadata")
    return MetadataBundle(
        manifest=manifest,
        manifest_sha256=hashlib.sha256(payload).hexdigest(),
        contract=parse_contract(selected["contract"].decode("utf-8")),
        flow=flow,
        rollups=rollups,
    )
