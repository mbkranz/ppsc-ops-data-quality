"""Add explicit source and field links to ODCS without resolving or executing them."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any
from uuid import NAMESPACE_URL, uuid5

from open_data_contract_standard.model import (
    AuthoritativeDefinition,
    OpenDataContractStandard,
)
from pydantic import BaseModel, ConfigDict, Field, model_validator

from .contracts import property_paths, property_references, validate_contract


class ProjectionEvidence(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    target_field: str = Field(min_length=1)
    source_entities: tuple[str, ...]
    source_paths: tuple[str, ...]
    description: str
    branches: tuple[dict[str, Any], ...] = ()
    dependencies: tuple[str, ...] = ()
    field_references: tuple[str, ...] = ()


class ProjectionDefinitionsRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    source_url: str = Field(min_length=1)
    source_prefix: str = ""
    field_bindings: dict[str, str] = Field(default_factory=dict)
    target_bindings: dict[str, str] = Field(default_factory=dict)

    @model_validator(mode="after")
    def valid_source(self) -> ProjectionDefinitionsRequest:
        if "#" in self.source_url or (
            self.source_prefix and not self.source_prefix.startswith("/")
        ):
            raise ValueError(
                "Supply an artifact URL and a separate absolute source pointer"
            )
        if any(
            not key or not value
            for bindings in (self.field_bindings, self.target_bindings)
            for key, value in bindings.items()
        ):
            raise ValueError("Field bindings must be nonempty")
        return self


def field_reference(contract: OpenDataContractStandard, qualified_name: str) -> str:
    """Return a stable local ODCS property-ID pointer, never an inferred join."""
    pointers = [
        key
        for key, value in property_references(contract).items()
        if key.startswith("schema/") and value == qualified_name
    ]
    if len(pointers) != 1:
        raise ValueError(
            f"A field reference needs one declared property with stable IDs: {qualified_name}"
        )
    return "#/" + pointers[0]


def add_projection_definitions(
    contract: OpenDataContractStandard,
    request: ProjectionDefinitionsRequest,
    *,
    lineage: Mapping[str, ProjectionEvidence],
) -> OpenDataContractStandard:
    """Copy and validate ODCS, adding source definitions and bound field references.

    FieldReference is a PPSC provenance-link type in ODCS's open definition list.
    The caller binds unresolved native relationship aliases to qualified fields.
    The function performs no I/O, reference fetching, query, or rule execution.
    """
    output = validate_contract(
        contract.model_dump(mode="json", by_alias=True, exclude_unset=True)
    )
    properties = {
        ".".join((obj.name, *path)): prop
        for obj in output.schema_ or []
        for path, prop in property_paths(obj)
    }
    for evidence in lineage.values():
        target = request.target_bindings.get(
            evidence.target_field, evidence.target_field
        )
        if target not in properties:
            raise ValueError(f"Unbound projection target: {evidence.target_field}")
        prop = properties[target]
        source_objects = list(prop.transformSourceObjects or [])
        entries = list(prop.authoritativeDefinitions or [])
        links = [
            (
                "transformationImplementation",
                request.source_url + "#" + request.source_prefix + pointer,
                evidence.description,
            )
            for pointer in evidence.source_paths
        ]
        for reference in evidence.field_references:
            bound = request.field_bindings.get(reference, reference)
            source_objects.append(bound.partition(".")[0])
            links.append((
                "fieldReference",
                field_reference(output, bound),
                f"Input field {bound} for {evidence.target_field}",
            ))
        existing = {(entry.type, entry.url) for entry in entries}
        for kind, url, description in links:
            if (kind, url) not in existing:
                entries.append(
                    AuthoritativeDefinition(
                        id=str(uuid5(NAMESPACE_URL, f"{target}|{kind}|{url}")),
                        type=kind,
                        url=url,
                        description=description,
                    )
                )
                existing.add((kind, url))
        prop.authoritativeDefinitions = entries
        prop.transformSourceObjects = list(dict.fromkeys(source_objects))
    return validate_contract(output)
