"""Native Ibis projection composition, independent of a source system or runner."""

from __future__ import annotations

from collections.abc import Mapping, Sequence

import ibis
import ibis.expr.types as ir
from pydantic import BaseModel, ConfigDict, Field

from .definitions import ProjectionEvidence


class ProjectionResult(BaseModel):
    model_config = ConfigDict(extra="forbid", arbitrary_types_allowed=True)

    expressions: dict[str, ir.Value]
    deterministic: dict[str, ir.BooleanValue]
    lineage: dict[str, ProjectionEvidence] = Field(default_factory=dict)
    assigned: dict[str, ir.BooleanValue] = Field(default_factory=dict)


def presence_requirements(
    *,
    required: Mapping[str, ir.BooleanValue] | None = None,
    must_be_null: Mapping[str, ir.BooleanValue] | None = None,
) -> dict[str, ir.BooleanValue]:
    """Name independent presence predicates; false is out of scope, NULL unknown.

    A false required predicate never invents a nullness requirement. The caller
    compiles domain conditions and retains physical NULL/sentinel distinctions.
    """
    result = {}
    for values, suffix in ((required, "required"), (must_be_null, "must_be_null")):
        for field, predicate in (values or {}).items():
            if not field or not isinstance(predicate, ir.BooleanValue):
                raise ValueError("Presence requirements need named Boolean expressions")
            name = f"expected__{field}_{suffix}"
            result[name] = predicate.name(name)
    return result


def expected_values(
    record: ir.Table, projection: ProjectionResult, *, keys: Sequence[str]
) -> ir.Table:
    """Project a keyed expected dataset; observations and joins stay caller-owned."""
    if not keys or len(set(keys)) != len(keys) or not set(keys) <= set(record.columns):
        raise ValueError("Expected values require unique, bound identity columns")
    fields = set(projection.expressions)
    if (
        fields != set(projection.deterministic)
        or not set(projection.assigned) <= fields
    ):
        raise ValueError("Projection evidence must match its expected fields")
    values = {
        f"expected__{name}": value for name, value in projection.expressions.items()
    }
    values.update({
        f"expected__{name}__deterministic": value
        for name, value in projection.deterministic.items()
    })
    values.update({
        f"expected__{name}__assigned": value
        for name, value in projection.assigned.items()
    })
    names = [*keys, *values]
    expected_count = (
        len(keys)
        + len(projection.expressions)
        + len(projection.deterministic)
        + len(projection.assigned)
    )
    if len(set(names)) != expected_count:
        raise ValueError("Expected value/evidence column collision")
    return record.select(*keys, **values)


def conditional_values(
    before: Mapping[str, ir.Value],
    assignments: Sequence[tuple[ir.BooleanValue, Mapping[str, ir.Value]]],
) -> dict[str, ir.Value]:
    """Compose ordered native CASE values; a selected NULL is an assignment."""
    result = {}
    for field, previous in before.items():
        branches = [
            (guard, values[field]) for guard, values in assignments if field in values
        ]
        result[field] = (
            ibis.cases(*branches, else_=previous) if branches else previous
        ).name(field)
    return result
