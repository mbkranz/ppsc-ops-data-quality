"""Explicit adapters from ODCS to engine and JSON schemas; never execute data."""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING, Any

from open_data_contract_standard.model import (
    OpenDataContractStandard,
    SchemaObject,
    SchemaProperty,
)

from .contracts import decimal_type, validate_contract

if TYPE_CHECKING:
    import ibis


class UnsupportedSchemaError(ValueError):
    """The requested representation cannot preserve the declared semantics."""


def schema_object(contract: OpenDataContractStandard, name: str) -> SchemaObject:
    contract = validate_contract(contract)
    matches = [obj for obj in contract.schema_ or [] if obj.name == name]
    if len(matches) != 1:
        raise ValueError(f"Expected one ODCS object named {name!r}")
    return matches[0]


def _check_temporal_format(prop: SchemaProperty, representation: str) -> None:
    declared = (prop.logicalTypeOptions or {}).get("format")
    if declared is not None and not (
        prop.logicalType == "date" and declared == "yyyy-MM-dd"
    ):
        raise UnsupportedSchemaError(
            f"{prop.name}: {representation} cannot preserve temporal format {declared!r}; "
            "use an explicit serialization adapter"
        )


def property_json_schema(prop: SchemaProperty) -> dict[str, Any]:
    """Translate the supported structural constraints, preserving required children."""
    kind = prop.logicalType
    if kind not in {
        "string",
        "integer",
        "number",
        "boolean",
        "date",
        "timestamp",
        "time",
        "object",
        "array",
    }:
        raise UnsupportedSchemaError(
            f"{prop.name}: unsupported JSON Schema type {kind!r}"
        )
    result = {"type": "string" if kind in {"date", "timestamp", "time"} else kind}
    if prop.description is not None:
        result["description"] = prop.description
    options = prop.logicalTypeOptions or {}
    if kind in {"date", "timestamp", "time"}:
        _check_temporal_format(prop, "JSON Schema")
    if kind in {"timestamp", "time"} and (
        options.get("timezone") is False
        or ("defaultTimezone" in options and options.get("timezone") is not True)
    ):
        raise UnsupportedSchemaError(
            f"{prop.name}: JSON Schema temporal formats require an explicit UTC offset; "
            "timezone-free values or default-timezone interpretation need a data check"
        )
    bounds = {"minimum", "maximum", "exclusiveMinimum", "exclusiveMaximum"}
    if kind in {"date", "timestamp", "time"} and bounds.intersection(options):
        raise UnsupportedSchemaError(
            f"{prop.name}: temporal bounds require a data check"
        )
    for key in (
        "minLength",
        "maxLength",
        "pattern",
        "minimum",
        "maximum",
        "exclusiveMinimum",
        "exclusiveMaximum",
        "multipleOf",
        "minItems",
        "maxItems",
        "uniqueItems",
        "minProperties",
        "maxProperties",
    ):
        if key in options:
            result[key] = options[key]
    formats = {"date": "date", "timestamp": "date-time", "time": "time"}
    if kind in formats:
        result["format"] = formats[kind]
    elif kind == "string" and options.get("format"):
        result["format"] = options["format"]
    if prop.enum is not None:
        result["enum"] = [value.value for value in prop.enum]
        if prop.required is not True and None not in result["enum"]:
            result["enum"].append(None)
    if kind == "object":
        result["properties"] = {
            child.name: property_json_schema(child) for child in prop.properties or []
        }
        required = [
            child.name for child in prop.properties or [] if child.required is True
        ]
        if required:
            result["required"] = required
        declared = options.get("required", [])
        if declared:
            result["required"] = list(dict.fromkeys([*required, *declared]))
    if kind == "array":
        if prop.items is None:
            raise UnsupportedSchemaError(
                f"{prop.name}: array requires an items definition"
            )
        result["items"] = property_json_schema(prop.items)
    if prop.required is not True:
        result["type"] = [result["type"], "null"]
    return result


def json_schema(contract: OpenDataContractStandard, object_name: str) -> dict[str, Any]:
    obj = schema_object(contract, object_name)
    result = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "title": obj.name,
        "type": "object",
        "properties": {p.name: property_json_schema(p) for p in obj.properties or []},
    }
    required = [p.name for p in obj.properties or [] if p.required is True]
    if required:
        result["required"] = required
    return result


def ibis_schema(
    contract: OpenDataContractStandard,
    object_name: str,
    *,
    enforce_required: bool = False,
    fields: Sequence[str] | None = None,
) -> ibis.Schema:
    """Return a native Ibis schema; raw validation inputs stay nullable by default."""
    import ibis
    import ibis.expr.datatypes as dt

    def dtype(prop):
        nullable = not (enforce_required and prop.required is True)
        kind = prop.logicalType
        options = prop.logicalTypeOptions or {}
        if kind in {"date", "timestamp", "time"}:
            _check_temporal_format(prop, "Ibis")
        if kind in {"timestamp", "time"} and (
            "defaultTimezone" in options and options.get("timezone") is not True
        ):
            raise UnsupportedSchemaError(
                f"{prop.name}: default-timezone interpretation requires an explicit "
                "binding before using an Ibis schema"
            )
        if kind == "time" and options.get("timezone"):
            raise UnsupportedSchemaError(
                f"{prop.name}: Ibis time cannot represent timezone-aware values"
            )
        scalar = {
            "string": dt.string,
            "integer": dt.int64,
            "boolean": dt.boolean,
            "date": dt.date,
            "time": dt.time,
        }
        if kind == "integer" and (prop.logicalTypeOptions or {}).get("format"):
            fmt = prop.logicalTypeOptions["format"]
            integers = {
                f"{sign}{bits}": getattr(dt, f"{prefix}{bits}")
                for sign, prefix in (("i", "int"), ("u", "uint"))
                for bits in (8, 16, 32, 64)
            }
            if fmt not in integers:
                raise UnsupportedSchemaError(
                    f"{prop.name}: Ibis cannot represent integer format {fmt}"
                )
            return integers[fmt].copy(nullable=nullable)
        if kind in scalar:
            return scalar[kind].copy(nullable=nullable)
        if kind == "timestamp":
            zone = options.get("defaultTimezone") if options.get("timezone") else None
            if options.get("timezone") and not zone:
                raise UnsupportedSchemaError(
                    f"{prop.name}: supply the timestamp timezone explicitly"
                )
            return dt.Timestamp(timezone=zone, nullable=nullable)
        if kind == "number":
            decimal = decimal_type(prop)
            if decimal:
                return dt.Decimal(decimal.precision, decimal.scale, nullable=nullable)
            fmt = (prop.logicalTypeOptions or {}).get("format")
            if fmt in {"f32", "f64"}:
                return {"f32": dt.float32, "f64": dt.float64}[fmt].copy(
                    nullable=nullable
                )
            raise UnsupportedSchemaError(
                f"{prop.name}: declare ppsc.decimal or an explicit float format"
            )
        if kind == "object" and prop.properties:
            return dt.Struct(
                {p.name: dtype(p) for p in prop.properties}, nullable=nullable
            )
        if kind == "array" and prop.items is not None:
            return dt.Array(dtype(prop.items), nullable=nullable)
        raise UnsupportedSchemaError(
            f"{prop.name}: unsupported or incomplete Ibis type {kind!r}"
        )

    obj = schema_object(contract, object_name)
    properties = {p.name: p for p in obj.properties or []}
    selected = list(properties) if fields is None else list(fields)
    if len(selected) != len(set(selected)) or any(
        name not in properties for name in selected
    ):
        raise ValueError(f"Select unique declared properties from {object_name}")
    return ibis.schema({name: dtype(properties[name]) for name in selected})
