"""ODCS-to-table projection, independent of workbook styling and source clients."""

from __future__ import annotations

import json

import pandas as pd
from open_data_contract_standard.model import OpenDataContractStandard
from pydantic import BaseModel, ConfigDict

from .contracts import (
    decimal_type,
    internal_reference,
    property_paths,
    property_references,
    validate_contract,
)
from .schemas import UnsupportedSchemaError, property_json_schema


class WorkbookTables(BaseModel):
    model_config = ConfigDict(extra="forbid", arbitrary_types_allowed=True)

    objects: pd.DataFrame
    fields: pd.DataFrame


OBJECT_COLUMNS = [
    "Authoritative Definitions",
    "Object",
    "Name",
    "Label",
    "Description (Main/Approved)",
    "Link to Other Objects/Records",
    "ODCS ID",
    "Contract ID",
    "Contract Version",
    "Contract Coverage",
    "Observed in source",
]
FIELD_COLUMNS = [
    "Authoritative Definitions",
    "Field References",
    "Field",
    "Object Name",
    "Name",
    "Title",
    "Type",
    "Description (Main/Approved)",
    "Required",
    "Unique",
    "Format",
    "Pandas Format",
    "Max string length",
    "String Regex Pattern",
    "Total Digits (e.g., 1.8 is 2 digits)",
    "Fraction Digits (e.g., 1.8 is 1 digit)",
    "Json Schema",
    "JSON Schema Diagnostic",
    "Category Origin",
    "Category Possible Values",
    "Category Possible Labels",
    "Category Value to Label Map",
    "Category Value to Label Dictionary",
    "Link to Other Objects/Records",
    "ODCS ID",
    "Contract ID",
    "Contract Version",
    "Contract Coverage",
    "Observed in source",
]


def _enum_text(values):
    entries = values or []
    return {
        "Category Possible Values": "|".join(str(e.value) for e in entries),
        "Category Possible Labels": "|".join(e.label or "" for e in entries),
        "Category Value to Label Map": "|".join(
            f"{e.value}={e.label}" for e in entries if e.label is not None
        ),
        "Category Value to Label Dictionary": json.dumps(
            {str(e.value): e.label for e in entries if e.label is not None},
            ensure_ascii=False,
        )
        if entries
        else None,
    }


def _tables(contract: OpenDataContractStandard, coverage: str) -> WorkbookTables:
    objects, fields = [], []
    references = property_references(contract)

    def display_reference(value):
        values = value if isinstance(value, list) else [value]
        names = [references.get(internal_reference(ref), ref) for ref in values]
        return "(" + ", ".join(names) + ")" if isinstance(value, list) else names[0]

    field_links = {}
    object_links = {}
    for obj in contract.schema_ or []:
        object_links[obj.name] = []
        for relationship in obj.relationships or []:
            sources = relationship.from_
            full_link = (
                f"{display_reference(sources)} -> {display_reference(relationship.to)}"
            )
            object_links[obj.name].append(full_link)
            # Composite members must retain the whole ordered key mapping.
            link = (
                full_link
                if isinstance(sources, list)
                else display_reference(relationship.to)
            )
            for source in sources if isinstance(sources, list) else [sources]:
                name = references.get(internal_reference(source))
                if name is not None:
                    field_links.setdefault(name, []).append(link)

    for obj in contract.schema_ or []:
        objects.append({
            "Authoritative Definitions": json.dumps(
                [
                    entry.model_dump(mode="json", exclude_none=True)
                    for entry in obj.authoritativeDefinitions
                ],
                ensure_ascii=False,
            )
            if obj.authoritativeDefinitions
            else None,
            "Object": obj.name,
            "Name": obj.name,
            "Label": obj.businessName,
            "Description (Main/Approved)": obj.description,
            "Link to Other Objects/Records": "|".join(object_links[obj.name]),
            "ODCS ID": obj.id,
            "Contract ID": contract.id,
            "Contract Version": contract.version,
            "Contract Coverage": coverage,
        })
        for path, prop in property_paths(obj):
            options = prop.logicalTypeOptions or {}
            decimal = decimal_type(prop)
            structured = prop.logicalType in {"object", "array"}
            json_value = None
            json_status = None
            if structured or prop.logicalType in {"date", "timestamp", "time"}:
                try:
                    representation = property_json_schema(prop)
                    if structured:
                        json_value = json.dumps(representation, ensure_ascii=False)
                except UnsupportedSchemaError as error:
                    json_status = str(error)
            row = {
                "Authoritative Definitions": json.dumps(
                    [
                        entry.model_dump(mode="json", exclude_none=True)
                        for entry in prop.authoritativeDefinitions
                    ],
                    ensure_ascii=False,
                )
                if prop.authoritativeDefinitions
                else None,
                "Field References": "|".join(
                    display_reference(entry.url)
                    for entry in prop.authoritativeDefinitions or []
                    if entry.type == "fieldReference"
                )
                or None,
                "Field": ".".join((obj.name, *path)),
                "Object Name": obj.name,
                "Name": prop.name,
                "Title": prop.businessName,
                "Type": prop.logicalType,
                "Description (Main/Approved)": prop.description,
                "Required": prop.required,
                "Unique": prop.unique,
                "Format": options.get("format"),
                "Pandas Format": {
                    "yyyy-MM-dd": "%Y-%m-%d",
                    "yyyy-MM-dd'T'HH:mm:ss'Z'": "%Y-%m-%dT%H:%M:%SZ",
                    "HH:mm:ss": "%H:%M:%S",
                }.get(options.get("format")),
                "Max string length": options.get("maxLength"),
                "String Regex Pattern": options.get("pattern"),
                "Total Digits (e.g., 1.8 is 2 digits)": decimal.precision
                if decimal
                else None,
                "Fraction Digits (e.g., 1.8 is 1 digit)": decimal.scale
                if decimal
                else None,
                "Json Schema": json_value,
                "JSON Schema Diagnostic": json_status,
                "Category Origin": "ODCS enum" if prop.enum is not None else None,
                "Link to Other Objects/Records": "|".join([
                    *(display_reference(r.to) for r in prop.relationships or []),
                    *field_links.get(".".join((obj.name, *path)), []),
                ]),
                "ODCS ID": prop.id,
                "Contract ID": contract.id,
                "Contract Version": contract.version,
                "Contract Coverage": coverage,
                **_enum_text(prop.enum),
            }
            fields.append(row)
    object_frame = pd.DataFrame(objects, columns=OBJECT_COLUMNS).set_index("Object")
    field_frame = pd.DataFrame(fields, columns=FIELD_COLUMNS).set_index("Field")
    if not field_frame.index.is_unique:
        raise UnsupportedSchemaError(
            "Property names collide when flattened into workbook field paths"
        )
    return WorkbookTables(objects=object_frame, fields=field_frame)


def workbook_tables(
    contract: OpenDataContractStandard | None,
    *,
    observed: OpenDataContractStandard | None = None,
) -> WorkbookTables:
    """Authored rows win, including explicit/unspecified values; keep inventory visible.

    Observed-only rows are labeled and are not promoted to authored requirements.
    Source-specific report columns and permissions are joined by the application.
    """
    if contract is None:
        if observed is None:
            raise ValueError("Supply an authored contract or an observed inventory")
        tables = _tables(validate_contract(observed), "Observed only")
        for frame in (tables.objects, tables.fields):
            frame["Observed in source"] = True
        return tables
    authored = _tables(validate_contract(contract), "Authored")
    if observed is None:
        return authored
    inventory = _tables(validate_contract(observed), "Observed only")
    tables = WorkbookTables(**{
        name: pd.concat([
            getattr(authored, name).astype(object),
            getattr(inventory, name)
            .astype(object)
            .loc[~getattr(inventory, name).index.isin(getattr(authored, name).index)],
        ]).sort_index()
        for name in ("objects", "fields")
    })
    for name in ("objects", "fields"):
        frame = getattr(tables, name)
        frame["Observed in source"] = frame.index.isin(getattr(inventory, name).index)
    return tables
