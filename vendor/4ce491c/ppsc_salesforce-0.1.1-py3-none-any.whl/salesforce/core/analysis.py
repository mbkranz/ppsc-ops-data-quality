"""Immutable native evidence and occurrence-aware facts, without renderers."""

from __future__ import annotations

import math
import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Literal, TypeAlias
from urllib.parse import quote

JSONScalar: TypeAlias = str | int | float | bool | None
FrozenJSON: TypeAlias = (
    JSONScalar | tuple["FrozenJSON", ...] | Mapping[str, "FrozenJSON"]
)
ConnectionFamily: TypeAlias = Literal[
    "reads", "writes", "control", "invokes", "contains", "binds_to"
]


def _freeze(value: Any, ancestors: frozenset[int] = frozenset()) -> FrozenJSON:
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Native evidence requires finite JSON numbers")
        return value
    if isinstance(value, (Mapping, list, tuple)):
        if id(value) in ancestors:
            raise ValueError("Native evidence cannot contain circular references")
        ancestors = ancestors | {id(value)}
        if isinstance(value, Mapping):
            if any(not isinstance(key, str) for key in value):
                raise ValueError("Native evidence requires string object keys")
            return MappingProxyType({
                key: _freeze(child, ancestors) for key, child in value.items()
            })
        return tuple(_freeze(child, ancestors) for child in value)
    raise TypeError(f"Native evidence is not JSON-safe: {type(value).__name__}")


def _thaw(value: FrozenJSON) -> Any:
    if isinstance(value, Mapping):
        return {key: _thaw(child) for key, child in value.items()}
    if isinstance(value, tuple):
        return [_thaw(child) for child in value]
    return value


def pointer(*parts: str | int) -> str:
    return "".join(
        "/" + str(part).replace("~", "~0").replace("/", "~1") for part in parts
    )


def _pointer_parts(path: str) -> tuple[str, ...]:
    if not isinstance(path, str) or (path and not path.startswith("/")):
        raise ValueError("JSON Pointer must be empty or begin with '/'")
    if re.search(r"~(?:[^01]|$)", path):
        raise ValueError(f"Invalid JSON Pointer escape: {path!r}")
    return tuple(
        part.replace("~1", "/").replace("~0", "~") for part in path.split("/")[1:]
    )


@dataclass(frozen=True, init=False)
class NativeDocument:
    _root: Mapping[str, FrozenJSON] = field(repr=False)

    def __init__(self, value: Mapping[str, Any]):
        root = _freeze(value)
        if not isinstance(root, Mapping):
            raise TypeError("Native document must be a JSON object")
        object.__setattr__(self, "_root", root)

    @property
    def root(self) -> Mapping[str, FrozenJSON]:
        return self._root

    def at(self, path: str = "") -> FrozenJSON:
        value: FrozenJSON = self._root
        for part in _pointer_parts(path):
            if isinstance(value, Mapping):
                value = value[part]
            elif isinstance(value, tuple):
                if not re.fullmatch(r"0|[1-9][0-9]*", part):
                    raise ValueError(f"Invalid array index in JSON Pointer: {path!r}")
                value = value[int(part)]
            else:
                raise ValueError(f"JSON Pointer descends through a scalar: {path!r}")
        return value

    def export(self, path: str = "") -> Any:
        """Return a detached JSON-safe fragment; absence is never replaced by NULL."""
        return _thaw(self.at(path))


@dataclass(frozen=True)
class SourceLocation:
    pointer: str
    start: int | None = None
    end: int | None = None

    def __post_init__(self):
        _pointer_parts(self.pointer)
        if self.start is None and self.end is None:
            return
        if (
            type(self.start) is not int
            or type(self.end) is not int
            or self.start < 0
            or self.end < self.start
        ):
            raise ValueError("Source spans require nonnegative, end-exclusive offsets")

    def occurrence_id(self, role: str) -> str:
        parts = (self.pointer, str(self.start), str(self.end), role)
        return "/".join(quote(part, safe="") for part in parts)


@dataclass(frozen=True)
class SourceIdentity:
    source_file: str | None = None
    metadata_base: str | None = None
    org: str | None = None
    version_id: str | None = None
    source_sha256: str | None = None
    origin: Literal["native", "normalized-model", "unbound"] = "unbound"

    def __post_init__(self):
        if self.metadata_base is not None:
            _pointer_parts(self.metadata_base)
        if self.origin not in {"native", "normalized-model", "unbound"}:
            raise ValueError(f"Unknown source origin: {self.origin}")
        if self.origin == "normalized-model" and self.metadata_base is not None:
            raise ValueError("Normalized model evidence has no saved-file base")

    def envelope_pointer(self, location: SourceLocation) -> str:
        return "/Metadata" + location.pointer

    def saved_pointer(self, location: SourceLocation) -> str:
        if self.metadata_base is None:
            raise ValueError("Saved-file provenance requires an explicit metadata base")
        return self.metadata_base + location.pointer

    def scoped_id(self, local_id: str) -> str:
        if not self.org or not self.version_id:
            raise ValueError("Persisted identity requires an org and Flow version")
        return "/".join(
            quote(part, safe="")
            for part in (self.org, "flow", self.version_id, local_id)
        )


@dataclass(frozen=True)
class Declaration:
    local_id: str
    name: str
    kind: str
    location: SourceLocation
    owner_id: str | None = None


@dataclass(frozen=True)
class ReferenceOccurrence:
    reference: str
    location: SourceLocation
    owner_id: str
    role: str
    syntax: Literal["native", "bare", "merge"] = "native"

    @property
    def occurrence_id(self) -> str:
        return self.location.occurrence_id(self.role)


@dataclass(frozen=True)
class Connection:
    source: str
    target: str
    family: ConnectionFamily
    role: str
    owner_id: str
    location: SourceLocation
    occurrence_ids: tuple[str, ...] = ()

    def __post_init__(self):
        if self.family not in {
            "reads",
            "writes",
            "control",
            "invokes",
            "contains",
            "binds_to",
        }:
            raise ValueError(f"Unknown connection family: {self.family}")
        object.__setattr__(self, "occurrence_ids", tuple(self.occurrence_ids))

    @property
    def connection_id(self) -> str:
        return "/".join(
            quote(part, safe="")
            for part in (
                self.location.occurrence_id(self.role),
                self.family,
                self.owner_id,
                self.source,
                self.target,
            )
        )


@dataclass(frozen=True)
class Expression:
    owner_id: str
    location: SourceLocation
    language: str
    occurrence_ids: tuple[str, ...] = ()

    def __post_init__(self):
        object.__setattr__(self, "occurrence_ids", tuple(self.occurrence_ids))


@dataclass(frozen=True)
class Diagnostic:
    code: str
    message: str
    location: SourceLocation
    owner_id: str
    consequence: Literal["structural", "unsupported", "uninterpreted", "binding"]

    def __post_init__(self):
        if self.consequence not in {
            "structural",
            "unsupported",
            "uninterpreted",
            "binding",
        }:
            raise ValueError(f"Unknown diagnostic consequence: {self.consequence}")
