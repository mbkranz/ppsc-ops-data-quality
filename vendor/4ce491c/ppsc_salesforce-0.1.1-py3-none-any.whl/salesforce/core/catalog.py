"""Exact saved catalog identities, independent of acquisition and SQL types."""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Set
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Literal
from urllib.parse import quote


@dataclass(frozen=True)
class FieldIdentity:
    object_name: str
    api_name: str
    kind: Literal["FieldDefinition", "EntityParticle"] = "FieldDefinition"
    parent_name: str | None = None
    durable_id: str | None = None

    def __post_init__(self):
        if any(
            not isinstance(name, str) or not name
            for name in (self.object_name, self.api_name)
        ):
            raise ValueError("Catalog identities require nonempty native API names")
        if self.kind not in {"FieldDefinition", "EntityParticle"}:
            raise ValueError(f"Unknown catalog identity kind: {self.kind}")
        if any(
            value is not None and (not isinstance(value, str) or not value)
            for value in (self.parent_name, self.durable_id)
        ):
            raise ValueError(
                "Catalog parent and durable identities must be native names"
            )


def canonical_field_id(identity: FieldIdentity) -> str:
    """Format semantic endpoints without changing the evidenced API spelling.

    Definitions retain their object/API key. Particles additionally distinguish
    each evidenced parent and durable ID; neither is inferred from a leaf name.
    Named, escaped segments keep absent evidence distinct from literal separator
    text. Legacy graph/network projections own their historical display IDs.
    """
    identifier = (
        f"{identity.kind}/{quote(identity.object_name, safe='')}."
        f"{quote(identity.api_name, safe='')}"
    )
    if identity.kind == "EntityParticle":
        for key, value in (
            ("parent", identity.parent_name),
            ("durable", identity.durable_id),
        ):
            if value is not None:
                identifier += f"/{key}={quote(value, safe='')}"
    return identifier


@dataclass(frozen=True)
class FieldBinding:
    status: Literal["resolved", "unresolved", "ambiguous"]
    candidates: tuple[FieldIdentity, ...] = ()

    def __post_init__(self):
        candidates = tuple(self.candidates)
        object.__setattr__(self, "candidates", candidates)
        if (
            self.status not in {"resolved", "unresolved", "ambiguous"}
            or (self.status == "resolved" and len(candidates) != 1)
            or (self.status == "unresolved" and candidates)
            or (self.status == "ambiguous" and len(candidates) == 1)
        ):
            raise ValueError("Binding status conflicts with its catalog candidates")

    @property
    def identity(self) -> FieldIdentity | None:
        return self.candidates[0] if self.status == "resolved" else None


def _identity_key(identity: FieldIdentity):
    return (
        identity.object_name,
        identity.api_name,
        identity.kind,
        identity.parent_name or "",
        identity.durable_id or "",
    )


def _binding(candidates: Iterable[FieldIdentity]) -> FieldBinding:
    values = tuple(sorted(set(candidates), key=_identity_key))
    return FieldBinding(
        "unresolved" if not values else "resolved" if len(values) == 1 else "ambiguous",
        values,
    )


@dataclass(frozen=True, init=False)
class CatalogIndex:
    objects: frozenset[str]
    fields: tuple[FieldIdentity, ...]
    relationships: Mapping[tuple[str, str], tuple[str, ...]]
    scope: str | None
    _definitions: Mapping[tuple[str, str], tuple[FieldIdentity, ...]]
    _particles: Mapping[tuple[str, str], tuple[FieldIdentity, ...]]

    def __init__(
        self,
        objects: Iterable[str] = (),
        fields: Iterable[FieldIdentity] = (),
        relationships: Mapping[tuple[str, str], Iterable[str]] | None = None,
        *,
        scope: str | None = None,
    ):
        names = frozenset(objects)
        if any(not isinstance(name, str) or not name for name in names):
            raise ValueError("Object catalog requires nonempty native API names")
        identities = tuple(sorted(set(fields), key=_identity_key))
        definitions: dict[tuple[str, str], list[FieldIdentity]] = {}
        particles: dict[tuple[str, str], list[FieldIdentity]] = {}
        for identity in identities:
            index = definitions if identity.kind == "FieldDefinition" else particles
            index.setdefault((identity.object_name, identity.api_name), []).append(
                identity
            )
        saved_relationships = {}
        for key, targets in (relationships or {}).items():
            if (
                not isinstance(key, tuple)
                or len(key) != 2
                or any(not isinstance(part, str) or not part for part in key)
                or isinstance(targets, (str, bytes))
            ):
                raise ValueError("Relationships require exact entity/name and targets")
            values = tuple(targets)
            if any(not isinstance(target, str) or not target for target in values):
                raise ValueError("Relationship targets must be native object names")
            saved_relationships[key] = tuple(sorted(set(values)))
        object.__setattr__(self, "objects", names)
        object.__setattr__(self, "fields", identities)
        object.__setattr__(self, "relationships", MappingProxyType(saved_relationships))
        object.__setattr__(self, "scope", scope)
        object.__setattr__(
            self,
            "_definitions",
            MappingProxyType({key: tuple(value) for key, value in definitions.items()}),
        )
        object.__setattr__(
            self,
            "_particles",
            MappingProxyType({key: tuple(value) for key, value in particles.items()}),
        )

    @classmethod
    def from_rows(
        cls,
        objects: Iterable[Mapping[str, Any]],
        fields: Iterable[Mapping[str, Any]],
        *,
        scope: str | None = None,
    ) -> CatalogIndex:
        names = [
            row.get("EntityDefinition.QualifiedApiName", row.get("QualifiedApiName"))
            for row in objects
        ]
        identities = []
        relationships: dict[tuple[str, str], set[str]] = {}
        for row in fields:
            obj = row.get("EntityDefinition.QualifiedApiName")
            parent = row.get("FieldDefinition.QualifiedApiName")
            component = row.get(
                "EntityParticle.QualifiedApiName", row.get("QualifiedApiName", parent)
            )
            if not isinstance(obj, str) or not obj:
                raise ValueError("Field rows require an exact entity API name")
            if not isinstance(parent, str) or not parent:
                raise ValueError("Field rows require an exact definition API name")
            identities.append(
                FieldIdentity(
                    obj, parent, durable_id=row.get("FieldDefinition.DurableId")
                )
            )
            if component is not None:
                if not isinstance(component, str) or not component:
                    raise ValueError("Particle API names must be nonempty strings")
                if (
                    component != parent
                    or row.get("EntityParticle.IsComponent") is True
                    or row.get("IsComponent") is True
                ):
                    identities.append(
                        FieldIdentity(
                            obj,
                            component,
                            "EntityParticle",
                            parent,
                            row.get("EntityParticle.DurableId"),
                        )
                    )
            relationship = row.get(
                "FieldDefinition.RelationshipName",
                row.get("EntityParticle.RelationshipName"),
            )
            reference = row.get(
                "FieldDefinition.ReferenceTo", row.get("EntityParticle.ReferenceTo")
            )
            if relationship is not None:
                if not isinstance(relationship, str) or not relationship:
                    raise ValueError("Relationship names must be native API names")
                if reference is not None and not isinstance(reference, Mapping):
                    raise ValueError(
                        "ReferenceTo must contain native referenceTo names"
                    )
                targets = (
                    reference.get("referenceTo", []) if reference is not None else []
                )
                if not isinstance(targets, (list, tuple)) or any(
                    not isinstance(target, str) or not target for target in targets
                ):
                    raise ValueError("referenceTo must be a list of native API names")
                relationships.setdefault((obj, relationship), set()).update(targets)
        return cls(names, identities, relationships, scope=scope)

    def resolve(self, object_name: str, field_path: str) -> FieldBinding:
        if (
            not isinstance(object_name, str)
            or not object_name
            or not isinstance(field_path, str)
            or not field_path
        ):
            raise ValueError("Field binding requires native object and field names")
        direct = self._definitions.get((object_name, field_path))
        if direct:
            return _binding(direct)
        particles = self._particles.get((object_name, field_path))
        if particles:
            return _binding(particles)
        parts = field_path.split(".")
        for relationship in parts[:-1]:
            targets = self.relationships.get((object_name, relationship), ())
            if not targets:
                return FieldBinding("unresolved")
            if len(targets) != 1:
                return FieldBinding("ambiguous")
            object_name = targets[0]
        return _binding(
            self._definitions.get((object_name, parts[-1]))
            or self._particles.get((object_name, parts[-1]), ())
        )

    def resolve_particle(
        self, object_name: str, parent_name: str, api_name: str
    ) -> FieldBinding:
        return _binding(
            identity
            for identity in self._particles.get((object_name, api_name), ())
            if identity.parent_name == parent_name
        )

    @property
    def containment(self) -> tuple[tuple[FieldIdentity, FieldIdentity], ...]:
        return tuple(
            (parent, particle)
            for particle in self.fields
            if particle.kind == "EntityParticle" and particle.parent_name
            if len(
                self._definitions.get((particle.object_name, particle.parent_name), ())
            )
            == 1
            for parent in self._definitions.get(
                (particle.object_name, particle.parent_name), ()
            )
        )


def resolve_field(
    object_name: str | None,
    field_path: str | None,
    fields: Set[tuple[str, str]],
    relationships: Mapping[tuple[str, str], tuple[str, ...]],
) -> tuple[str, str] | None:
    """Compatibility resolver for existing exact field-set callers."""
    if not isinstance(object_name, str) or not isinstance(field_path, str):
        return None
    if (object_name, field_path) in fields:
        return object_name, field_path
    parts = field_path.split(".")
    for relationship in parts[:-1]:
        targets = relationships.get((object_name, relationship), ())
        if len(targets) != 1:
            return None
        object_name = targets[0]
    return (object_name, parts[-1]) if (object_name, parts[-1]) in fields else None
