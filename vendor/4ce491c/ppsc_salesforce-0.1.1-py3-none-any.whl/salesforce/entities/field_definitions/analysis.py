"""Pure, occurrence-complete field semantics; no graph or SQL dependencies."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal

from salesforce.core.analysis import (
    Connection,
    Declaration,
    Diagnostic,
    Expression,
    NativeDocument,
    ReferenceOccurrence,
    SourceIdentity,
    SourceLocation,
    pointer,
)
from salesforce.core.catalog import (
    CatalogIndex,
    FieldBinding,
    FieldIdentity,
    canonical_field_id,
)
from salesforce.core.formulas import formula_references

__all__ = ["FieldAnalysis", "analyze_field"]


@dataclass(frozen=True)
class FieldAnalysis:
    """Facts own immutable evidence; ``document.export`` returns detached JSON.

    Bindings are (occurrence ID, exact catalog binding) pairs, not assertions
    about runtime execution or SQL support. Without a catalog they are unresolved.
    """

    document: NativeDocument
    source: SourceIdentity
    owner_id: str
    full_name: str | None
    object_name: str | None
    identity: FieldIdentity | None
    declarations: tuple[Declaration, ...]
    references: tuple[ReferenceOccurrence, ...]
    connections: tuple[Connection, ...]
    expressions: tuple[Expression, ...]
    diagnostics: tuple[Diagnostic, ...]
    bindings: tuple[tuple[str, FieldBinding], ...]


def analyze_field(
    metadata: Mapping[str, Any] | None,
    full_name: str | None = None,
    *,
    identity: FieldIdentity | None = None,
    catalog: CatalogIndex | None = None,
    source: SourceIdentity | None = None,
) -> FieldAnalysis:
    """Analyze native CustomField metadata, never a flattened Tooling row.

    Supply ``full_name="Account.Total__c"`` (or an exact ``identity``) when
    metadata's fullName is local/absent. An anonymous root is allowed for native
    rollup inventories; it cannot bind contextual bare fields or claim an object.
    Explicit particle identities preserve their actual parent, never a guessed
    dotted path. Locations are relative to the supplied metadata document.
    String defaultValue operands are Salesforce formulas; nonstrings are literal
    native defaults. Unknown metadata remains available in the document.
    """
    document = NativeDocument(metadata if metadata is not None else {})
    native = document.root
    if full_name is not None and (not isinstance(full_name, str) or not full_name):
        raise ValueError("Field full_name must be a nonempty native name")
    if full_name is None:
        candidate = native.get("fullName")
        full_name = candidate if isinstance(candidate, str) and candidate else None
    if identity is not None:
        qualified = f"{identity.object_name}.{identity.api_name}"
        if full_name is not None and full_name != qualified:
            raise ValueError("Field full_name conflicts with its catalog identity")
        full_name = qualified
    elif full_name:
        obj, separator, name = full_name.partition(".")
        if separator and obj and name:
            identity = FieldIdentity(obj, name)
    object_name = identity.object_name if identity else None
    owner_id = canonical_field_id(identity) if identity else ""
    declarations = [
        Declaration(
            owner_id,
            identity.api_name if identity else full_name or "",
            identity.kind if identity else "FieldDefinition",
            SourceLocation(""),
        )
    ]
    references: list[ReferenceOccurrence] = []
    connections: list[Connection] = []
    expressions: list[Expression] = []
    diagnostics: list[Diagnostic] = []
    bindings: list[tuple[str, FieldBinding]] = []

    def diagnose(
        code: str,
        message: str,
        path: str,
        consequence: Literal[
            "structural", "unsupported", "uninterpreted", "binding"
        ] = "uninterpreted",
    ):
        diagnostics.append(
            Diagnostic(code, message, SourceLocation(path), owner_id, consequence)
        )

    if metadata is None:
        diagnose(
            "incomplete_metadata", "Field metadata was not acquired", "", "structural"
        )
    if identity is None:
        diagnose(
            "missing_field_identity",
            "A qualified field identity is unavailable",
            "",
            "structural",
        )
    else:
        connections.append(
            Connection(
                f"EntityDefinition/{object_name}",
                owner_id,
                "contains",
                "field_defined_on_sobject",
                owner_id,
                SourceLocation(""),
            )
        )
        if identity.kind == "EntityParticle" and identity.parent_name:
            connections.append(
                Connection(
                    canonical_field_id(
                        FieldIdentity(identity.object_name, identity.parent_name)
                    ),
                    owner_id,
                    "contains",
                    "field_particle",
                    owner_id,
                    SourceLocation(""),
                )
            )

    def reference(
        value,
        role: str,
        location: SourceLocation,
        *,
        kind: str = "Field",
        qualified: bool = False,
        syntax: Literal["native", "bare", "merge"] = "native",
    ):
        if value is None or value == "":
            return
        if not isinstance(value, str):
            diagnose(
                "invalid_reference",
                "Native references require strings",
                location.pointer,
                "structural",
            )
            return
        occurrence = ReferenceOccurrence(value, location, owner_id, role, syntax)
        references.append(occurrence)
        if kind != "Field":
            endpoint = f"{kind}/{value}"
        elif value.startswith("$"):
            endpoint = f"FormulaGlobal/{value}"
            diagnose(
                "uninterpreted_global_reference",
                "Global formula references are retained without field binding",
                location.pointer,
            )
        else:
            obj, path = object_name, value
            prefix, dot, tail = value.partition(".")
            if dot and (
                qualified
                or prefix == object_name
                or (catalog is not None and prefix in catalog.objects)
            ):
                obj, path = prefix, tail
            binding = (
                catalog.resolve(obj, path)
                if catalog is not None and obj and path
                else FieldBinding("unresolved")
            )
            bindings.append((occurrence.occurrence_id, binding))
            bound_identity = binding.identity
            endpoint = (
                canonical_field_id(bound_identity)
                if bound_identity is not None
                else f"FieldReference/{obj + '.' if obj else ''}{path}"
            )
            if binding.status != "resolved":
                diagnose(
                    "catalog_unavailable"
                    if catalog is None
                    else f"{binding.status}_field",
                    "Field binding is unavailable"
                    if catalog is None
                    else f"Exact field binding is {binding.status}: {value}",
                    location.pointer,
                    "binding",
                )
            elif bound_identity is not None and bound_identity.kind == "EntityParticle":
                particle = bound_identity
                if particle.parent_name and catalog is not None:
                    parent = catalog.resolve(particle.object_name, particle.parent_name)
                    if parent.identity and parent.identity.kind == "FieldDefinition":
                        connections.append(
                            Connection(
                                canonical_field_id(parent.identity),
                                endpoint,
                                "contains",
                                "field_particle",
                                owner_id,
                                location,
                                (occurrence.occurrence_id,),
                            )
                        )
        connections.append(
            Connection(
                endpoint,
                owner_id,
                "reads",
                role,
                owner_id,
                location,
                (occurrence.occurrence_id,),
            )
        )

    def formula(key, role):
        if key not in native:
            return
        value = native[key]
        location = SourceLocation(pointer(key))
        if not isinstance(value, str):
            expressions.append(Expression(owner_id, location, "salesforce_literal"))
            if key != "defaultValue" and value is not None:
                diagnose(
                    "invalid_formula",
                    "Formula text is not a string",
                    pointer(key),
                    "structural",
                )
            return
        parsed = formula_references(value)
        first = len(references)
        for item in parsed["references"]:
            start, end = item["start"], item["end"]
            reference(
                item["reference"],
                role,
                SourceLocation(pointer(key), start, end),
                syntax="merge" if value[max(0, start - 2) : start] == "{!" else "bare",
            )
        expressions.append(
            Expression(
                owner_id,
                location,
                "salesforce_formula",
                tuple(item.occurrence_id for item in references[first:]),
            )
        )
        for item in parsed["unparsed"]:
            diagnostics.append(
                Diagnostic(
                    "unparsed_formula",
                    "Unsupported native formula notation",
                    SourceLocation(pointer(key), item["start"], item["end"]),
                    owner_id,
                    "uninterpreted",
                )
            )

    for key, role in (
        ("formula", "field_formula"),
        ("defaultValueFormula", "field_default"),
        ("defaultValue", "field_default"),
    ):
        formula(key, role)

    rollup_start = len(references)
    for key, role in (
        ("summarizedField", "rollup_measure"),
        ("summaryForeignKey", "rollup_relationship"),
    ):
        reference(native.get(key), role, SourceLocation(pointer(key)), qualified=True)

    def filters(items, base, role):
        if not isinstance(items, tuple):
            if items is not None:
                diagnose(
                    "invalid_filter_items", "Expected a native list", base, "structural"
                )
            return
        for index, item in enumerate(items):
            path = base + pointer(index)
            if not isinstance(item, Mapping):
                diagnose(
                    "invalid_filter_item",
                    "Expected a native object",
                    path,
                    "structural",
                )
                continue
            first = len(references)
            for key, suffix, kind in (
                ("field", "", "Field"),
                ("valueField", "_value", "Field"),
                ("valueSetName", "_value_set", "GlobalValueSet"),
            ):
                reference(
                    item.get(key),
                    role + suffix,
                    SourceLocation(path + pointer(key)),
                    kind=kind,
                    qualified=True,
                )
            expressions.append(
                Expression(
                    owner_id,
                    SourceLocation(path),
                    "salesforce_filter",
                    tuple(item.occurrence_id for item in references[first:]),
                )
            )
            operation = item.get("operation")
            if (
                not isinstance(operation, str)
                or operation
                not in {
                    "equals",
                    "notEqual",
                    "greaterThan",
                    "greaterOrEqual",
                    "lessThan",
                    "lessOrEqual",
                    "contains",
                    "notContain",
                    "startsWith",
                }
                or item.get("valueField")
                or item.get("valueSetName")
            ):
                diagnose(
                    "unsupported_filter",
                    "Native filter evidence is retained; display translation is unsupported",
                    path,
                    "unsupported",
                )

    filters(
        native.get("summaryFilterItems"), pointer("summaryFilterItems"), "rollup_filter"
    )
    if native.get("summaryOperation") is not None or len(references) > rollup_start:
        expressions.append(
            Expression(
                owner_id,
                SourceLocation(""),
                "salesforce_rollup",
                tuple(item.occurrence_id for item in references[rollup_start:]),
            )
        )
        operation = native.get("summaryOperation")
        if operation is None:
            diagnose(
                "incomplete_rollup",
                "Native rollup dependencies lack an acquired operation",
                "",
                "structural",
            )
        elif not isinstance(operation, str) or operation not in {
            "count",
            "sum",
            "min",
            "max",
            "avg",
        }:
            diagnose(
                "unsupported_rollup_operation",
                "Native rollup operation has no supported display translation",
                pointer("summaryOperation") if "summaryOperation" in native else "",
                "unsupported",
            )

    value_set = native.get("valueSet")
    if isinstance(value_set, Mapping):
        first = len(references)
        for key, role, kind in (
            ("valueSetName", "value_set", "GlobalValueSet"),
            ("controllingField", "controlling_field", "Field"),
        ):
            reference(
                value_set.get(key),
                role,
                SourceLocation(pointer("valueSet", key)),
                kind=kind,
            )
        expressions.append(
            Expression(
                owner_id,
                SourceLocation(pointer("valueSet")),
                "salesforce_value_set",
                tuple(item.occurrence_id for item in references[first:]),
            )
        )
        definition = value_set.get("valueSetDefinition")
        if isinstance(definition, Mapping):
            path = pointer("valueSet", "valueSetDefinition")
            set_id = owner_id + path
            declarations.append(
                Declaration(
                    set_id,
                    "valueSetDefinition",
                    "ValueSetDefinition",
                    SourceLocation(path),
                    owner_id,
                )
            )
            connections.append(
                Connection(
                    owner_id,
                    set_id,
                    "contains",
                    "inline_value_set",
                    owner_id,
                    SourceLocation(path),
                )
            )
            values = definition.get("value", ())
            if isinstance(values, tuple):
                for index, value in enumerate(values):
                    location = SourceLocation(path + pointer("value", index))
                    if not isinstance(value, Mapping):
                        diagnose(
                            "invalid_value",
                            "Expected a native value object",
                            location.pointer,
                            "structural",
                        )
                        continue
                    value_id = owner_id + location.pointer
                    name = value.get("fullName")
                    declarations.append(
                        Declaration(
                            value_id,
                            name if isinstance(name, str) else "",
                            "CustomValue",
                            location,
                            set_id,
                        )
                    )
                    connections.append(
                        Connection(
                            set_id,
                            value_id,
                            "contains",
                            "value_set_value",
                            owner_id,
                            location,
                        )
                    )
                    if value.get("default") is True:
                        connections.append(
                            Connection(
                                value_id,
                                owner_id,
                                "reads",
                                "value_set_default",
                                owner_id,
                                SourceLocation(location.pointer + "/default"),
                            )
                        )
            if value_set.get("valueSetName"):
                diagnose(
                    "conflicting_value_set",
                    "Both inline and global value sets supplied",
                    pointer("valueSet"),
                    "structural",
                )
    elif value_set is not None:
        diagnose(
            "invalid_value_set",
            "Expected native value-set metadata",
            pointer("valueSet"),
            "structural",
        )

    for key in ("metadataRelationshipControllingField", "referenceTargetField"):
        reference(native.get(key), key, SourceLocation(pointer(key)))
    targets = native.get("referenceTo")
    if isinstance(targets, str):
        reference(
            targets,
            "references_object",
            SourceLocation(pointer("referenceTo")),
            kind="EntityDefinition",
        )
    elif isinstance(targets, tuple):
        for index, target in enumerate(targets):
            reference(
                target,
                "references_object",
                SourceLocation(pointer("referenceTo", index)),
                kind="EntityDefinition",
            )
    lookup = native.get("lookupFilter")
    if isinstance(lookup, Mapping):
        filters(
            lookup.get("filterItems"),
            pointer("lookupFilter", "filterItems"),
            "lookup_filter",
        )
    elif lookup is not None:
        diagnose(
            "invalid_lookup_filter",
            "Expected native lookup-filter metadata",
            pointer("lookupFilter"),
            "structural",
        )

    return FieldAnalysis(
        document,
        source or SourceIdentity(),
        owner_id,
        full_name,
        object_name,
        identity,
        tuple(declarations),
        tuple(references),
        tuple(connections),
        tuple(expressions),
        tuple(diagnostics),
        tuple(bindings),
    )
