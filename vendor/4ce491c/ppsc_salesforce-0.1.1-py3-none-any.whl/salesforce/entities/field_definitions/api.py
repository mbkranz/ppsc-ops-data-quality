"""Selected native field/component downloads and metadata enrichment reads."""

import json
import os
from collections.abc import Sequence
from hashlib import sha256
from pathlib import Path
from tempfile import NamedTemporaryFile

from pydantic import BaseModel, ConfigDict, Field, computed_field

from salesforce import soql_templates
from salesforce.client import query_records
from salesforce.entities.object_definitions.api import (
    UNAVAILABLE_PROPERTIES,
    fetch_entity_definitions,
)

__all__ = ["ApiExportReceipt", "download_api_export", "field_definition_metadata"]


class ApiExportReceipt(BaseModel):
    """Identity and counts of one completely written native JSON capture."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    path: Path
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    object_names: tuple[str, ...] = Field(min_length=1)
    field_count: int = Field(ge=0)
    particle_count: int = Field(ge=0)

    @computed_field
    @property
    def object_count(self) -> int:
        return len(self.object_names)


def _native_definition(record: dict, context: str, *, particle: bool = False) -> None:
    """Reject omitted/unavailable evidence without interpreting native types."""
    if record.get(UNAVAILABLE_PROPERTIES):
        raise ValueError(f"Unavailable native field evidence for {context}")
    required = {"DurableId", "DataType", "Length", "Precision", "Scale", "IsCompound"}
    if particle:
        required.add("IsComponent")
    if not required.issubset(record) or any(
        not isinstance(record.get(name), str) or not record[name]
        for name in ("DurableId", "DataType")
    ):
        raise ValueError(f"Missing native field identity/type evidence for {context}")


def download_api_export(
    client, object_names: Sequence[str], *, output_path: Path | str
) -> ApiExportReceipt:
    """Download selected native definitions into one new JSON file.

    The saved list retains EntityDefinition records with their complete native
    Fields and Particles query envelopes, including type/component evidence.
    The existing selected acquisition owns query pagination and recovery. Reads
    and incomplete selections fail explicitly; no partial capture is published.
    Existing paths are never overwritten, including a concurrently created path.
    No extra identity requests, source normalization or schema compilation occur.
    """
    if isinstance(object_names, str):
        raise ValueError("Select a collection of object API names")
    names = tuple(object_names)
    if not names:
        raise ValueError("Select at least one object API name")
    destination = Path(output_path)
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(destination)
    selected = fetch_entity_definitions(
        client,
        names,
        template=soql_templates.tooling.by_entity.EntityDefinition.by_names,
    )
    returned = [record["QualifiedApiName"] for record in selected.records]
    if (
        selected.unresolved
        or len(returned) != len(names)
        or set(returned) != set(names)
    ):
        raise ValueError("Selected object definitions are unavailable or mismatched")
    field_count = particle_count = 0
    for record in selected.records:
        name = record["QualifiedApiName"]
        if not isinstance(record.get("DurableId"), str) or not record["DurableId"]:
            raise ValueError(f"Missing native object identity for {name}")
        fields = query_records([record["Fields"]], f"{name}.Fields")
        field_count += len(fields)
        for field in fields:
            context = name + "." + field["QualifiedApiName"]
            _native_definition(field, context)
            particles = query_records([field["Particles"]], context + ".Particles")
            particle_count += len(particles)
            for particle in particles:
                _native_definition(
                    particle,
                    context + "." + particle["QualifiedApiName"],
                    particle=True,
                )
    payload = (
        json.dumps(selected.records, ensure_ascii=False, indent=2, allow_nan=False)
        + "\n"
    ).encode("utf-8")
    receipt = ApiExportReceipt(
        path=destination,
        sha256=sha256(payload).hexdigest(),
        object_names=names,
        field_count=field_count,
        particle_count=particle_count,
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with NamedTemporaryFile(
            dir=destination.parent, prefix=f".{destination.name}.", delete=False
        ) as file:
            temporary = Path(file.name)
            file.write(payload)
            file.flush()
            os.fsync(file.fileno())
        os.link(temporary, destination)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    return receipt


def field_definition_metadata(salesforce_client, durableid=None, fullname=None):
    if fullname:
        objectname, fieldname = fullname.split(".", 1)
        custom_fields = (
            soql_templates.tooling.by_entity.FieldDefinition.metadata_by_name.format(
                object_name=objectname, field_name=fieldname
            )
        )

    elif durableid:
        custom_fields = (
            soql_templates.tooling.by_entity.FieldDefinition.metadata_by_id.format(
                id=durableid
            )
        )
    else:
        raise ValueError("Either fullname+fieldname or durableid must be provided")

    response = salesforce_client.query(custom_fields, use_tooling_api=True)
    return response
