"""Native roll-up dependencies, independent of display SQL support."""

import math

from sqlglot import ErrorLevel, exp

AGGREGATE_BUILDERS = {
    "count": exp.Count,
    "sum": exp.Sum,
    "min": exp.Min,
    "max": exp.Max,
    "avg": exp.Avg,
}

COMPARISON_BUILDERS = {
    "equals": exp.EQ,
    "notEqual": exp.NEQ,
    "greaterThan": exp.GT,
    "greaterOrEqual": exp.GTE,
    "lessThan": exp.LT,
    "lessOrEqual": exp.LTE,
}


def _qualified_field(name) -> exp.Column | None:
    if not isinstance(name, str):
        return None
    parts = name.split(".")
    if len(parts) != 2 or not all(parts):
        return None
    return exp.column(parts[1], table=parts[0], quoted=True)


def _filter_expression(item) -> exp.Expression | None:
    column = _qualified_field(item.get("field"))
    value = item.get("value")
    if (
        column is None
        or item.get("valueField")
        or item.get("valueSetName")
        or not isinstance(value, (str, int, float, bool))
        or (isinstance(value, float) and not math.isfinite(value))
    ):
        return None
    operation = item.get("operation")
    if operation in COMPARISON_BUILDERS:
        return COMPARISON_BUILDERS[operation](
            this=column, expression=exp.convert(value)
        )
    if not isinstance(value, str):
        return None
    literal = exp.Literal.string(value)
    if operation == "startsWith":
        return exp.StartsWith(this=column, expression=literal)
    if operation in ("contains", "notContain"):
        predicate = exp.GT(
            this=exp.StrPosition(this=column, substr=literal),
            expression=exp.Literal.number(0),
        )
        return exp.Not(this=predicate) if operation == "notContain" else predicate
    return None


def rollup_expression(metadata, full_name) -> str | None:
    """Render a display SQL tree, or None when native semantics are unsupported.

    Field/value-set operands and collection/range filters need explicit mappings.
    Reference extraction must still use ``rollup_references``. This display does
    not establish physical bindings or executable Salesforce equivalence.
    """
    operation = metadata.get("summaryOperation")
    aggregate = AGGREGATE_BUILDERS.get(operation)
    parent_field = _qualified_field(full_name)
    aggregate_field = _qualified_field(
        metadata.get("summarizedField")
        or (metadata.get("summaryForeignKey") if operation == "count" else None)
    )
    if aggregate is None or aggregate_field is None or parent_field is None:
        return None
    conditions = []
    if metadata.get("summaryForeignKey"):
        foreign_key = _qualified_field(metadata["summaryForeignKey"])
        if foreign_key is None or foreign_key.table != aggregate_field.table:
            return None
        conditions.append(
            exp.EQ(
                this=exp.column("Id", table=parent_field.table, quoted=True),
                expression=foreign_key,
            )
        )
    for item in metadata.get("summaryFilterItems") or []:
        predicate = _filter_expression(item)
        if predicate is None:
            return None
        conditions.append(predicate)
    query = exp.select(aggregate(this=aggregate_field)).from_(
        exp.Table(this=exp.to_identifier(aggregate_field.table, quoted=True))
    )
    if conditions:
        query = query.where(exp.and_(*conditions))
    return query.sql(
        dialect="postgres", pretty=True, unsupported_level=ErrorLevel.RAISE
    )


def rollup_references(metadata):
    """Project legacy rollup names/order from the shared native occurrence facts."""
    from .analysis import analyze_field

    roles = {
        "rollup_measure": "summarizes_field",
        "rollup_relationship": "rollup_relationship",
        "rollup_filter": "rollup_filter",
        "rollup_filter_value": "rollup_filter",
    }
    for occurrence in analyze_field(metadata).references:
        if occurrence.role in roles:
            yield (
                occurrence.reference,
                roles[occurrence.role],
                occurrence.location.pointer,
            )
