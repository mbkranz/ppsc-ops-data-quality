"""Immutable native Flow semantics, independent of models and graph/SQL engines.

The presentation descriptors are the short-lived legacy projection, not another
extractor. Canonical connections and their occurrences remain separate facts.
"""

from __future__ import annotations

import json
import re
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime
from types import MappingProxyType
from typing import Any, Literal

from salesforce.core.analysis import (
    Connection,
    ConnectionFamily,
    Declaration,
    Diagnostic,
    Expression,
    NativeDocument,
    ReferenceOccurrence,
    SourceIdentity,
    SourceLocation,
    pointer,
)
from salesforce.core.formulas import formula_references


ELEMENT_KINDS = {
    "variables": "FlowVariable",
    "formulas": "FlowFormula",
    "constants": "FlowConstant",
    "stages": "FlowStage",
    "choices": "FlowChoice",
    "dynamicChoiceSets": "FlowDynamicChoiceSet",
    "textTemplates": "FlowTextTemplate",
    "start": "FlowStart",
    "decisions": "FlowDecision",
    "assignments": "FlowAssignment",
    "waits": "FlowWait",
    "transforms": "FlowTransform",
    "loops": "FlowLoop",
    "screens": "FlowScreen",
    "subflows": "FlowSubFlow",
    "apexPluginCalls": "FlowApexPluginCall",
    "recordUpdates": "FlowRecordUpdate",
    "recordCreates": "FlowRecordCreate",
    "recordDeletes": "FlowRecordDelete",
    "actionCalls": "FlowActionCall",
    "recordLookups": "FlowRecordLookup",
    "recordRollbacks": "FlowRecordRollback",
    "collectionProcessors": "FlowCollectionProcessor",
}
RESOURCE_COLLECTIONS = {"variables", "constants", "formulas", "choices"}
RECORD_KINDS = {
    key: ELEMENT_KINDS[key]
    for key in (
        "recordLookups",
        "recordUpdates",
        "recordCreates",
        "recordDeletes",
        "collectionProcessors",
        "start",
    )
}
FORMULA_KEYS = {"expression", "formula", "filterFormula", "formulaExpression"}
REFERENCE_KEYS = {
    "actionName",
    "flowName",
    "apexClass",
    "extensionName",
    "sourceTemplateApiName",
    "object",
    "field",
    "sortField",
    "recordField",
    "displayField",
    "valueField",
    "picklistField",
    "outputFieldApiName",
}


@dataclass(frozen=True)
class StructuralEntry:
    location: SourceLocation
    owner_id: str
    owner_name: str


@dataclass(frozen=True)
class ExpressionEntry:
    expression: Expression
    kind: str
    key: str = ""
    known: bool = True


@dataclass(frozen=True)
class NodeView:
    name: str
    owner_id: str
    kind: str
    style: str = "element"
    attributes: Mapping[str, Any] | None = None


@dataclass(frozen=True)
class EdgeView:
    source: str
    target: str
    key: str | None
    owner_id: str
    attributes: Mapping[str, Any]
    connection_id: str
    occurrence_ids: tuple[str, ...] = ()
    legacy_occurrence_ids: tuple[str, ...] = ()


@dataclass(frozen=True)
class FlowEndpoint:
    namespace: str
    native_name: str


@dataclass(frozen=True)
class ConnectionTraits:
    structural: bool = False
    synthetic_projection: bool = False


@dataclass(frozen=True)
class FlowAnalysis:
    document: NativeDocument
    source: SourceIdentity
    declarations: tuple[Declaration, ...]
    occurrences: tuple[ReferenceOccurrence, ...]
    connections: tuple[Connection, ...]
    diagnostics: tuple[Diagnostic, ...]
    elements: Mapping[str, tuple[str, int, str]]
    control_targets: Mapping[str, tuple[str, ...]]
    connector_targets: Mapping[str, str]
    entry_paths: Mapping[str, tuple[str | None, ...]]
    record_types: Mapping[str, str]
    entries: tuple[StructuralEntry, ...]
    expressions: tuple[ExpressionEntry, ...]
    node_views: tuple[NodeView, ...]
    edge_views: tuple[EdgeView, ...]
    objects: frozenset[str]
    views: tuple[NodeView | EdgeView, ...]
    duplicate_names: frozenset[str]
    endpoints: Mapping[str, FlowEndpoint]
    connection_traits: Mapping[str, ConnectionTraits]


def _frozen(value):
    return NativeDocument(value).root


def format_value(value: Any) -> dict[str, Any]:
    """The legacy value presentation, including false, zero, empty and NULL."""
    value = value or {}
    formatted: dict[str, Any] = {}
    for key in (
        "apexValue",
        "complexValue",
        "transformReference",
        "booleanValue",
        "complexValueType",
        "elementReference",
        "dateTimeValue",
        "dateValue",
        "numberValue",
        "stringValue",
    ):
        item = value.get(key)
        if item is None:
            continue
        if key == "numberValue":
            item = float(item)
        if key.endswith("Type"):
            formatted[key.replace("Type", "_type")] = item
        elif key.endswith("Value"):
            if key == "dateTimeValue" and isinstance(item, str):
                item = datetime.fromisoformat(item).isoformat().replace("+00:00", "Z")
            formatted.update(kind="literal", literal_type=key[:-5].lower(), value=item)
        elif key.endswith("Reference"):
            formatted.update(
                kind="reference", reference_type=key[:-9].lower(), value=item
            )
    if not formatted:
        formatted = dict(kind="literal", literal_type="null", value=None)
    if formatted["kind"] == "reference":
        name = formatted["value"]
    elif formatted["literal_type"] == "string":
        name = f"Literal[{json.dumps(formatted['value'])}]"
    elif formatted["literal_type"] == "apex":
        name = "ApexClass[" + ",".join(formatted["value"]) + "]"
    elif formatted["literal_type"] == "complex":
        name = f"{formatted.get('complexValue_type', 'complex')}({formatted['value']})"
    elif formatted["literal_type"] == "datetime":
        name = f"Literal[{datetime.fromisoformat(str(formatted['value']))}]"
    else:
        name = f"Literal[{formatted['value']}]"
    return dict(name=name, **formatted)


class _Builder:
    def __init__(self, document, source):
        self.document, self.source = document, source
        self.declarations, self.occurrences, self.connections = [], [], []
        self.diagnostics, self.entries, self.expressions = [], [], []
        self.nodes, self.edges, self.views = [], [], []
        self.elements, self.control, self.connectors, self.paths = {}, {}, {}, {}
        self.records, self.objects = {}, set()
        self.by_path, self.names, self.owner_names = {}, {}, {}
        self.duplicate_names = set()
        self.endpoints, self.connection_traits = {}, {}

    def endpoint(self, name, namespace):
        if namespace == "local" or (
            namespace == "reference" and "." not in name and name in self.names
        ):
            local = self.names.get(name)
            if local is not None:
                return local
        local = pointer("$endpoints", namespace, name)
        self.endpoints[local] = FlowEndpoint(namespace, name)
        return local

    def connect(self, *args, structural=False, synthetic_projection=False):
        connection = Connection(*args)
        self.connections.append(connection)
        self.connection_traits[connection.connection_id] = ConnectionTraits(
            structural, synthetic_projection
        )
        return connection

    def evidence_paths(self, path):
        return tuple(
            candidate
            for candidate in self.by_path
            if candidate == path or candidate.startswith(path + "/")
        )

    def diagnostic(
        self,
        code,
        message,
        path,
        owner,
        consequence: Literal[
            "structural", "unsupported", "uninterpreted", "binding"
        ] = "unsupported",
        *,
        start=None,
        end=None,
    ):
        self.diagnostics.append(
            Diagnostic(
                code, message, SourceLocation(path, start, end), owner, consequence
            )
        )

    def declare(self, name, kind, path, parent=None):
        if not isinstance(name, str) or not name:
            self.diagnostic(
                "missing-declaration-name",
                "Element has no native name",
                path,
                path,
                "structural",
            )
            return
        if name in self.names:
            self.duplicate_names.add(name)
            original = self.names[name]
            self.diagnostic(
                "duplicate-declaration",
                f"Duplicate Flow declaration: {name}",
                path,
                path,
                "structural",
            )
            if not any(
                item.code == "duplicate-declaration"
                and item.location.pointer == original
                for item in self.diagnostics
            ):
                self.diagnostic(
                    "duplicate-declaration",
                    f"Duplicate Flow declaration: {name}",
                    original,
                    original,
                    "structural",
                )
        self.names.setdefault(name, path)
        self.owner_names[path] = name
        self.endpoints[path] = FlowEndpoint("local", name)
        if parent is not None:
            parent = max(
                (
                    declaration.local_id
                    for declaration in self.declarations
                    if parent == declaration.local_id
                    or parent.startswith(declaration.local_id + "/")
                ),
                key=len,
                default=None,
            )
        self.declarations.append(
            Declaration(path, name, kind, SourceLocation(path), parent)
        )
        if parent is not None:
            self.connect(
                parent,
                path,
                "contains",
                "declares",
                parent,
                SourceLocation(path),
                structural=True,
            )

    def occurrence(
        self,
        reference,
        path,
        owner,
        role,
        start=None,
        end=None,
        syntax: Literal["native", "bare", "merge"] = "native",
    ):
        item = ReferenceOccurrence(
            reference, SourceLocation(path, start, end), owner, role, syntax
        )
        self.occurrences.append(item)
        self.by_path.setdefault(path, []).append(item)

    def inventory(self, value, path="", owner="", owner_name=""):
        if isinstance(value, Mapping):
            name = value.get("name")
            if name:
                owner_name = (
                    f"{owner_name}.{name}" if owner_name and "/rules/" in path else name
                )
            if path in self.owner_names:
                owner = path
            self.entries.append(
                StructuralEntry(SourceLocation(path), owner, owner_name)
            )
            for key, child in value.items():
                child_path = path + pointer(key)
                if isinstance(child, str):
                    if key.endswith("Reference") or key in REFERENCE_KEYS:
                        self.occurrence(child, child_path, owner, key)
                    elif key in FORMULA_KEYS:
                        scanned = formula_references(child)
                        for item in scanned["references"]:
                            start, end = item["start"], item["end"]
                            syntax = (
                                "merge"
                                if child[max(0, start - 2) : start] == "{!"
                                else "bare"
                            )
                            self.occurrence(
                                item["reference"],
                                child_path,
                                owner,
                                key,
                                start,
                                end,
                                syntax,
                            )
                        for item in scanned["unparsed"]:
                            self.diagnostic(
                                "unparsed_formula",
                                "Unsupported native formula notation",
                                child_path,
                                owner,
                                "uninterpreted",
                                start=item["start"],
                                end=item["end"],
                            )
                        known = path.startswith("/formulas/") or key != "expression"
                        self.expressions.append(
                            ExpressionEntry(
                                Expression(
                                    owner,
                                    SourceLocation(child_path),
                                    "salesforce_formula" if known else "unknown",
                                    tuple(
                                        o.occurrence_id
                                        for o in self.by_path.get(child_path, ())
                                    ),
                                ),
                                "formula",
                                key,
                                known,
                            )
                        )
                elif key in {"queriedFields", "choiceReferences"} and isinstance(
                    child, tuple
                ):
                    for index, reference in enumerate(child):
                        if isinstance(reference, str):
                            self.occurrence(
                                reference, child_path + pointer(index), owner, key
                            )
                if key in {"conditions", "filters"} and child:
                    self.expressions.append(
                        ExpressionEntry(
                            Expression(
                                owner, SourceLocation(child_path), "flow_condition"
                            ),
                            "condition",
                            key,
                            path.split("/")[1] in ELEMENT_KINDS if path else False,
                        )
                    )
                if key.lower().endswith("connector") and isinstance(child, Mapping):
                    target = child.get("targetReference")
                    if isinstance(target, str):
                        self.connectors[child_path] = target
                self.inventory(child, child_path, owner, owner_name)
        elif isinstance(value, tuple):
            for index, child in enumerate(value):
                self.inventory(child, path + pointer(index), owner, owner_name)

    def node(self, node_name, owner, kind, style="element", **attrs):
        view = NodeView(node_name, owner, kind, style, _frozen(attrs))
        self.nodes.append(view)
        self.views.append(view)

    def read(self, dependency, consumer, key, role, owner, **kwargs):
        """Handlers name the dependency and consumer explicitly, in that order."""
        kwargs.setdefault("source_kind", "reference")
        kwargs.setdefault("target_kind", "local")
        self.emit(dependency, consumer, key, role, owner, family="reads", **kwargs)

    def emit(
        self,
        source,
        target,
        key,
        relation,
        owner,
        *,
        family: ConnectionFamily,
        canonical_source=None,
        canonical_target=None,
        source_kind=None,
        target_kind=None,
        occurrence_paths=None,
        structural=False,
        synthetic_projection=False,
        path=None,
        ref_path=None,
        reference_endpoint=None,
        legacy_path=None,
        occurrence=None,
        **attrs,
    ):
        if source is None or target is None:
            self.diagnostic(
                "missing-edge-endpoint",
                "Connection has no endpoint",
                path or owner,
                owner,
                "structural",
            )
            return
        path = path or owner
        occurrences = (
            (occurrence,)
            if occurrence
            else tuple(
                item
                for evidence_path in (
                    occurrence_paths
                    if occurrence_paths is not None
                    else (ref_path or path,)
                )
                for item in self.by_path.get(evidence_path, ())
            )
        )
        ids = tuple(o.occurrence_id for o in occurrences)
        canonical_owner = max(
            (
                declaration.local_id
                for declaration in self.declarations
                if path == declaration.local_id
                or path.startswith(declaration.local_id + "/")
            ),
            key=len,
            default=owner,
        )
        semantic_source = source if canonical_source is None else canonical_source
        semantic_target = target if canonical_target is None else canonical_target
        if family == "writes":
            semantic_source = canonical_owner
        else:
            semantic_source = self.endpoint(semantic_source, source_kind or "local")
        semantic_target = self.endpoint(
            semantic_target,
            target_kind
            or (
                "local"
                if family in {"control", "contains"}
                else "callable"
                if family == "invokes"
                else "reference"
            ),
        )
        if family == "contains":
            declaration = next(
                (
                    item
                    for item in self.declarations
                    if item.local_id == semantic_target
                ),
                None,
            )
            if declaration and declaration.owner_id is not None:
                semantic_source = canonical_owner = declaration.owner_id
        connection = self.connect(
            semantic_source,
            semantic_target,
            family,
            relation,
            canonical_owner,
            occurrence.location if occurrence else SourceLocation(path),
            ids,
            structural=structural,
            synthetic_projection=synthetic_projection,
        )
        if reference_endpoint:
            attrs.update(
                reference_path=ref_path.removeprefix(owner) if ref_path else None,
                reference_endpoint=reference_endpoint,
            )
        attrs["relation"] = relation
        if legacy_path is not None:
            attrs["path"] = legacy_path
        parts = owner.split("/")
        legacy_owner = "/".join(parts[:2] if parts[1] == "start" else parts[:3])
        endpoints = {
            attrs.get("source_reference", source),
            attrs.get("target_reference", target),
        }
        legacy_reference_path = attrs.get("reference_path")
        legacy_ids = tuple(
            item.occurrence_id
            for item in self.occurrences
            if (
                item.location.pointer.startswith(legacy_owner + "/")
                and (
                    item.location.pointer == legacy_owner + legacy_reference_path
                    if legacy_reference_path is not None
                    else item.reference in endpoints
                )
            )
        )
        view = EdgeView(
            source,
            target,
            key,
            owner,
            _frozen(attrs),
            connection.connection_id,
            ids,
            legacy_ids,
        )
        self.edges.append(view)
        self.views.append(view)

    def connector(
        self,
        name,
        owner,
        value,
        prop="connector",
        relation="navigates_to",
        *,
        stop=False,
        location_path=None,
        **attrs,
    ):
        attrs.pop("label", None)
        path = location_path or owner + "/" + re.sub(
            r"\[(\d+)\]", r"/\1", prop
        ).replace(".", "/")
        target = value.get("targetReference") if isinstance(value, Mapping) else None
        if target is None:
            if not stop:
                return
            target = "STOP"
            path = owner
            self.node("STOP", owner, "FlowStopConnector", "terminal")
        self.emit(
            name,
            target,
            name + "." + prop,
            relation,
            owner,
            family="control",
            target_kind="local" if value is not None else "terminal",
            occurrence_paths=(path + "/targetReference",) if value is not None else (),
            synthetic_projection=target == "STOP" and value is None,
            path=path,
            **attrs,
        )

    def value_edge(self, value, target, key, relation, owner, value_path, **attrs):
        formatted = format_value(value)
        ref = (
            value_path + "/" + formatted["reference_type"] + "Reference"
            if formatted["kind"] == "reference"
            else None
        )
        self.read(
            formatted["name"],
            target,
            key,
            relation,
            owner,
            path=value_path,
            ref_path=ref,
            reference_endpoint="source",
            source_kind="reference" if formatted["kind"] == "reference" else "literal",
            structural=formatted["kind"] == "literal",
            **attrs,
        )
        return formatted

    def filters(self, node, owner):
        name = node["name"]
        obj = node.get("object") or node.get("inputReference")
        for i, condition in enumerate(node.get("filters") or ()):
            path = owner + pointer("filters", i)
            value = format_value(condition.get("value"))
            self.value_edge(
                condition.get("value"),
                name,
                f"{name}.filters[{i}].value",
                "read_resource_into",
                owner,
                path + "/value",
                attrs=value,
                note=["`attrs` is a formatted FlowElementReferenceOrValue instance"],
            )
            field = condition.get("field")
            self.read(
                f"{obj}.{field}" if field else obj,
                name,
                f"{name}.filters[{i}]",
                "read_resource_into",
                owner,
                path=path + "/field",
                ref_path=path + "/field",
                reference_endpoint="source",
                source_reference=field,
                source_kind=("field" if field else "object")
                if node.get("object")
                else "reference",
            )

    def conditions(
        self, conditions, name, owner, path, prefix="conditions", collection=False
    ):
        for i, condition in enumerate(conditions or ()):
            local = path + pointer(i)
            key = f"{prefix}[{i}]"
            if collection:
                self.conditions(
                    condition.get("conditions"),
                    name,
                    owner,
                    local + "/conditions",
                    key,
                    True,
                )
            if condition.get("leftValueReference"):
                self.read(
                    condition["leftValueReference"],
                    name,
                    f"{name}.{key}.leftValueReference",
                    "read_resource_into" if collection else "read_condition_resource",
                    owner,
                    path=local + "/leftValueReference",
                )
            if "rightValue" in condition:
                value = format_value(condition["rightValue"])
                self.read(
                    value["name"],
                    name,
                    f"{name}.{key}.rightValue",
                    "read_resource_into" if collection else "read_condition_resource",
                    owner,
                    path=local + "/rightValue",
                    attrs=value,
                    source_kind="reference"
                    if value["kind"] == "reference"
                    else "literal",
                    occurrence_paths=self.evidence_paths(local + "/rightValue"),
                    structural=value["kind"] == "literal",
                )
            if not collection:
                self.conditions(
                    condition.get("conditions"),
                    name,
                    owner,
                    local + "/conditions",
                    key + ".conditions",
                )

    def formula(self, name, owner, prop, relation, prefix=None, **attrs):
        for occurrence in self.by_path.get(owner + pointer(prop), ()):
            self.read(
                occurrence.reference,
                name,
                (prefix or name + "." + prop + ".") + occurrence.reference,
                relation,
                owner,
                path=owner + pointer(prop),
                occurrence=occurrence,
                **attrs,
            )

    def inputs(self, node, owner, name=None):
        name = name or node["name"]
        for prop in ("inputParameters", "inputAssignments"):
            for i, parameter in enumerate(node.get(prop) or ()):
                value = format_value(parameter.get("value"))
                self.value_edge(
                    parameter.get("value"),
                    name,
                    name + "." + prop + "." + parameter["name"],
                    "read_input_resource_into",
                    owner,
                    owner + pointer(prop, i, "value"),
                    attrs=value,
                )

    def outputs(self, node, owner, automatic=False, name=None):
        name = name or node["name"]
        for prop in ("outputParameters", "outputAssignments"):
            for i, parameter in enumerate(node.get(prop) or ()):
                notes = (
                    [
                        "available for reference in other flow elements (storeOutputAutomatically=true)"
                    ]
                    if automatic
                    else []
                )
                target = parameter.get("assignToReference")
                if target:
                    ref_path = owner + pointer(prop, i, "assignToReference")
                    self.emit(
                        name,
                        target,
                        name + "." + prop + "." + parameter["name"],
                        "assign_output_resource_to",
                        owner,
                        family="writes",
                        path=ref_path,
                        ref_path=ref_path,
                        reference_endpoint="target",
                        notes=notes,
                    )
                elif automatic:
                    self.emit(
                        name,
                        name + "." + parameter["name"],
                        name + "." + prop + "." + parameter["name"],
                        "assign_output_resource_to",
                        owner,
                        family="writes",
                        path=owner + pointer(prop, i),
                        notes=notes,
                        structural=True,
                    )
                else:
                    self.diagnostic(
                        "legacy-output-without-target",
                        f"OutputParameter {parameter['name']} must have either assignToReference or storeOutputAutomatically=true to create an edge",
                        owner + pointer(prop, i),
                        owner,
                    )

    def parameters(self, parameters, name, owner, path, output=False, **attrs):
        for i, parameter in enumerate(parameters or ()):
            local = path + pointer(i)
            pname = f"Parameter[{name}.{parameter['name']}]"
            if output:
                if not parameter.get("assignToReference"):
                    continue
                self.node(
                    pname,
                    owner,
                    "Parameter",
                    "parameter",
                    parameter_kind="output",
                    name=parameter["name"],
                )
                self.emit(
                    name,
                    pname,
                    None,
                    "maps_output",
                    owner,
                    family="writes",
                    path=local,
                    edge_type="maps_output",
                    param_name=parameter["name"],
                    target_kind="parameter",
                    structural=True,
                )
                self.emit(
                    pname,
                    parameter["assignToReference"],
                    None,
                    "writes_resource",
                    owner,
                    family="writes",
                    path=local + "/assignToReference",
                    edge_type="writes_resource",
                    param_name=parameter["name"],
                )
            else:
                value = format_value(parameter.get("value"))
                source = value.pop("name")
                self.read(
                    source,
                    pname,
                    None,
                    "reads_resource",
                    owner,
                    path=local + "/value",
                    edge_type="reads_resource",
                    param_name=parameter["name"],
                    source_kind="reference"
                    if value["kind"] == "reference"
                    else "literal",
                    target_kind="parameter",
                    occurrence_paths=self.evidence_paths(local + "/value"),
                    structural=value["kind"] == "literal",
                    **value,
                )
                self.node(
                    pname,
                    owner,
                    "Parameter",
                    "parameter",
                    parameter_kind="input",
                    name=parameter["name"],
                )
                self.read(
                    pname,
                    name,
                    None,
                    "maps_input",
                    owner,
                    path=local,
                    edge_type="maps_input",
                    param_name=parameter["name"],
                    source_kind="parameter",
                    structural=True,
                    **attrs,
                )

    def element(self, collection, node, owner):
        kind = ELEMENT_KINDS[collection]
        name = node.get("name") or ("start" if collection == "start" else None)
        if name is None:
            return
        style = "flat" if collection in {"waits", "transforms"} else "element"
        self.node(name, owner, kind, style)
        if collection in {"dynamicChoiceSets", "textTemplates"}:
            return
        if collection == "stages":
            if node.get("steps"):
                self.diagnostic(
                    "legacy-stage-steps",
                    "'FlowStage' object has no attribute 'inputParameters'",
                    owner + "/steps",
                    owner,
                )
            return
        if collection == "recordRollbacks":
            self.diagnostic(
                "legacy-record-rollback",
                "FlowRecordRollback is not implemented yet.",
                owner,
                owner,
            )
            return
        if collection in {"variables", "constants", "choices"}:
            if collection in {"variables", "choices"} and "value" not in node:
                self.diagnostic(
                    "legacy-missing-value",
                    "'NoneType' object has no attribute 'format_values'",
                    owner + "/value",
                    owner,
                )
            if collection == "variables" and node.get("apexClass"):
                self.emit(
                    name,
                    node["apexClass"],
                    name + ".apexClass",
                    "assign_callable_as",
                    owner,
                    family="invokes",
                    target_kind="apex",
                    path=owner + "/apexClass",
                )
            value = format_value(node.get("value"))
            attrs = {}
            relation = {
                "variables": "define_variable_as",
                "constants": "define_constant_as",
                "choices": "define_choice_as",
            }[collection]
            if collection != "variables":
                if collection == "choices":
                    value.update(
                        label=node.get("choiceText"),
                        description=node.get("description"),
                    )
                attrs["attrs"] = value
            self.read(
                value["name"],
                name,
                name + ".value",
                relation,
                owner,
                path=owner + "/value" if "value" in node else owner,
                source_kind="reference" if value["kind"] == "reference" else "literal",
                occurrence_paths=self.evidence_paths(owner + "/value"),
                structural=value["kind"] == "literal" and "value" in node,
                synthetic_projection="value" not in node,
                **attrs,
            )
            return
        if collection == "formulas":
            self.formula(
                name,
                owner,
                "expression",
                "get_formula_references",
                prefix=name + ".formula.",
                note="Edges remove the $ designating current context",
            )
            return
        if collection == "start":
            if node.get("object"):
                self.read(
                    node["object"],
                    name,
                    name + ".object",
                    "trigger_context",
                    owner,
                    path=owner + "/object",
                    source_kind="object",
                )
            for i, value in enumerate(node.get("inputs") or ()):
                formatted = format_value(value)
                self.read(
                    formatted["name"],
                    name,
                    f"{name}.inputs[{i}]",
                    "start:input_value",
                    owner,
                    path=owner + pointer("inputs", i),
                    attrs=formatted,
                    source_kind="reference"
                    if formatted["kind"] == "reference"
                    else "literal",
                    occurrence_paths=self.evidence_paths(owner + pointer("inputs", i)),
                    structural=formatted["kind"] == "literal",
                )
            self.connector(name, owner, node.get("connector"))
            self.filters(dict(node, name=name), owner)
            self.formula(name, owner, "filterFormula", "get_current_context_references")
            for i, scheduled in enumerate(node.get("scheduledPaths") or ()):
                path = owner + pointer("scheduledPaths", i)
                obj = node.get("object")
                if obj:
                    source = (
                        f"{obj}.{scheduled['recordField']}"
                        if scheduled.get("recordField")
                        else obj
                    )
                    self.read(
                        source,
                        name,
                        name + (scheduled.get("name") or "") + f".scheduledPaths[{i}]",
                        "read_resource",
                        owner,
                        path=path,
                        source_kind="field"
                        if scheduled.get("recordField")
                        else "object",
                        occurrence_paths=(path + "/recordField",)
                        if scheduled.get("recordField")
                        else (owner + "/object",),
                    )
                else:
                    self.diagnostic(
                        "legacy-scheduled-path-without-object",
                        "Scheduled path has no object context",
                        path,
                        owner,
                    )
                self.connector(
                    name,
                    owner,
                    scheduled.get("connector"),
                    f"scheduledPaths[{i}].connector",
                )
            if node.get("schedule") and node.get("object"):
                self.read(
                    node["object"],
                    name,
                    name + ".schedule",
                    "read_resource",
                    owner,
                    path=owner + "/schedule",
                    schedule=node["schedule"],
                    source_kind="object",
                    occurrence_paths=(owner + "/object",),
                )
            return
        if collection == "decisions" and name:
            for i, rule in enumerate(node.get("rules") or ()):
                path = owner + pointer("rules", i)
                rname = name + "." + rule["name"]
                self.node(rname, path, "FlowRule", "rule")
                self.conditions(
                    rule.get("conditions"), rname, owner, path + "/conditions"
                )
                self.emit(
                    name,
                    rname,
                    f"{name}.rules[{i}]",
                    "decision_rule_of",
                    owner,
                    family="contains",
                    structural=True,
                    path=path,
                )
                connector = rule.get("connector")
                self.connector(
                    rname,
                    owner,
                    connector,
                    "connector",
                    "navigates_if_true" if connector else "stop_navigation_if_true",
                    stop=True,
                    location_path=path + "/connector",
                    **({} if connector else {"label": "No Connector"}),
                )
            self.connector(
                name,
                owner,
                node.get("defaultConnector"),
                "defaultConnector",
                "navigates_if_all_false",
                label=node.get("defaultConnectorLabel"),
            )
            return
        if collection == "assignments":
            for i, item in enumerate(node.get("assignmentItems") or ()):
                path = owner + pointer("assignmentItems", i)
                if "value" not in item:
                    self.diagnostic(
                        "legacy-missing-value",
                        "'NoneType' object has no attribute 'format_values'",
                        path + "/value",
                        owner,
                    )
                value = self.value_edge(
                    item.get("value"),
                    name,
                    f"{name}.assignmentItems[{i}].value",
                    "read_resource_for_assignment",
                    owner,
                    path + "/value",
                    expression=format_value(item.get("value"))["value"],
                )
                self.emit(
                    name,
                    item["assignToReference"],
                    f"{name}.assignmentItems[{i}].assignToReference",
                    _snake(item["operator"]),
                    owner,
                    family="writes",
                    path=path + "/assignToReference",
                    ref_path=path + "/assignToReference",
                    reference_endpoint="target",
                    expression=value["value"],
                )
            self.connector(name, owner, node.get("connector"), stop=True)
            return
        if collection == "loops":
            self.read(
                node["collectionReference"],
                name,
                name + ".collectionReference",
                "reads_collection",
                owner,
                path=owner + "/collectionReference",
            )
            if node.get("assignNextValueToReference"):
                self.emit(
                    name,
                    node["assignNextValueToReference"],
                    name + ".assignNextValueToReference",
                    "assigns_collection_next_value_to_reference",
                    owner,
                    family="writes",
                    path=owner + "/assignNextValueToReference",
                )
            self.connector(
                name,
                owner,
                node.get("nextValueConnector"),
                "nextValueConnector",
                "navigates_to_collection_next_value",
            )
            self.connector(
                name,
                owner,
                node.get("noMoreValuesConnector"),
                "noMoreValuesConnector",
                "navigates_to_if_no_more_values",
            )
            return
        if collection in {"actionCalls", "apexPluginCalls", "subflows"}:
            self.inputs(node, owner)
            self.outputs(
                node,
                owner,
                automatic=bool(node.get("storeOutputAutomatically"))
                if collection == "actionCalls"
                else False,
            )
            prop, relation = {
                "actionCalls": ("actionName", "invoke_callable_action"),
                "apexPluginCalls": ("apexClass", "invokes_apex"),
                "subflows": ("flowName", "invokes_subflow"),
            }[collection]
            if collection == "apexPluginCalls":
                self.node(node[prop], owner, "ApexClass", "apex")
            self.emit(
                name,
                node[prop],
                name + "." + prop,
                relation,
                owner,
                family="invokes",
                target_kind={
                    "actionCalls": "action",
                    "apexPluginCalls": "apex",
                    "subflows": "subflow",
                }[collection],
                path=owner + pointer(prop),
            )
            for prop in ("connector", "faultConnector"):
                self.connector(
                    name, owner, node.get(prop), prop, stop=collection != "subflows"
                )
            if collection == "actionCalls":
                self.connector(
                    name,
                    owner,
                    node.get("timeoutConnector"),
                    "timeoutConnector",
                    stop=True,
                )
                for i, path in enumerate(node.get("actionCallPaths") or ()):
                    self.connector(
                        name,
                        owner,
                        path.get("connector"),
                        f"actionCallPaths[{i}].connector",
                        stop=True,
                    )
                if node.get("einsteinDecidePath"):
                    self.diagnostic(
                        "legacy-einstein-decide-path",
                        "einsteinDecidePath not implemented",
                        owner + "/einsteinDecidePath",
                        owner,
                    )
            return
        if collection.startswith("record"):
            self.record(collection, node, owner)
            return
        if collection == "collectionProcessors":
            self.read(
                node["collectionReference"],
                name,
                name + ".collectionReference",
                "read_resource_into",
                owner,
                path=owner + "/collectionReference",
            )
            self.conditions(
                node.get("conditions"),
                name,
                owner,
                owner + "/conditions",
                collection=True,
            )
            self.formula(name, owner, "formula", "read_resource_into")
            for i, option in enumerate(node.get("sortOptions") or ()):
                if option.get("sortField"):
                    self.read(
                        node["collectionReference"] + "." + option["sortField"],
                        name,
                        f"{name}.sortOptions[{i}]",
                        "orders_by",
                        owner,
                        path=owner + pointer("sortOptions", i, "sortField"),
                    )
            for i, item in enumerate(node.get("mapItems") or ()):
                path = owner + pointer("mapItems", i)
                if item.get("value") is None:
                    self.diagnostic(
                        "legacy-missing-value",
                        "'NoneType' object has no attribute 'format_values'",
                        path + "/value",
                        owner,
                    )
                formatted = format_value(item.get("value"))
                self.read(
                    formatted["name"],
                    name,
                    f"{name}.mapItems[{i}].value",
                    "read_resource_for_mapping",
                    owner,
                    path=path + "/value",
                    source_kind="reference"
                    if formatted["kind"] == "reference"
                    else "literal",
                    occurrence_paths=self.evidence_paths(path + "/value"),
                    structural=formatted["kind"] == "literal",
                )
                self.emit(
                    name,
                    item["assignToFieldReference"],
                    f"{name}.mapItems[{i}].assignToReference",
                    _snake(item["operator"]),
                    owner,
                    family="writes",
                    path=path + "/assignToFieldReference",
                )
            if node.get("assignNextValueToReference"):
                self.emit(
                    name,
                    node["assignNextValueToReference"],
                    name + ".assignNextValueToReference",
                    "assign_next_value_to_reference",
                    owner,
                    family="writes",
                    path=owner + "/assignNextValueToReference",
                )
            self.connector(name, owner, node.get("connector"), stop=True)
            self.connector(
                name, owner, node.get("faultConnector"), "fault_connector", stop=True
            )
            return
        if collection == "screens":
            if node.get("actions"):
                self.diagnostic(
                    "legacy-screen-actions",
                    "Action handling not implemented as none of the current flows have screen actions.",
                    owner + "/actions",
                    owner,
                )
            for i, field in enumerate(node.get("fields") or ()):
                self.screen_field(field, owner + pointer("fields", i), name, owner)
            self.connector(name, owner, node.get("connector"))
            return
        if collection == "waits":
            for prop in ("defaultConnector", "faultConnector"):
                if node.get(prop):
                    self.emit(
                        name,
                        node[prop]["targetReference"],
                        None,
                        "navigates_to",
                        owner,
                        family="control",
                        occurrence_paths=(owner + pointer(prop, "targetReference"),),
                        path=owner + pointer(prop),
                        edge_type="navigates_to",
                        legacy_path=prop,
                    )
            for i, event in enumerate(node.get("waitEvents") or ()):
                path = owner + pointer("waitEvents", i)
                self.parameters(
                    event.get("inputParameters"), name, owner, path + "/inputParameters"
                )
                self.parameters(
                    event.get("outputParameters"),
                    name,
                    owner,
                    path + "/outputParameters",
                    output=True,
                )
                if event.get("connector"):
                    self.emit(
                        name,
                        event["connector"]["targetReference"],
                        None,
                        "navigates_to",
                        owner,
                        family="control",
                        occurrence_paths=(path + "/connector/targetReference",),
                        path=path + "/connector",
                        edge_type="navigates_to",
                        legacy_path="waitEvents",
                    )
            return
        if collection == "transforms":
            for i, value in enumerate(node.get("transformValues") or ()):
                for j, action in enumerate(value.get("transformValueActions") or ()):
                    path = owner + pointer(
                        "transformValues", i, "transformValueActions", j
                    )
                    attrs = dict(
                        outputField=action.get("outputFieldApiName"),
                        transformType=action.get("transformType"),
                        transformValueName=value.get("transformValueName"),
                    )
                    if action.get("value") is not None:
                        formatted = format_value(action["value"])
                        source = formatted.pop("name")
                        self.read(
                            source,
                            name,
                            None,
                            "reads_resource",
                            owner,
                            path=path + "/value",
                            edge_type="reads_resource",
                            legacy_path="transformValueAction.value",
                            **attrs,
                            **formatted,
                            source_kind="reference"
                            if formatted["kind"] == "reference"
                            else "literal",
                            occurrence_paths=self.evidence_paths(path + "/value"),
                            structural=formatted["kind"] == "literal",
                        )
                    self.parameters(
                        action.get("inputParameters"),
                        name,
                        owner,
                        path + "/inputParameters",
                        **attrs,
                    )
                    if action.get("outputFieldApiName"):
                        self.emit(
                            name,
                            name + "." + action["outputFieldApiName"],
                            None,
                            "outputField",
                            owner,
                            family="writes",
                            path=path + "/outputFieldApiName",
                            type="outputField",
                            transformType=action.get("transformType"),
                            transformValueName=value.get("transformValueName"),
                        )
            if node.get("connector"):
                self.emit(
                    name,
                    node["connector"]["targetReference"],
                    None,
                    "connector",
                    owner,
                    family="control",
                    path=owner + "/connector",
                    occurrence_paths=(owner + "/connector/targetReference",),
                    type="connector",
                )

    def record(self, collection, node, owner):
        name, obj = node["name"], node.get("object")
        if collection == "recordLookups":
            self.filters(node, owner)
            if node.get("queriedFields"):
                for i, field in enumerate(node["queriedFields"]):
                    path = owner + pointer("queriedFields", i)
                    self.read(
                        f"{obj}.{field}",
                        name,
                        f"{name}.queriedFields[{i}]",
                        "map_sobject_fields_to_param",
                        owner,
                        path=path,
                        ref_path=path,
                        reference_endpoint="source",
                        source_reference=field,
                        source_kind="field",
                    )
            else:
                self.read(
                    obj,
                    name,
                    name + ".object",
                    "map_sobject_to_param",
                    owner,
                    path=owner + "/object",
                    source_kind="object",
                )
            for i, assignment in enumerate(node.get("outputAssignments") or ()):
                path = owner + pointer("outputAssignments", i)
                self.emit(
                    f"{obj}.{assignment['field']}",
                    assignment["assignToReference"],
                    f"{name}.outputAssignments.{assignment['field']}",
                    "assign_field_to_output_reference",
                    owner,
                    family="writes",
                    path=path,
                    occurrence_paths=(path + "/assignToReference",),
                    link_source_node=name,
                )
                self.connect(
                    self.endpoint(f"{obj}.{assignment['field']}", "field"),
                    owner,
                    "reads",
                    "lookup_field",
                    owner,
                    SourceLocation(path + "/field"),
                    tuple(
                        item.occurrence_id
                        for item in self.by_path.get(path + "/field", ())
                    ),
                )
            if node.get("sortField"):
                path = owner + "/sortField"
                self.read(
                    f"{obj}.{node['sortField']}",
                    name,
                    name + ".sortField",
                    "orders_by",
                    owner,
                    path=path,
                    ref_path=path,
                    reference_endpoint="source",
                    source_reference=node["sortField"],
                    source_kind="field",
                )
            if node.get("outputReference"):
                self.emit(
                    name,
                    node["outputReference"],
                    name + ".outputReference",
                    "assign_to_output_reference",
                    owner,
                    family="writes",
                    target_kind="reference",
                    path=owner + "/outputReference",
                )
        else:
            if collection == "recordCreates" and obj:
                self.emit(
                    name,
                    obj,
                    name + ".object",
                    "inserts_into",
                    owner,
                    family="writes",
                    target_kind="object",
                    path=owner + "/object",
                )
            if node.get("inputReference"):
                self.read(
                    node["inputReference"],
                    name,
                    name + ".inputReference",
                    "assign_to_param"
                    if collection == "recordCreates"
                    else "reads_input_reference",
                    owner,
                    path=owner + "/inputReference",
                )
                if collection == "recordCreates" and obj and not node.get("doesUpsert"):
                    self.emit(
                        node["inputReference"],
                        obj,
                        None,
                        "insert_from_reference_with_overrides"
                        if node.get("inputAssignments")
                        else "insert_all_fields_from_reference",
                        owner,
                        family="writes",
                        target_kind="object",
                        path=owner + "/inputReference",
                    )
            for i, assignment in enumerate(node.get("inputAssignments") or ()):
                target = obj or (
                    node.get("inputReference")
                    if collection == "recordUpdates"
                    else "inputref"
                )
                value = format_value(assignment.get("value"))
                self.emit(
                    value["name"],
                    f"{target}.{assignment['field']}",
                    f"{name}.inputAssignments[{assignment['field']}]",
                    "set_value_to_field",
                    owner,
                    family="writes",
                    target_kind="field" if obj else "reference",
                    path=owner + pointer("inputAssignments", i),
                    occurrence_paths=(owner + pointer("inputAssignments", i, "field"),),
                    value=value["value"],
                    notes=[
                        "The input assignments are the manual method so refer directly to a field."
                    ],
                )
                value_path = owner + pointer("inputAssignments", i, "value")
                self.connect(
                    self.endpoint(
                        value["name"],
                        "reference" if value["kind"] == "reference" else "literal",
                    ),
                    owner,
                    "reads",
                    "assignment_value",
                    owner,
                    SourceLocation(value_path),
                    tuple(
                        item.occurrence_id
                        for path in self.evidence_paths(value_path)
                        for item in self.by_path[path]
                    ),
                    structural=value["kind"] == "literal",
                )
            self.filters(node, owner)
            if obj and collection != "recordCreates":
                self.emit(
                    name,
                    obj,
                    name + ".object",
                    "updates_object"
                    if collection == "recordUpdates"
                    else "deletes_records_in_object",
                    owner,
                    family="writes",
                    target_kind="object",
                    path=owner + "/object",
                )
            if node.get("assignRecordIdToReference"):
                self.emit(
                    name,
                    node["assignRecordIdToReference"],
                    name + ".assignRecordIdToReference",
                    "write_new_Id_to_reference",
                    owner,
                    family="writes",
                    path=owner + "/assignRecordIdToReference",
                )
        for prop in ("connector", "faultConnector"):
            self.connector(name, owner, node.get(prop), prop)

    def screen_field(self, node, path, parent, top_owner):
        name = node.get("name") or parent + "." + node["fieldType"]
        self.node(name, path, "FlowScreenField", "screen_field")
        self.emit(
            parent,
            name,
            parent + "." + name,
            "field_contained_within",
            top_owner,
            family="contains",
            structural=True,
            path=path,
        )
        prefix = parent + "." + name
        for prop, relation in (
            ("sourceTemplateApiName", ":get_source_template"),
            ("extensionName", "invokes_user_interface_component"),
            ("objectFieldReference", "get_object_field_reference"),
            ("defaultSelectedChoiceReference", "map_default_reference"),
        ):
            if node.get(prop):
                attrs = {}
                if prop == "sourceTemplateApiName":
                    attrs["notes"] = ["TODO: need to map to source template"]
                if prop == "objectFieldReference":
                    attrs["notes"] = ["TODO: need to map to object field reference"]
                self.emit(
                    node[prop],
                    name,
                    prefix + "." + prop,
                    relation,
                    top_owner,
                    family="invokes"
                    if prop in {"extensionName", "sourceTemplateApiName"}
                    else "reads",
                    canonical_source=name
                    if prop in {"extensionName", "sourceTemplateApiName"}
                    else None,
                    canonical_target=node[prop]
                    if prop in {"extensionName", "sourceTemplateApiName"}
                    else None,
                    source_kind="local"
                    if prop in {"extensionName", "sourceTemplateApiName"}
                    else "reference",
                    target_kind={
                        "extensionName": "component",
                        "sourceTemplateApiName": "template",
                    }.get(prop, "local"),
                    path=path + pointer(prop),
                    **attrs,
                )
                if prop == "extensionName":
                    self.node(
                        node[prop],
                        top_owner,
                        "",
                        "notes",
                        notes=["TODO: need to map to lightning component"],
                    )
        if node.get("validationRule"):
            self.formula(
                name,
                path + "/validationRule",
                "formulaExpression",
                "get_references",
                prefix=prefix + ".validationRule.",
            )
        if node.get("defaultValue") is not None:
            value = format_value(node["defaultValue"])
            self.read(
                value["name"],
                name,
                prefix + ".defaultValue",
                "map_default_value",
                top_owner,
                path=path + "/defaultValue",
                attrs=value,
                source_kind="reference" if value["kind"] == "reference" else "literal",
                occurrence_paths=self.evidence_paths(path + "/defaultValue"),
                structural=value["kind"] == "literal",
            )
        self.inputs(node, path, name)
        self.outputs(node, path, bool(node.get("storeOutputAutomatically")), name)
        for i, child in enumerate(node.get("fields") or ()):
            self.screen_field(
                child, path + pointer("fields", i), parent + "." + name, top_owner
            )


def _snake(value):
    return re.sub(r"(?<!^)(?=[A-Z])", "_", value).lower()


def analyze_flow(
    metadata: Mapping[str, Any], *, source: SourceIdentity | None = None
) -> FlowAnalysis:
    """Analyze once; all returned evidence and indexes are recursively immutable."""
    document = (
        metadata if isinstance(metadata, NativeDocument) else NativeDocument(metadata)
    )
    builder = _Builder(document, source or SourceIdentity())
    root: Mapping[str, Any] = document.root
    for collection, value in root.items():
        if collection not in ELEMENT_KINDS:
            if isinstance(value, (Mapping, tuple)) and value:
                builder.diagnostic(
                    "unknown-region",
                    "Native metadata retained without semantic interpretation",
                    pointer(collection),
                    pointer(collection),
                    "uninterpreted",
                )
            continue
        values = ((0, value),) if collection == "start" else enumerate(value or ())
        for index, item in values:
            if not isinstance(item, Mapping):
                continue
            owner = (
                pointer(collection)
                if collection == "start"
                else pointer(collection, index)
            )
            name = item.get("name") or ("start" if collection == "start" else None)
            builder.declare(name, ELEMENT_KINDS[collection], owner)
            if name and collection not in RESOURCE_COLLECTIONS:
                builder.elements.setdefault(name, (collection, index, owner))
            if collection == "decisions" and name:
                for i, rule in enumerate(item.get("rules") or ()):
                    if isinstance(rule, Mapping) and rule.get("name"):
                        builder.declare(
                            name + "." + rule["name"],
                            "FlowRule",
                            owner + pointer("rules", i),
                            owner,
                        )
            for nested, nested_kind in {
                "scheduledPaths": "FlowScheduledPath",
                "waitEvents": "FlowWaitEvent",
                "transformValues": "FlowTransformValue",
            }.items():
                for i, child in enumerate(item.get(nested) or ()):
                    local = owner + pointer(nested, i)
                    builder.owner_names[local] = child.get("name") or ""
                    if child.get("name") and name:
                        builder.declare(
                            name + "." + child["name"], nested_kind, local, owner
                        )

            def screen_declarations(fields, path):
                for i, child in enumerate(fields or ()):
                    local = path + pointer("fields", i)
                    if child.get("name"):
                        builder.declare(child["name"], "FlowScreenField", local, path)
                    else:
                        builder.owner_names[local] = ""
                    screen_declarations(child.get("fields"), local)

            if collection == "screens":
                screen_declarations(item.get("fields"), owner)
    builder.inventory(root)
    for entry in builder.entries:
        path = entry.location.pointer
        parts = path.strip("/").split("/")
        if parts[0] in RECORD_KINDS and (
            (parts[0] != "start" and len(parts) == 2) or parts == ["start"]
        ):
            builder.expressions.append(
                ExpressionEntry(
                    Expression(entry.owner_id, entry.location, "flow_record_operation"),
                    "record",
                    RECORD_KINDS[parts[0]],
                )
            )
    for collection in ELEMENT_KINDS:
        if collection not in root:
            continue
        value = root[collection]
        values = ((0, value),) if collection == "start" else enumerate(value or ())
        for index, item in values:
            if not isinstance(item, Mapping):
                continue
            owner = (
                pointer(collection)
                if collection == "start"
                else pointer(collection, index)
            )
            try:
                builder.element(collection, item, owner)
            except (KeyError, TypeError, ValueError) as error:
                builder.diagnostic(
                    "invalid-element-shape", str(error), owner, owner, "structural"
                )
            name = item.get("name") or ("start" if collection == "start" else None)
            if name:
                builder.control[name] = tuple(
                    target
                    for path, target in builder.connectors.items()
                    if path.startswith(owner + "/")
                )
            obj = item.get("object")
            if obj:
                builder.objects.add(obj)
            if collection == "variables" and item.get("objectType") and name:
                builder.records[name] = item["objectType"]
            if collection == "start" and obj:
                builder.records.update({"$Record": obj, "$Record__Prior": obj})
            if collection == "recordLookups" and obj:
                builder.records[name] = obj
                if item.get("outputReference"):
                    builder.records[item["outputReference"]] = obj
    for path in (root.get("start") or {}).get("scheduledPaths") or ():
        builder.paths.setdefault(path.get("pathType"), []).append(
            (path.get("connector") or {}).get("targetReference")
        )
    pending = list(root.get("loops") or ())
    while pending:
        resolved = [
            loop
            for loop in pending
            if loop.get("collectionReference") in builder.records
        ]
        if not resolved:
            break
        for loop in resolved:
            builder.records[loop["name"]] = builder.records[loop["collectionReference"]]
            pending.remove(loop)
    builder.records.update({
        "$User": "User",
        "$UserRole": "UserRole",
        "$Organization": "Organization",
        "$Profile": "Profile",
    })
    builder.objects.update(builder.records.values())
    return FlowAnalysis(
        document,
        builder.source,
        tuple(builder.declarations),
        tuple(builder.occurrences),
        tuple(builder.connections),
        tuple(builder.diagnostics),
        MappingProxyType(builder.elements),
        MappingProxyType(builder.control),
        MappingProxyType(builder.connectors),
        MappingProxyType({key: tuple(value) for key, value in builder.paths.items()}),
        MappingProxyType(builder.records),
        tuple(builder.entries),
        tuple(builder.expressions),
        tuple(builder.nodes),
        tuple(builder.edges),
        frozenset(builder.objects),
        tuple(builder.views),
        frozenset(builder.duplicate_names),
        MappingProxyType(builder.endpoints),
        MappingProxyType(builder.connection_traits),
    )
