"""Check saved Flow artifacts and graph integrity without Salesforce access."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import quote

import networkx as nx
import pyarrow as pa
import pyarrow.parquet as pq

from salesforce.client import query_records
from .api import validate_flow_id
from .contract import (
    ARTIFACT_NAMES,
    CONTRACT_VERSION,
    NODE_SCHEMA,
    EDGE_SCHEMA,
    EXPRESSION_SCHEMA,
    NodeKind,
    canonical_json,
)
from .snapshot import SOURCE_NAMES

AUDIT_VERSION = "flow-audit/v2"
POLICY = {
    "version": "flow-audit-policy/v2",
    "scope": "artifact_and_graph_integrity",
    "failure_severities": ["error"],
    "executable_equivalence_verified": False,
    "complete_relationship_extraction_verified": False,
}


def _finding(findings, code, message, *, severity="error", **references):
    findings.append(dict(severity=severity, code=code, message=message, **references))


def _descriptors(directory, names, findings):
    result = {}
    for name in sorted(names):
        try:
            with (directory / name).open("rb") as stream:
                digest = hashlib.file_digest(stream, "sha256").hexdigest()
            result[name] = dict(sha256=digest, size=(directory / name).stat().st_size)
        except OSError as error:
            _finding(
                findings, "missing_or_unreadable_file", error.strerror, artifact=name
            )
    return result


def _json(directory, name, findings):
    try:
        return json.loads((directory / name).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        _finding(
            findings,
            "invalid_json",
            "Required JSON could not be read",
            artifact=name,
            reason=type(error).__name__,
        )
        return None


def _inventory(payload, findings):
    """Read only the source envelope, version identity, and selection fields."""
    if not isinstance(payload, list):
        _finding(
            findings,
            "invalid_source_envelope",
            "Flow export must contain query pages",
            artifact="Flow.json",
        )
        return None
    records, versions, names = [], set(), set()
    for page_index, page in enumerate(payload):
        try:
            page_records = query_records([page], "Flow audit inventory")
        except ValueError:
            _finding(
                findings,
                "invalid_source_envelope",
                "Invalid saved query page",
                artifact="Flow.json",
                source_path=f"/{page_index}",
            )
            return None
        for index, raw in enumerate(page_records):
            path = f"/{page_index}/records/{index}"
            flow_id, metadata = raw.get("Id"), raw.get("Metadata")
            try:
                validate_flow_id(flow_id)
            except ValueError:
                _finding(
                    findings,
                    "invalid_version_id",
                    "Invalid Flow version ID",
                    artifact="Flow.json",
                    source_path=path,
                )
                return None
            if flow_id[:15] in versions:
                _finding(
                    findings,
                    "duplicate_version",
                    "Repeated Flow version ID",
                    flow_version_id=flow_id,
                    source_path=path,
                )
                return None
            versions.add(flow_id[:15])
            if not isinstance(metadata, dict):
                _finding(
                    findings,
                    "missing_metadata",
                    "Flow version has no native metadata",
                    flow_version_id=flow_id,
                    source_path=path,
                )
                return None
            name = metadata.get("fullName") or raw.get("FullName")
            if not isinstance(name, str) or not name:
                _finding(
                    findings,
                    "invalid_flow_name",
                    "Flow version requires a name",
                    flow_version_id=flow_id,
                    source_path=path,
                )
                return None
            if metadata.get("status") == "Active":
                if name in names:
                    _finding(
                        findings,
                        "duplicate_active_name",
                        "Multiple active versions share a Flow name",
                        flow_version_id=flow_id,
                        source_path=path,
                    )
                    return None
                names.add(name)
            records.append((path, raw))
    return records


def _coverage(export_dir, findings):
    """Retain producer reports; acquisition policy is validated by the build."""
    reports = {}
    for name in ("flow", "datamodel"):
        artifact = f"{name}-report.json"
        report = _json(export_dir, artifact, findings)
        reports[name] = report
        if not isinstance(report, dict) or not isinstance(
            report.get("coverage_complete"), bool
        ):
            _finding(
                findings,
                "invalid_coverage",
                "Acquisition report requires a coverage flag",
                artifact=artifact,
            )
        elif not report["coverage_complete"]:
            _finding(
                findings,
                "incomplete_acquisition",
                "Producer reports acquisition gaps; see the hashed source report",
                severity="warning",
                artifact=artifact,
            )
    return reports


def _tables(lineage_dir, findings):
    tables = {}
    for name, schema in [
        ("nodes", NODE_SCHEMA),
        ("edges", EDGE_SCHEMA),
        ("expressions", EXPRESSION_SCHEMA),
    ]:
        artifact = f"{name}.parquet"
        try:
            table = pq.read_table(lineage_dir / artifact)
        except (OSError, pa.ArrowException):
            _finding(
                findings,
                "invalid_parquet",
                "Required table could not be read",
                artifact=artifact,
            )
            continue
        if table.schema != schema or any(
            table.column(field.name).null_count
            for field in schema
            if not field.nullable
        ):
            _finding(
                findings,
                "table_schema",
                "Table schema/nullability differs from lineage/v1",
                artifact=artifact,
            )
            continue
        rows = table.to_pylist()
        key = {"nodes": "node_id", "edges": "edge_id", "expressions": "expression_id"}[
            name
        ]
        if any(not row[key] for row in rows) or len({row[key] for row in rows}) != len(
            rows
        ):
            _finding(
                findings,
                "duplicate_table_id",
                "Table identifiers must be nonempty and unique",
                artifact=artifact,
            )
            continue
        tables[name] = rows
    return tables


def _has_path(payload, path, base):
    if not isinstance(path, str) or not (path == base or path.startswith(base + "/")):
        return False
    try:
        for part in path[1:].split("/"):
            part = part.replace("~1", "/").replace("~0", "~")
            if isinstance(payload, list) and part.isdigit():
                payload = payload[int(part)]
            elif isinstance(payload, dict):
                payload = payload[part]
            else:
                return False
    except (KeyError, IndexError, ValueError):
        return False
    return True


def _graph(document, org, findings, contract_version=CONTRACT_VERSION):
    """Validate raw IDs/endpoints before NetworkX can merge or invent nodes."""
    if (
        not isinstance(document, dict)
        or document.get("directed") is not True
        or document.get("multigraph") is not True
        or not isinstance(document.get("nodes"), list)
        or not isinstance(document.get("edges"), list)
    ):
        _finding(
            findings,
            "invalid_graph",
            "Expected a directed MultiDiGraph node-link document",
            artifact="flows.json",
        )
        return None
    if not isinstance(document.get("graph"), dict):
        _finding(
            findings,
            "invalid_graph",
            "Graph attributes must be an object",
            artifact="flows.json",
        )
        return None
    if (
        document["graph"].get("org") != org
        or document["graph"].get("contract_version") != contract_version
    ):
        _finding(
            findings,
            "graph_identity",
            "Graph environment/contract differs from audit selection",
            artifact="flows.json",
        )
    nodes, edges, valid = set(), set(), True
    for group, required, identity, seen in [
        (
            "nodes",
            ("id", "kind", "name", "flow_name", "flow_version_id", "resolution_status"),
            "id",
            nodes,
        ),
        (
            "edges",
            (
                "edge_id",
                "key",
                "source",
                "target",
                "relation",
                "flow_name",
                "flow_version_id",
                "evidence_type",
                "resolution_status",
            ),
            "edge_id",
            edges,
        ),
    ]:
        for index, item in enumerate(document[group]):
            singular = "node" if group == "nodes" else "edge"
            if (
                not isinstance(item, dict)
                or any(
                    not isinstance(item.get(key), str) or not item[key]
                    for key in required
                )
                or (
                    item.get("source_path") is not None
                    and not isinstance(item["source_path"], str)
                )
                or ("attrs" in item and not isinstance(item["attrs"], dict))
            ):
                _finding(
                    findings,
                    f"invalid_{singular}",
                    "Required graph attributes have invalid types or values",
                    artifact="flows.json",
                    source_path=f"/{group}/{index}",
                )
                valid = False
                continue
            if group == "edges" and item["key"] != item["edge_id"]:
                _finding(
                    findings,
                    "edge_identity",
                    "Graph edge key differs from its occurrence ID",
                    artifact="flows.json",
                    edge_id=item["edge_id"],
                )
                valid = False
            if item[identity] in seen:
                _finding(
                    findings,
                    f"duplicate_graph_{singular}",
                    "Repeated graph identifier would overwrite an occurrence",
                    artifact="flows.json",
                    item_id=item[identity],
                )
                valid = False
            seen.add(item[identity])
    if not valid:
        return None
    for edge in document["edges"]:
        if edge["source"] not in nodes or edge["target"] not in nodes:
            _finding(
                findings,
                "missing_endpoint",
                "Graph edge refers to a missing node",
                artifact="flows.json",
                edge_id=edge["edge_id"],
            )
            valid = False
    return nx.node_link_graph(document, edges="edges") if valid else None


def _graph_checks(graph, selected, payload, org, findings):
    canonical = graph.graph.get("contract_version") == "lineage/v2"
    owners = {
        (node.get("flow_version_id"), node["pointer"])
        for _, node in graph.nodes(data=True)
        if isinstance(node.get("pointer"), str)
    }
    owners.update(
        (node.get("flow_version_id"), "")
        for _, node in graph.nodes(data=True)
        if node.get("kind") == "Flow"
    )
    kinds = {kind.value for kind in NodeKind}
    for node_id, node in graph.nodes(data=True):
        flow_id = node["flow_version_id"]
        root = f"{org}/flow/{quote(flow_id, safe='')}"
        expected_id = (
            root
            if node["kind"] == "Flow"
            else root + "/node/" + quote(node["name"], safe="")
        )
        if node_id != expected_id:
            _finding(
                findings,
                "node_identity",
                "Node identity differs from its Flow scope",
                node_id=node_id,
            )
        if node["kind"] not in kinds or node["resolution_status"] not in {
            "resolved",
            "unresolved",
            "not_applicable",
            *({"ambiguous"} if canonical else set()),
        }:
            _finding(
                findings,
                "node_contract",
                "Unknown node kind or resolution status",
                node_id=node_id,
            )
        if selected is None:
            continue
        if flow_id not in selected:
            _finding(
                findings,
                "unselected_graph_version",
                "Node belongs to an unselected Flow version",
                node_id=node_id,
            )
            continue
        path, raw = selected[flow_id]
        name = raw["Metadata"].get("fullName") or raw["FullName"]
        if node["flow_name"] != name:
            _finding(
                findings,
                "node_identity",
                "Node Flow name differs from source selection",
                node_id=node_id,
            )
        if node["kind"] == "Flow":
            if node.get("source_record") != raw or node.get("source_path") != path:
                _finding(
                    findings,
                    "native_record_mismatch",
                    "Flow root does not retain its selected native record",
                    node_id=node_id,
                )
        elif node.get("source_path") is not None and not _has_path(
            payload, node["source_path"], path + "/Metadata"
        ):
            _finding(
                findings,
                "invalid_source_path",
                "Node provenance does not exist within its Flow metadata",
                node_id=node_id,
                source_path=node["source_path"],
            )
    if selected is not None:
        for flow_id, (path, _) in selected.items():
            root = f"{org}/flow/{quote(flow_id, safe='')}"
            if root not in graph or graph.nodes[root]["kind"] != "Flow":
                _finding(
                    findings,
                    "missing_flow_root",
                    "Selected active version has no graph root",
                    flow_version_id=flow_id,
                    source_path=path,
                )
    for source, target, key, edge in graph.edges(keys=True, data=True):
        flow_id = edge["flow_version_id"]
        if any(
            graph.nodes[node][field] != edge[field]
            for node in (source, target)
            for field in ("flow_version_id", "flow_name")
        ):
            _finding(
                findings,
                "cross_flow_edge",
                "Edge crosses Flow version/name scope",
                edge_id=key,
            )
        root = f"{org}/flow/{quote(flow_id, safe='')}"
        if canonical:
            local_id = edge.get("canonical_connection_id")
            expected_id = (
                root + "/edge/" + quote(local_id, safe="")
                if isinstance(local_id, str)
                else None
            )
        else:
            expected_id = (
                root
                + "/edge/"
                + "/".join(
                    quote(part, safe="")
                    for part in (
                        graph.nodes[source]["name"],
                        graph.nodes[target]["name"],
                        canonical_json(edge.get("original_key")),
                    )
                )
            )
        if key != expected_id:
            _finding(
                findings,
                "edge_identity",
                "Edge identity differs from its occurrence key",
                edge_id=key,
            )
        if (
            selected is not None
            and flow_id in selected
            and not _has_path(
                payload, edge.get("source_path"), selected[flow_id][0] + "/Metadata"
            )
        ):
            _finding(
                findings,
                "invalid_source_path",
                "Edge provenance does not exist within its Flow metadata",
                edge_id=key,
                source_path=edge.get("source_path"),
            )
        if canonical:
            _canonical_edge_checks(graph, source, target, key, edge, findings, owners)
            if selected is not None and flow_id in selected:
                _canonical_occurrence_checks(
                    edge, payload, selected[flow_id][0] + "/Metadata", root, findings
                )
        elif (
            edge["evidence_type"] != "inferred"
            or edge["resolution_status"] != "unresolved"
        ):
            _finding(
                findings,
                "unverified_edge_confirmation",
                "Current producer records inferred, unresolved semantics",
                edge_id=key,
            )


def _canonical_edge_checks(graph, source, target, key, edge, findings, owners):
    statuses = {graph.nodes[node]["resolution_status"] for node in (source, target)}
    expected_resolution = (
        "ambiguous"
        if "ambiguous" in statuses
        else "unresolved"
        if "unresolved" in statuses
        else "resolved"
    )
    if (
        edge["relation"]
        not in {"reads", "writes", "control", "invokes", "contains", "binds_to"}
        or not isinstance(edge.get("role"), str)
        or not edge.get("role")
        or not isinstance(edge.get("owner_id"), str)
        or (edge.get("flow_version_id"), edge.get("owner_id")) not in owners
        or not isinstance(edge.get("occurrence_ids"), list)
        or edge["resolution_status"] != expected_resolution
        or edge["evidence_type"] not in {"explicit", "inferred"}
        or edge.get("derivation_kind")
        not in {
            "native_property",
            "lexical_formula",
            "derived_mapping",
            "catalog_binding",
        }
        or edge.get("interpretation_status")
        not in {"supported", "partial", "uninterpreted"}
        or edge.get("binding_status") != "not_attempted"
        or edge.get("runtime_status") != "not_evaluated"
    ):
        _finding(
            findings,
            "canonical_edge_contract",
            "Canonical relation, provenance, or independent status dimensions are invalid",
            edge_id=key,
        )


def _canonical_occurrence_checks(edge, payload, base, root, findings):
    """Check occurrence evidence against saved strings, not regenerated semantics."""
    identifiers = edge.get("occurrence_ids")
    occurrences = edge.get("reference_occurrences")
    valid = (
        isinstance(identifiers, list)
        and all(
            isinstance(item, str) and item.startswith(root + "/")
            for item in identifiers
        )
        and len(identifiers) == len(set(identifiers))
        and isinstance(occurrences, list)
        and all(isinstance(item, dict) for item in occurrences)
        and identifiers == [item.get("occurrence_id") for item in occurrences]
    )
    if not valid:
        _finding(
            findings,
            "canonical_occurrence_contract",
            "Occurrence IDs and evidence must agree within the owning Flow scope",
            edge_id=edge["edge_id"],
        )
        return
    if not identifiers and (
        edge.get("derivation_kind") == "lexical_formula"
        or not (
            edge.get("synthetic_projection") is True
            or (
                edge.get("structural") is True
                and _has_path(payload, edge.get("source_path"), base)
            )
        )
    ):
        _finding(
            findings,
            "canonical_occurrence_contract",
            "Reference-derived connections require occurrence evidence",
            edge_id=edge["edge_id"],
        )
    for occurrence in occurrences:
        path, pointer = occurrence.get("source_path"), occurrence.get("pointer")
        reference = occurrence.get("reference")
        start, end = occurrence.get("start"), occurrence.get("end")
        valid = (
            isinstance(pointer, str)
            and path == base + pointer
            and _has_path(payload, path, base)
            and isinstance(reference, str)
            and bool(reference)
        )
        if valid:
            native = payload
            for part in path[1:].split("/"):
                part = part.replace("~1", "/").replace("~0", "~")
                native = native[int(part)] if isinstance(native, list) else native[part]
            valid = isinstance(native, str)
            if start is None and end is None:
                valid = valid and native == reference
            else:
                valid = (
                    valid
                    and type(start) is int
                    and type(end) is int
                    and 0 <= start <= end <= len(native)
                    and native[start:end] == reference
                )
        if not valid:
            _finding(
                findings,
                "canonical_occurrence_provenance",
                "Reference text/span does not identify its saved native occurrence",
                edge_id=edge["edge_id"],
                source_path=path,
            )


def _parity(graph, tables, findings):
    for name, items, identity in [
        ("nodes", {node: data for node, data in graph.nodes(data=True)}, "node_id"),
        (
            "edges",
            {
                key: dict(data, source_id=source, target_id=target)
                for source, target, key, data in graph.edges(keys=True, data=True)
            },
            "edge_id",
        ),
    ]:
        if name not in tables:
            continue
        if set(items) != {row[identity] for row in tables[name]}:
            _finding(
                findings,
                "graph_table_ids",
                "Graph and Parquet identifiers differ",
                artifact=f"{name}.parquet",
            )
        for row in tables[name]:
            item = items.get(row[identity])
            if item is None:
                continue
            attributes = {
                key: value
                for key, value in item.items()
                if key not in {"source_id", "target_id"}
            }
            if row["attributes_json"] != canonical_json(attributes) or any(
                row[key] != item.get(key)
                for key in row
                if key not in {identity, "attributes_json"}
            ):
                _finding(
                    findings,
                    "graph_table_values",
                    "Graph and Parquet attributes differ",
                    artifact=f"{name}.parquet",
                    item_id=row[identity],
                )


def _expression_checks(rows, graph, selected, payload, org, findings):
    for row in rows:
        expression_id = row["expression_id"]
        owner = graph.nodes.get(row["owner_node_id"])
        if owner is None:
            _finding(
                findings,
                "missing_expression_owner",
                "Expression owner is missing from graph",
                expression_id=expression_id,
            )
            continue
        flow_id, path = owner["flow_version_id"], row["source_path"]
        root = f"{org}/flow/{quote(flow_id, safe='')}"
        if not expression_id.startswith(root + "/expression/"):
            _finding(
                findings,
                "expression_owner_scope",
                "Expression and owner belong to different Flow scopes",
                expression_id=expression_id,
            )
        if selected is not None and flow_id in selected:
            base = selected[flow_id][0] + "/Metadata"
            if not _has_path(payload, path, base):
                _finding(
                    findings,
                    "invalid_source_path",
                    "Expression provenance does not exist within its Flow metadata",
                    expression_id=expression_id,
                    source_path=path,
                )
            elif expression_id != root + "/expression/" + quote(
                path.removeprefix(base), safe=""
            ):
                _finding(
                    findings,
                    "expression_identity",
                    "Expression identity differs from its source path",
                    expression_id=expression_id,
                )
        status, sql, language = (
            row["translation_status"],
            row["athena_sql"],
            row["source_language"],
        )
        if (
            row["native_expression"] is None
            or not row["reason"]
            or not row["reason"].strip()
            or status
            not in {"supported_representation", "unsupported", "not_attempted"}
            or (status == "supported_representation" and (not sql or not sql.strip()))
            or (status != "supported_representation" and sql is not None)
            or language
            not in {
                "salesforce_formula",
                "unknown",
                "flow_condition",
                "flow_record_operation",
            }
            or (language == "salesforce_formula" and status != "unsupported")
            or (language == "unknown" and status != "not_attempted")
        ):
            _finding(
                findings,
                "translation_contract",
                "Native text, language, SQL, status, and reason are inconsistent",
                expression_id=expression_id,
            )


def _limitations(graph, rows, findings):
    for count, code, severity, artifact, message in [
        (
            sum(
                node["resolution_status"] == "unresolved"
                for _, node in graph.nodes(data=True)
            ),
            "unresolved_references",
            "warning",
            "flows.json",
            "Recorded nodes remain unresolved",
        ),
        (
            sum(
                edge["evidence_type"] == "inferred"
                for _, _, edge in graph.edges(data=True)
            ),
            "inferred_edges",
            "informational",
            "flows.json",
            "Recorded edge semantics are inferred",
        ),
        (
            sum(row["translation_status"] == "unsupported" for row in rows),
            "unsupported_expressions",
            "unsupported",
            "expressions.parquet",
            "Recorded expressions have unsupported translations",
        ),
        (
            sum(row["translation_status"] == "not_attempted" for row in rows),
            "uninterpreted_expressions",
            "warning",
            "expressions.parquet",
            "Recorded expressions have not been interpreted",
        ),
    ]:
        if count:
            _finding(
                findings,
                code,
                message,
                severity=severity,
                artifact=artifact,
                count=count,
            )


def audit_lineage(
    *,
    org: str,
    export_dir: Path,
    lineage_dir: Path,
    contract_version: str = CONTRACT_VERSION,
):
    """Return deterministic integrity findings without network access or writes."""
    if not isinstance(org, str) or not re.fullmatch(r"[A-Za-z0-9_-]+", org):
        raise ValueError(
            "Org must be a nonempty alias containing letters, digits, _ or -"
        )
    if contract_version not in {"lineage/v1", "lineage/v2"}:
        raise ValueError(f"Unsupported lineage contract: {contract_version}")
    export_dir, lineage_dir = Path(export_dir), Path(lineage_dir)
    findings = []
    sources = _descriptors(export_dir, SOURCE_NAMES, findings)
    artifacts = _descriptors(lineage_dir, ARTIFACT_NAMES, findings)
    payload = _json(export_dir, "Flow.json", findings)
    records = _inventory(payload, findings)
    selected = (
        None
        if records is None
        else {
            raw["Id"]: (path, raw)
            for path, raw in records
            if raw["Metadata"].get("status") == "Active"
        }
    )
    inventory = (
        []
        if records is None
        else [
            dict(
                flow_version_id=raw["Id"],
                flow_name=raw.get("FullName"),
                status=raw["Metadata"].get("status"),
                source_path=path,
                selected=raw["Metadata"].get("status") == "Active",
            )
            for path, raw in sorted(records, key=lambda item: item[1]["Id"])
        ]
    )
    coverage = _coverage(export_dir, findings)
    manifest = _json(lineage_dir, "manifest.json", findings)
    if not isinstance(manifest, dict):
        _finding(
            findings,
            "invalid_manifest",
            "Lineage manifest must be an object",
            artifact="manifest.json",
        )
        manifest = None
    if manifest is not None:
        if (
            manifest.get("org") != org
            or manifest.get("contract_version") != contract_version
        ):
            _finding(
                findings,
                "manifest_identity",
                "Manifest environment/contract differs from audit selection",
                artifact="manifest.json",
            )
        if manifest.get("sources") != sources:
            _finding(
                findings,
                "source_snapshot_mismatch",
                "Manifest does not describe the selected source bytes",
                artifact="manifest.json",
            )
        if all(
            isinstance(report, dict)
            and isinstance(report.get("coverage_complete"), bool)
            for report in coverage.values()
        ):
            if manifest.get("coverage") != coverage or manifest.get(
                "coverage_complete"
            ) != all(report["coverage_complete"] for report in coverage.values()):
                _finding(
                    findings,
                    "manifest_coverage",
                    "Manifest coverage differs from producer reports",
                    artifact="manifest.json",
                )
        if records is not None and manifest.get("flow_versions") != inventory:
            _finding(
                findings,
                "manifest_inventory",
                "Manifest selection inventory differs from source",
                artifact="manifest.json",
            )
    tables = _tables(lineage_dir, findings)
    graph = _graph(
        _json(lineage_dir, "flows.json", findings), org, findings, contract_version
    )
    if graph is not None:
        _graph_checks(graph, selected, payload, org, findings)
        _parity(graph, tables, findings)
        _expression_checks(
            tables.get("expressions", []), graph, selected, payload, org, findings
        )
        _limitations(graph, tables.get("expressions", []), findings)
    counts = {
        name: len(tables.get(name, [])) for name in ("nodes", "edges", "expressions")
    }
    if (
        manifest is not None
        and len(tables) == 3
        and manifest.get("row_counts") != counts
    ):
        _finding(
            findings,
            "manifest_row_counts",
            "Manifest row counts differ from persisted tables",
            artifact="manifest.json",
            observed=counts,
        )
    final_sources = _descriptors(export_dir, SOURCE_NAMES, [])
    final_artifacts = _descriptors(lineage_dir, ARTIFACT_NAMES, [])
    if (sources, artifacts) != (final_sources, final_artifacts):
        _finding(
            findings,
            "inputs_changed_during_audit",
            "Source or artifact bytes changed during verification",
        )
    findings.sort(key=canonical_json)
    severities = Counter(row["severity"] for row in findings)
    return dict(
        audit_version=AUDIT_VERSION,
        contract_version=contract_version,
        org=org,
        policy=POLICY,
        passed=not severities["error"],
        sources=sources,
        artifacts=artifacts,
        inventory=inventory,
        coverage=coverage,
        row_counts=counts,
        summary={
            severity: severities[severity]
            for severity in ("error", "warning", "unsupported", "informational")
        },
        diagnostics=findings,
    )


def write_audit(report, path: Path, *, export_dir: Path, lineage_dir: Path):
    """Write only outside source and DVC lineage directories."""
    path = Path(path)
    for directory in (Path(export_dir).resolve(), Path(lineage_dir).resolve()):
        if path.resolve().is_relative_to(directory) or directory.is_relative_to(
            path.resolve()
        ):
            raise ValueError(
                "Audit report must be outside source exports and lineage outputs"
            )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(canonical_json(report) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    selection = parser.add_mutually_exclusive_group(required=True)
    selection.add_argument("--environment")
    selection.add_argument("--org")
    parser.add_argument("--lineage-dir", type=Path)
    parser.add_argument("--export-dir", type=Path)
    parser.add_argument("--report", type=Path)
    parser.add_argument(
        "--contract-version",
        choices=["lineage/v1", "lineage/v2"],
        default=CONTRACT_VERSION,
    )
    args = parser.parse_args()
    if args.environment:
        from salesforce.settings import Settings

        settings = Settings.load(args.environment)
        args.org = settings.org
        args.export_dir = args.export_dir or settings.paths.exports
        args.lineage_dir = (
            args.lineage_dir or settings.paths.build / "views/flow_lineage"
        )
        args.report = (
            args.report or Path("build/audits/flow") / args.environment / "audit.json"
        )
    if args.lineage_dir is None or args.report is None:
        parser.error("Supply --environment or both --lineage-dir and --report.")
    if not re.fullmatch(r"[A-Za-z0-9_-]+", args.org):
        parser.error("Invalid org alias")
    export_dir = args.export_dir or Path("metadata/salesforce") / args.org / "exports"
    report = audit_lineage(
        org=args.org,
        export_dir=export_dir,
        lineage_dir=args.lineage_dir,
        contract_version=args.contract_version,
    )
    try:
        write_audit(
            report, args.report, export_dir=export_dir, lineage_dir=args.lineage_dir
        )
    except ValueError as error:
        parser.error(str(error))
    print(
        canonical_json(
            dict(org=args.org, passed=report["passed"], summary=report["summary"])
        )
    )
    raise SystemExit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()
