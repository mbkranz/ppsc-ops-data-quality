"""Build persisted Flow lineage from saved exports without contacting Salesforce."""

import argparse
import json
from pathlib import Path
import shutil
from tempfile import TemporaryDirectory
import networkx as nx
import pyarrow.parquet as pq
from .contract import ARTIFACT_NAMES, canonical_json
from .snapshot import load_snapshot, source_descriptors
from .graph import compile_lineage
from .tables import lineage_tables


def build_lineage(
    *,
    org: str,
    export_dir: Path,
    output_dir: Path,
    contract_version: str = "lineage/v1",
):
    """Build one org's five contract artifacts; return the deterministic manifest."""
    export_dir, output_dir = Path(export_dir).resolve(), Path(output_dir).absolute()
    if contract_version not in {"lineage/v1", "lineage/v2"}:
        raise ValueError(f"Unsupported lineage contract: {contract_version}")
    if (
        output_dir.is_symlink()
        or output_dir.resolve().is_relative_to(export_dir)
        or export_dir.is_relative_to(output_dir.resolve())
    ):
        raise ValueError("Lineage output must be separate from source exports")
    if output_dir.exists() and (
        not output_dir.is_dir()
        or any(
            path.name not in ARTIFACT_NAMES or not path.is_file()
            for path in output_dir.iterdir()
        )
    ):
        raise ValueError("Output directory contains files outside the lineage contract")
    manifest_path = output_dir / "manifest.json"
    if manifest_path.exists():
        existing = json.loads(manifest_path.read_text(encoding="utf-8"))
        if existing.get("contract_version") != contract_version:
            raise ValueError(
                "Use a separate output directory for each lineage contract"
            )
    snapshot = load_snapshot(export_dir)
    lineage = compile_lineage(snapshot, org=org, contract_version=contract_version)
    _write_lineage(lineage, output_dir, export_dir=export_dir)
    return lineage.manifest


def _write_lineage(lineage, output_dir: Path, *, export_dir: Path):
    """Stage all artifacts and verify source stability before replacing output."""
    graph, manifest = lineage.graph, lineage.manifest
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(
        prefix=f".{output_dir.name}-", dir=output_dir.parent
    ) as temporary:
        staging = Path(temporary)
        (staging / "flows.json").write_text(
            canonical_json(nx.node_link_data(graph, edges="edges")) + "\n",
            encoding="utf-8",
        )
        for name, table in lineage_tables(lineage).items():
            pq.write_table(table, staging / f"{name}.parquet")
        (staging / "manifest.json").write_text(
            canonical_json(manifest) + "\n", encoding="utf-8"
        )
        if source_descriptors(export_dir) != manifest["sources"]:
            raise ValueError("Source exports changed during the lineage build")
        if output_dir.exists():
            shutil.rmtree(output_dir)
        staging.replace(output_dir)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--org", required=True)
    parser.add_argument("--export-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument(
        "--contract-version", choices=["lineage/v1", "lineage/v2"], default="lineage/v1"
    )
    args = parser.parse_args()
    manifest = build_lineage(
        org=args.org,
        export_dir=args.export_dir,
        output_dir=args.output_dir,
        contract_version=args.contract_version,
    )
    print(
        canonical_json({
            key: manifest[key]
            for key in ("org", "row_counts", "coverage_complete", "coverage_warnings")
        })
    )


if __name__ == "__main__":
    main()
