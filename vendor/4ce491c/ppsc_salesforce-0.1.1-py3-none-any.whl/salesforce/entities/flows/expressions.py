"""Native Flow metadata to SQLGlot trees and explicitly selected SQL dialects.

Rendered SQL is a representation of metadata. Physical table binding and Flow
execution semantics require separate validation by the consumer.
"""

import json
import math
import re
from dataclasses import dataclass, field, replace
from datetime import date, datetime
from urllib.parse import quote

from pydantic_core import to_jsonable_python
from sqlglot import ErrorLevel, exp, parse_one
from sqlglot.errors import ParseError, UnsupportedError

from salesforce.core.provenance import annotate, source_metadata

from .lineage import resolve_field


class UnsupportedTranslation(ValueError):
    """Valid native metadata has no supported SQL representation."""


@dataclass(frozen=True)
class SqlContext:
    record_types: dict[str, str] = field(default_factory=dict)
    scalar_names: frozenset[str] = frozenset()
    fields: set[tuple[str, str]] | None = None
    object: str | None = None
    alias: str | None = None
    relationships: dict[tuple[str, str], tuple[str, ...]] = field(default_factory=dict)
    source: dict | None = None


def native_metadata(value):
    return value.model_dump() if hasattr(value, "model_dump") else value


def reference(name, context=None, *, field_name=False):
    """Keep symbolic resources distinct from a query's row/table references."""
    if (
        not isinstance(name, str)
        or not name
        or any(token in name for token in ("[", "]", "{", "}"))
    ):
        raise UnsupportedTranslation(f"Unsupported reference: {name!r}")
    context = context or SqlContext()
    if field_name:
        if context.fields is not None and (context.object, name) not in context.fields:
            raise UnsupportedTranslation(
                f"Field is unresolved in the saved catalog: {context.object}.{name}"
            )
        return exp.column(name, table=context.alias, quoted=True)
    resolved = None
    if context.fields is not None:
        root, dot, suffix = name.partition(".")
        obj = context.record_types.get(root, root)
        resolved = (
            resolve_field(obj, suffix, context.fields, context.relationships)
            if dot
            else None
        )
        if not resolved and name not in context.scalar_names:
            raise UnsupportedTranslation(f"Flow reference is unresolved: {name}")
    # A Flow resource is a symbolic parameter, not an implicit SQL join or alias.
    column = exp.column(name, quoted=True)
    if resolved:
        column.meta["ppsc"] = source_metadata(
            {"elementReference": name},
            source=context.source,
            source_entities=[f"FieldDefinition.{resolved[0]}.{resolved[1]}"],
            resolved_field=".".join(resolved),
        )
    return column


def value_to_ast(value, context=None):
    if value is None:
        return exp.Null()
    if isinstance(value, (list, tuple)):
        return exp.Tuple(expressions=[value_to_ast(item, context) for item in value])
    value = native_metadata(value)
    if not isinstance(value, dict):
        if isinstance(value, bool):
            return exp.Boolean(this=value)
        if isinstance(value, (int, float)) and math.isfinite(value):
            return exp.Literal.number(value)
        if isinstance(value, str):
            return exp.Literal.string(value)
        raise UnsupportedTranslation(f"Unsupported SQL literal: {type(value).__name__}")
    # Dict insertion order preserves the native value precedence.
    for key, convert in VALUE_BUILDERS.items():
        if value.get(key) is not None:
            return convert(value[key], context)
    if any(item is not None for item in value.values()):
        raise UnsupportedTranslation(
            "Unknown native value requires an explicit mapping"
        )
    return exp.Null()


def _apex_value_to_ast(value, context):
    raise UnsupportedTranslation("apexValue requires a structured-value mapping")


def _complex_value_to_ast(value, context):
    raise UnsupportedTranslation("complexValue requires a structured-value mapping")


def _date_to_ast(value, context):
    if isinstance(value, (date, datetime)):
        value = value.isoformat()
    return exp.Cast(this=exp.Literal.string(value), to=exp.DataType.build("DATE"))


def _datetime_to_ast(value, context):
    if isinstance(value, (date, datetime)):
        value = value.isoformat()
    parsed = datetime.fromisoformat(value)
    sql_type = "TIMESTAMPTZ" if parsed.tzinfo is not None else "TIMESTAMP"
    return exp.Cast(this=exp.Literal.string(value), to=exp.DataType.build(sql_type))


VALUE_BUILDERS = {
    "elementReference": reference,
    "transformReference": reference,
    "apexValue": _apex_value_to_ast,
    "complexValue": _complex_value_to_ast,
    "booleanValue": value_to_ast,
    "numberValue": value_to_ast,
    "stringValue": value_to_ast,
    "dateValue": _date_to_ast,
    "dateTimeValue": _datetime_to_ast,
}

COMPARISON_BUILDERS = {
    "EqualTo": exp.EQ,
    "NotEqualTo": exp.NEQ,
    "GreaterThan": exp.GT,
    "GreaterThanOrEqualTo": exp.GTE,
    "LessThan": exp.LT,
    "LessThanOrEqualTo": exp.LTE,
}

STRING_PREDICATE_BUILDERS = {"StartsWith": exp.StartsWith, "EndsWith": exp.EndsWith}


def predicate_to_ast(condition, context=None):
    condition = native_metadata(condition)
    if condition.get("aggregationOperator"):
        raise UnsupportedTranslation(
            "Aggregated Flow conditions require collection semantics"
        )
    if condition.get("conditions"):
        return conditions_to_ast(
            condition["conditions"], condition.get("conditionLogic"), context
        )
    is_field = "field" in condition
    name = condition.get("field") if is_field else condition.get("leftValueReference")
    left = reference(name, context, field_name=is_field)
    right = value_to_ast(
        condition.get("value") if is_field else condition.get("rightValue"), context
    )
    operator = condition.get("operator")
    if operator in ("EqualTo", "NotEqualTo") and isinstance(right, exp.Null):
        result = exp.Is(this=left, expression=right)
        return exp.Not(this=result) if operator == "NotEqualTo" else result
    if operator in COMPARISON_BUILDERS:
        return COMPARISON_BUILDERS[operator](this=left, expression=right)
    if operator == "IsNull" and isinstance(right, exp.Boolean):
        result = exp.Is(this=left, expression=exp.Null())
        return result if right.this else exp.Not(this=result)
    if operator == "Contains":
        return exp.GT(
            this=exp.StrPosition(this=left, substr=right),
            expression=exp.Literal.number(0),
        )
    if operator in STRING_PREDICATE_BUILDERS:
        return STRING_PREDICATE_BUILDERS[operator](this=left, expression=right)
    if operator in ("In", "NotIn") and isinstance(right, exp.Tuple):
        result = exp.In(this=left, expressions=right.expressions)
        return exp.Not(this=result) if operator == "NotIn" else result
    raise UnsupportedTranslation(
        f"{operator} requires additional type, collection, or event semantics"
    )


def conditions_to_ast(conditions, logic=None, context=None):
    if not conditions:
        return None
    predicates = [predicate_to_ast(condition, context) for condition in conditions]
    return annotate(
        condition_logic(predicates, logic),
        source_metadata(
            {
                "conditions": [native_metadata(item) for item in conditions],
                "conditionLogic": logic,
            },
            source=(context or SqlContext()).source,
            description="Native Salesforce Flow conditions",
        ),
    )


def condition_logic(
    predicates: list[exp.Expression], logic: str | None = None
) -> exp.Expression:
    """Bind native AND/OR or numbered Boolean logic for SQL and Ibis consumers."""
    logic = (logic or "AND").strip().upper()
    if logic in ("AND", "OR"):
        return (exp.and_ if logic == "AND" else exp.or_)(*predicates)
    # Parse native numbered Boolean logic, then replace complete numeric nodes.
    # This avoids replacing "1" inside "10" or depending on condition order.
    if not re.fullmatch(r"[\d\s()]+|(?:\d|\s|\(|\)|AND|OR|NOT)+", logic):
        raise UnsupportedTranslation(f"Unsupported condition logic: {logic}")
    try:
        tree = parse_one(logic, read="postgres", error_level=ErrorLevel.RAISE)
    except ParseError as error:
        raise UnsupportedTranslation(f"Invalid condition logic: {logic}") from error
    if any(
        not isinstance(node, (exp.And, exp.Or, exp.Not, exp.Paren, exp.Literal))
        for node in tree.walk()
    ):
        raise UnsupportedTranslation(f"Unsupported condition logic: {logic}")

    def bind(node):
        if isinstance(node, exp.Literal):
            if (
                node.is_string
                or not node.this.isdigit()
                or not 1 <= int(node.this) <= len(predicates)
            ):
                raise UnsupportedTranslation(
                    f"Condition index is outside the native condition list: {node}"
                )
            return exp.Paren(this=predicates[int(node.this) - 1].copy())
        return node

    return tree.transform(bind)


def _table(name, alias=None):
    if not name:
        raise UnsupportedTranslation("A named source/target object is required")
    table = exp.Table(this=exp.to_identifier(name, quoted=True))
    if alias:
        table.set("alias", exp.TableAlias(this=exp.to_identifier(alias, quoted=True)))
    return table


def _output_reference(query, name):
    if not name:
        return query
    result = exp.select(exp.Star()).from_(_table(name))
    result.set(
        "with_",
        exp.With(
            expressions=[
                exp.CTE(
                    this=query,
                    alias=exp.TableAlias(this=exp.to_identifier(name, quoted=True)),
                )
            ]
        ),
    )
    return result


def _apply_record_filters(query, node, context):
    condition = conditions_to_ast(node.get("filters"), node.get("filterLogic"), context)
    return query.where(condition) if condition is not None else query


def _lookup_to_ast(node, context):
    if node.get("relatedRecords"):
        raise UnsupportedTranslation(
            "Related-record lookups require relationship bindings"
        )
    projections = []
    fields = list(node.get("queriedFields") or [])
    assignments = node.get("outputAssignments") or []
    select_all = bool(node.get("storeOutputAutomatically")) and not fields
    for assignment in assignments:
        if assignment["field"] not in fields:
            fields.append(assignment["field"])
    aliases = {item["field"]: item["assignToReference"] for item in assignments}
    if select_all or not fields:
        projections.append(
            exp.Column(this=exp.Star(), table=exp.to_identifier("t", quoted=True))
        )
    for name in fields:
        column = reference(name, context, field_name=True)
        if name in aliases:
            column = exp.alias_(column, aliases[name], quoted=True)
        projections.append(column)
    query = exp.select(*projections).from_(_table(node.get("object"), "t"))
    query = _apply_record_filters(query, node, context)
    if node.get("sortField"):
        query = query.order_by(
            exp.Ordered(
                this=reference(node["sortField"], context, field_name=True),
                desc=node.get("sortOrder") == "Desc",
            )
        )
    if node.get("getFirstRecordOnly"):
        query = query.limit(1)
    elif node.get("limit") is not None:
        limit = value_to_ast(node["limit"], context)
        if (
            not isinstance(limit, exp.Literal)
            or limit.is_string
            or not float(limit.this).is_integer()
            or float(limit.this) <= 0
        ):
            raise UnsupportedTranslation(
                "Lookup limit requires a positive integer literal"
            )
        query = query.limit(int(float(limit.this)))
    return _output_reference(query, node.get("outputReference"))


def _write_target(node):
    if node.get("inputReference"):
        raise UnsupportedTranslation(
            "Record-variable writes require explicit physical field/value bindings"
        )
    if node.get("doesUpsert"):
        raise UnsupportedTranslation(
            "Salesforce upsert matching requires an explicit conflict-policy mapping"
        )
    if node.get("assignRecordIdToReference"):
        raise UnsupportedTranslation("Generated record IDs require an output binding")
    return _table(node.get("object"))


def _assignment_pairs(node, context):
    assignments = node.get("inputAssignments") or []
    if not assignments:
        raise UnsupportedTranslation("A write requires explicit field assignments")
    return [
        (
            reference(item["field"], replace(context, alias=None), field_name=True),
            value_to_ast(item.get("value"), context),
        )
        for item in assignments
    ]


def _create_to_ast(node, context):
    target = _write_target(node)
    pairs = _assignment_pairs(node, context)
    if node.get("filters"):
        raise UnsupportedTranslation(
            "Conditional record creation requires a matching-policy mapping"
        )
    return exp.Insert(
        this=exp.Schema(this=target, expressions=[lhs.this for lhs, _ in pairs]),
        expression=exp.Values(
            expressions=[exp.Tuple(expressions=[rhs for _, rhs in pairs])]
        ),
    )


def _update_to_ast(node, context):
    target = _write_target(node)
    pairs = _assignment_pairs(node, context)
    query = exp.Update(
        this=target,
        expressions=[exp.EQ(this=lhs, expression=rhs) for lhs, rhs in pairs],
    )
    return _apply_record_filters(query, node, replace(context, alias=None))


def _delete_to_ast(node, context):
    query = exp.Delete(this=_write_target(node))
    return _apply_record_filters(query, node, replace(context, alias=None))


def _start_to_ast(node, context):
    if node.get("recordTriggerType"):
        raise UnsupportedTranslation("Record triggers require an event-record binding")
    query = exp.select(exp.Star()).from_(_table(node.get("object"), "t"))
    return _apply_record_filters(query, node, context)


def _collection_to_ast(node, context):
    context = replace(
        context,
        object=context.record_types.get(node.get("collectionReference")),
        alias="c",
    )
    if node.get("mapItems"):
        raise UnsupportedTranslation(
            "Collection assignment operators require collection semantics"
        )
    query = exp.select(
        exp.Column(this=exp.Star(), table=exp.to_identifier("c", quoted=True))
    ).from_(_table(node.get("collectionReference"), "c"))
    condition = conditions_to_ast(
        node.get("conditions"), node.get("conditionLogic"), context
    )
    if condition is not None:
        query = query.where(condition)
    for option in node.get("sortOptions") or []:
        if option.get("doesPutEmptyStringAndNullFirst"):
            raise UnsupportedTranslation(
                "Empty-string and null ordering requires an explicit type mapping"
            )
        query = query.order_by(
            exp.Ordered(
                this=reference(option["sortField"], context, field_name=True),
                desc=option.get("sortOrder") == "Desc",
            )
        )
    if node.get("limit") is not None:
        if type(node["limit"]) is not int or node["limit"] <= 0:
            raise UnsupportedTranslation("Collection limit must be a positive integer")
        query = query.limit(node["limit"])
    return _output_reference(query, node.get("assignNextValueToReference"))


RECORD_BUILDERS = {
    "FlowRecordLookup": _lookup_to_ast,
    "FlowRecordCreate": _create_to_ast,
    "FlowRecordUpdate": _update_to_ast,
    "FlowRecordDelete": _delete_to_ast,
    "FlowStart": _start_to_ast,
    "FlowCollectionProcessor": _collection_to_ast,
}


def record_to_ast(node, context=None, *, kind=None):
    kind = kind or type(node).__name__
    node = native_metadata(node)
    context = replace(context or SqlContext(), object=node.get("object"), alias="t")
    if node.get("formula") or node.get("filterFormula"):
        raise UnsupportedTranslation(
            "Native Salesforce formulas require an explicit formula mapping"
        )
    builder = RECORD_BUILDERS.get(kind)
    if builder is None:
        raise UnsupportedTranslation(f"{kind} is not a supported SQL record operation")
    return annotate(
        builder(node, context),
        source_metadata(
            node,
            source=context.source,
            source_entities=[kind + "." + node["name"]] if node.get("name") else [],
            description=f"Native Salesforce {kind}: {node.get('name') or node.get('object', '')}",
            translation_status="supported_representation",
        ),
    )


def render_sql(expression, *, dialect):
    try:
        return expression.sql(dialect=dialect, unsupported_level=ErrorLevel.RAISE)
    except UnsupportedError as error:
        raise UnsupportedTranslation(str(error)) from error


def _native_display(value, reason):
    return json.dumps(
        {
            "native": to_jsonable_python(native_metadata(value)),
            "translation_status": "unsupported",
            "reason": reason,
        },
        sort_keys=True,
    )


def display_record(node):
    try:
        return render_sql(record_to_ast(node), dialect="postgres")
    except UnsupportedTranslation as error:
        return _native_display(node, str(error))


def display_conditions(conditions, logic=None):
    try:
        tree = conditions_to_ast(conditions, logic)
        return render_sql(tree, dialect="postgres") if tree is not None else ""
    except UnsupportedTranslation as error:
        return _native_display(
            [native_metadata(item) for item in conditions], str(error)
        )


RECORD_KINDS = {
    "recordLookups": "FlowRecordLookup",
    "recordUpdates": "FlowRecordUpdate",
    "recordCreates": "FlowRecordCreate",
    "recordDeletes": "FlowRecordDelete",
    "collectionProcessors": "FlowCollectionProcessor",
    "start": "FlowStart",
}

CONDITION_LOGIC_KEYS = {"conditions": "conditionLogic", "filters": "filterLogic"}


@dataclass(frozen=True)
class _TranslationResult:
    sql: str | None
    status: str
    reason: str


def _translate(builder, *args, **kwargs):
    """Build and render immediately; programming errors propagate to the caller."""
    try:
        sql = render_sql(builder(*args, **kwargs), dialect="athena")
    except UnsupportedTranslation as error:
        return _TranslationResult(None, "unsupported", str(error))
    return _TranslationResult(
        sql,
        "supported_representation",
        "Illustrative metadata SQL; physical bindings and executable equivalence are unverified",
    )


def _formula_expression(native, *, known):
    language = "salesforce_formula" if known else "unknown"
    result = _TranslationResult(
        None,
        "unsupported" if known else "not_attempted",
        "Native Salesforce formulas require an explicit formula mapping"
        if known
        else "Unknown metadata expression retained without interpretation",
    )
    return {"source_language": language, "native_expression": native}, result


def _condition_expression(value, key, logic_key, context):
    from .contract import canonical_json

    native = canonical_json({key: value[key], logic_key: value.get(logic_key)})
    result = _translate(conditions_to_ast, value[key], value.get(logic_key), context)
    return {"source_language": "flow_condition", "native_expression": native}, result


def _record_expression(value, kind, context):
    from .contract import canonical_json

    native = canonical_json(value)
    result = _translate(record_to_ast, value, context, kind=kind)
    return {
        "source_language": "flow_record_operation",
        "native_expression": native,
    }, result


def _expression_row(root_id, base_path, source_path, owner_node_id, expression, result):
    return dict(
        expression_id=root_id
        + "/expression/"
        + quote(source_path.removeprefix(base_path), safe=""),
        owner_node_id=owner_node_id,
        **expression,
        athena_sql=result.sql,
        translation_status=result.status,
        source_path=source_path,
        reason=result.reason,
    )


def native_expressions(
    metadata=None, *, root_id, base_path, owners, context, analysis=None
):
    """Retain native evidence even when a SQL representation is unavailable."""
    rows = []
    from . import analysis as flow_analysis

    analysis = analysis or flow_analysis.analyze_flow(metadata)
    inventory = {
        item.expression.location.pointer: item for item in analysis.expressions
    }
    for entry in analysis.entries:
        relative_path = entry.location.pointer
        path = base_path + relative_path
        value = analysis.document.export(relative_path)
        relative = relative_path.strip("/").split("/")
        local_context = replace(context, object=value.get("object") or context.object)
        owner_node_id = owners.get(
            entry.owner_id,
            owners.get(
                entry.owner_name or ("start" if relative[0] == "start" else ""), root_id
            ),
        )
        for key in ("expression", "formula", "filterFormula", "formulaExpression"):
            item = inventory.get(relative_path + "/" + key)
            if item and item.kind == "formula":
                expression, result = _formula_expression(
                    analysis.document.export(item.expression.location.pointer),
                    known=item.known,
                )
                rows.append(
                    _expression_row(
                        root_id,
                        base_path,
                        f"{path}/{key}",
                        owner_node_id,
                        expression,
                        result,
                    )
                )
        for key, logic_key in CONDITION_LOGIC_KEYS.items():
            item = inventory.get(relative_path + "/" + key)
            if item and item.kind == "condition":
                if item.known:
                    expression, result = _condition_expression(
                        value, key, logic_key, local_context
                    )
                else:
                    from .contract import canonical_json

                    expression = {
                        "source_language": "unknown",
                        "native_expression": canonical_json({
                            key: value[key],
                            logic_key: value.get(logic_key),
                        }),
                    }
                    result = _TranslationResult(
                        None,
                        "not_attempted",
                        "Unknown metadata expression retained without interpretation",
                    )
                rows.append(
                    _expression_row(
                        root_id,
                        base_path,
                        f"{path}/{key}",
                        owner_node_id,
                        expression,
                        result,
                    )
                )
        item = inventory.get(relative_path)
        if item and item.kind == "record":
            expression, result = _record_expression(value, item.key, local_context)
            rows.append(
                _expression_row(
                    root_id, base_path, path, owner_node_id, expression, result
                )
            )
    return rows
