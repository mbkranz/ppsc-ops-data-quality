"""Pure Flow graph compilation with scoped IDs and native source evidence."""

import re
from collections.abc import Mapping
from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from types import MappingProxyType
from typing import Any
from urllib.parse import quote

import networkx as nx
from pydantic_core import to_jsonable_python

from salesforce.core.analysis import NativeDocument, SourceIdentity
from salesforce.core.catalog import CatalogIndex, FieldIdentity

from . import analysis as flow_analysis
from .contract import CONTRACT_VERSION, canonical_json
from .expressions import (
    SqlContext,
    display_conditions,
    display_record,
    native_expressions,
)
from .lineage import label_references, resolve_field
from .snapshot import FlowSnapshot


class MetadataGraph(nx.MultiDiGraph):
    """Emit model graphs with one relation convention and owning-element evidence."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._source_path = None
        self._edge_views: dict[tuple[Any, Any, Any], flow_analysis.EdgeView] = {}
        self._owner_node_ids: dict[str, str] = {}

    @contextmanager
    def at_source(self, path):
        previous, self._source_path = self._source_path, path
        try:
            yield
        finally:
            self._source_path = previous

    def add_node(self, node_for_adding, **attrs):
        if self._source_path is not None:
            attrs.setdefault("source_path", self._source_path)
        return super().add_node(node_for_adding, **attrs)

    def add_edge(self, u_for_edge, v_for_edge, key=None, **attrs):
        attrs.setdefault("source_reference", u_for_edge)
        attrs.setdefault("target_reference", v_for_edge)
        attrs["relation"] = (
            attrs.get("relation")
            or attrs.get("edge_type")
            or attrs.get("type")
            or "unclassified"
        )
        if self._source_path is not None:
            attrs.setdefault("source_path", self._source_path)
        return super().add_edge(u_for_edge, v_for_edge, key=key, **attrs)


@dataclass(frozen=True)
class CompiledLineage:
    graph: nx.MultiDiGraph
    expressions: list[dict]
    manifest: dict
    analyses: Mapping[str, flow_analysis.FlowAnalysis] = field(default_factory=dict)
    owner_node_ids: Mapping[tuple[str, str], str] = field(default_factory=dict)


def _native_model_data(model) -> dict[str, Any]:
    """Keep effective defaults, but never pass computed presentation fields as evidence."""

    def clean(value) -> Any:
        if isinstance(value, dict):
            return {
                key: clean(child)
                for key, child in value.items()
                if key not in {"node_kind", "node_hierarchy"}
            }
        if isinstance(value, list):
            return [clean(child) for child in value]
        return value

    return clean(to_jsonable_python(model.model_dump(exclude_none=True)))


def _legacy_gate(analysis):
    errors = {
        "legacy-einstein-decide-path": NotImplementedError,
        "legacy-screen-actions": NotImplementedError,
        "legacy-record-rollback": NotImplementedError,
        "legacy-stage-steps": AttributeError,
        "legacy-output-without-target": ValueError,
        "legacy-missing-value": AttributeError,
        "legacy-scheduled-path-without-object": UnboundLocalError,
    }
    for diagnostic in analysis.diagnostics:
        exception = errors.get(diagnostic.code)
        if exception:
            raise exception(diagnostic.message)
        if diagnostic.consequence == "structural":
            raise ValueError(f"{diagnostic.code}: {diagnostic.message}")


def _legacy_owner(path):
    parts = path.split("/")
    return "/".join(parts[:2] if parts[1] == "start" else parts[:3])


def _model_at(model, path):
    for part in path.split("/")[1:]:
        part = part.replace("~1", "/").replace("~0", "~")
        model = model[int(part)] if isinstance(model, list) else getattr(model, part)
    return model


def _node_expression(graph, view, native, model):
    """Presentation only: dependency and ownership discovery occurred in analysis."""
    name = view.name
    collection = view.owner_id.split("/")[1]
    if collection in {"variables", "constants"}:
        value = model.value.format_values()
        constant = " CONSTANT" if collection == "constants" else ""
        graph.nodes[name]["expression"] = (
            f"{name}{constant} {native.get('dataType')} := {value['value']}"
        )
    elif collection == "choices":
        value = model.value.format_values()
        value.update(
            label=native.get("choiceText"), description=native.get("description")
        )
        import json

        graph.nodes[name]["expression"] = json.dumps(value)
    elif collection == "formulas":
        graph.nodes[name]["expression"] = native["expression"]
    elif collection in flow_analysis.RECORD_KINDS:
        graph.nodes[name]["expression"] = display_record(model)
    elif collection == "assignments":
        graph.nodes[name]["expression"] = ";\n".join(
            f"{item['operator']}({flow_analysis.format_value(item.get('value'))['value']}) AS {item['assignToReference']}"
            for item in native.get("assignmentItems") or []
        )
    elif view.kind == "FlowScreenField" and native.get("validationRule"):
        graph.nodes[name]["expression"] = {
            re.sub(r"(?<!^)(?=[A-Z])", "_", key).lower(): value
            for key, value in native["validationRule"].items()
        }


def project_model_graph(flow, *, analysis=None, scoped=True):
    """Render the immutable semantic descriptors; never call element graph builders."""
    analysis = analysis or flow_analysis.analyze_flow(
        _native_model_data(flow), source=SourceIdentity(origin="normalized-model")
    )
    _legacy_gate(analysis)
    graph = MetadataGraph()
    normalized = NativeDocument(to_jsonable_python(flow.model_dump(exclude_none=True)))
    raw_nodes = {}
    for view in analysis.views:
        if isinstance(view, flow_analysis.EdgeView):
            attrs = NativeDocument({"attributes": view.attributes}).export(
                "/attributes"
            )
            with graph.at_source(_legacy_owner(view.owner_id)):
                key = graph.add_edge(view.source, view.target, key=view.key, **attrs)
                identity = view.source, view.target, key
                previous = graph._edge_views.get(identity)
                graph._edge_views[identity] = (
                    replace(
                        view,
                        occurrence_ids=tuple(
                            dict.fromkeys(previous.occurrence_ids + view.occurrence_ids)
                        ),
                    )
                    if previous
                    else view
                )
            continue
        owner = _legacy_owner(view.owner_id)
        attrs = dict(view.attributes or {})
        try:
            native = normalized.export(view.owner_id)
        except (KeyError, IndexError, ValueError):
            native = analysis.document.export(view.owner_id)
        if view.style in {"element", "rule", "screen_field"}:
            native = dict(native)
            if view.style == "rule":
                native["name"] = view.name
            # Unknown retained source regions may lack model presentation fields.
            native.setdefault("node_kind", view.kind)
            native.setdefault("node_hierarchy", "Metadata.FlowBaseElement.FlowElement")
            attrs = {"attrs": native}
        elif view.style == "flat":
            excluded = (
                {"defaultConnector", "faultConnector", "waitEvents"}
                if view.kind == "FlowWait"
                else {"transformValues", "connector"}
            )
            attrs = {key: value for key, value in native.items() if key not in excluded}
        elif view.style == "terminal":
            attrs = {
                "attrs": {
                    "processMetadataValues": [],
                    "targetReference": "STOP",
                    "not_salesforce_class": True,
                    "node_hierarchy": "Metadata.FlowBaseElement.FlowConnector.FlowStopConnector",
                    "node_kind": "FlowStopConnector",
                    "synthetic_terminal": True,
                }
            }
        elif view.style == "parameter":
            attrs = {"node_kind": "Parameter", **attrs}
        elif view.style == "apex":
            attrs = {"node_kind": "apexClass"}
        graph.add_node(
            view.name,
            **attrs,
            **({} if view.style == "notes" else {"source_path": owner}),
        )
        if view.style not in {"terminal", "parameter", "apex", "notes"}:
            _node_expression(graph, view, native, _model_at(flow, view.owner_id))
            raw_nodes[view.owner_id] = view.name

    for view in analysis.node_views:
        if view.kind != "FlowDecision":
            continue
        node = normalized.export(view.owner_id)
        clauses = []
        for i, rule in enumerate(node.get("rules") or []):
            model_rule = _model_at(flow, view.owner_id + f"/rules/{i}")
            condition = (
                display_conditions(model_rule.conditions, model_rule.conditionLogic)
                if model_rule.conditions
                else None
            )
            clause = ("IF " if i == 0 else "ELSE IF ") + str(condition)
            target = analysis.connector_targets.get(
                view.owner_id + f"/rules/{i}/connector"
            )
            clause += " THEN ({!" + target + "})" if target else " THEN NULL"
            graph.nodes[view.name + "." + rule["name"]]["expression"] = clause
            clauses.append(clause)
        target = analysis.connector_targets.get(view.owner_id + "/defaultConnector")
        if target:
            clauses.append("ELSE ({!" + target + "})")
        graph.nodes[view.name]["expression"] = "\n\t".join(clauses)

    label_references(flow, graph, analysis=analysis)
    name = flow.fullName or "UnnamedFlow"
    renamed = (
        {
            node: name + "." + node
            for node, attrs in nx.get_node_attributes(graph, "attrs").items()
            if attrs.get("node_kind", "").startswith("Flow") or node == "STOP"
        }
        if scoped
        else {}
    )
    nx.relabel_nodes(graph, renamed, copy=False)
    graph._edge_views = {
        (renamed.get(source, source), renamed.get(target, target), key): view
        for (source, target, key), view in graph._edge_views.items()
    }
    graph.graph["name"] = name
    for key, value in flow:
        if key in flow_analysis.ELEMENT_KINDS or not value:
            continue
        graph.graph[key] = (
            [item.model_dump(exclude_none=True) for item in value]
            if isinstance(value, list)
            and all(hasattr(item, "model_dump") for item in value)
            else value
        )
    if analysis.source.origin == "normalized-model":
        graph.graph["analysis_origin"] = "normalized-model"
    graph._owner_node_ids = {
        owner: renamed.get(node, node)
        for owner, node in raw_nodes.items()
        if node in graph or renamed.get(node) in graph
    }
    return graph


def project_element(
    model, graph, *, parent_node_path=None, relations=None, key_contains=None
):
    """Compatibility entry point for standalone element graph calls."""
    from .models import Flow, elements

    if model.node_kind == "FlowScreenField":
        parent = elements.FlowScreen.model_construct(
            name=parent_node_path, processMetadataValues=[], fields=[model], actions=[]
        )
        values: dict[str, Any] = {"screens": [parent]}
    else:
        collection = next(
            (
                key
                for key, kind in flow_analysis.ELEMENT_KINDS.items()
                if kind == model.node_kind
            ),
            None,
        )
        if collection is None:
            raise ValueError(f"No Flow semantic projection for {model.node_kind}")
        values = {collection: model if collection == "start" else [model]}
    flow = Flow.model_construct(processType="Flow", runInMode=None, **values)
    projected = project_model_graph(flow, scoped=False)
    # Standalone legacy methods did not add Flow process annotations or origins.
    for node, attrs in projected.nodes(data=True):
        if relations is not None or key_contains is not None:
            continue
        attrs = {
            key: value
            for key, value in attrs.items()
            if not key.startswith("process_") and key != "source_path"
        }
        if model.node_kind == "FlowScreenField" and node == parent_node_path:
            continue
        graph.add_node(node, **attrs)
    for source, target, key, attrs in projected.edges(keys=True, data=True):
        if relations is not None and attrs["relation"] not in relations:
            continue
        if key_contains is not None and key_contains not in str(key):
            continue
        graph.add_edge(
            source,
            target,
            key=key,
            **{prop: value for prop, value in attrs.items() if prop != "source_path"},
        )
    return graph


def project_conditions(model, graph, conditions, *, prefix="conditions"):
    """Compatibility condition-edge helper over a synthetic normalized owner."""
    metadata = {
        "decisions": [
            {
                "name": "__conditions",
                "rules": [
                    {
                        "name": model.name,
                        "conditions": [
                            item.model_dump(exclude_none=True)
                            for item in conditions or ()
                        ],
                    }
                ],
            }
        ]
    }
    analysis = flow_analysis.analyze_flow(
        to_jsonable_python(metadata), source=SourceIdentity(origin="normalized-model")
    )
    for view in analysis.edge_views:
        if view.attributes["relation"] != "read_condition_resource":
            continue
        if view.key is None:
            continue
        attrs = NativeDocument({"attributes": view.attributes}).export("/attributes")
        key = view.key.removeprefix("__conditions.").replace(
            ".conditions[", "." + prefix + "["
        )
        graph.add_edge(view.source, model.name, key=key, **attrs)
    return graph


def _edge_resolution_status(graph, source, target):
    statuses = {graph.nodes[node]["resolution_status"] for node in (source, target)}
    return (
        "ambiguous"
        if "ambiguous" in statuses
        else "unresolved"
        if "unresolved" in statuses
        else "resolved"
    )


def project_canonical_graph(analysis, *, flow_name=None):
    """Opt-in in-memory lineage/v2; publishing continues to default to v1.

    Every canonical connection is emitted independently, including repeated
    formula occurrences. Reads point from dependencies to their consumers.
    """
    for diagnostic in analysis.diagnostics:
        if diagnostic.code in {"duplicate-declaration", "missing-declaration-name"}:
            raise ValueError(f"{diagnostic.code}: {diagnostic.message}")
    graph = MetadataGraph(contract_version="lineage/v2")
    declarations = {item.local_id: item for item in analysis.declarations}
    source = analysis.source
    flow_name = flow_name or analysis.document.root.get("fullName") or "UnnamedFlow"
    root_id = (
        f"{quote(source.org, safe='')}/flow/{quote(source.version_id, safe='')}"
        if source.org and source.version_id
        else ""
    )

    def scoped(local):
        return source.scoped_id(local) if source.org and source.version_id else local

    def native_name(local):
        return analysis.endpoints[local].native_name

    def name(local):
        if local in declarations:
            return flow_name + "." + native_name(local)
        namespace = analysis.endpoints[local].namespace
        if namespace in {"literal", "parameter"}:
            return native_name(local)
        label = {
            "reference": "Reference",
            "local": "UnresolvedLocal",
            "object": "Object",
            "field": "Field",
            "action": "Action",
            "apex": "ApexClass",
            "subflow": "Subflow",
            "component": "Component",
            "template": "Template",
            "terminal": "Terminal",
            "callable": "Callable",
        }[namespace]
        return f"{label}[{native_name(local)}]"

    def endpoint(local):
        return root_id + "/node/" + quote(name(local), safe="")

    def evidence(location):
        return {
            "pointer": location.pointer,
            "start": location.start,
            "end": location.end,
            "origin": source.origin,
            **(
                {"source_file": source.source_file}
                if source.source_file is not None
                else {}
            ),
            **(
                {"source_path": source.saved_pointer(location)}
                if source.metadata_base is not None
                else {}
            ),
        }

    def interpretation(owner):
        diagnostics = [
            item
            for item in analysis.diagnostics
            if item.owner_id == owner or item.location.pointer.startswith(owner + "/")
        ]
        if any(item.consequence == "structural" for item in diagnostics):
            return "partial"
        if any(item.consequence == "unsupported" for item in diagnostics):
            return "partial"
        return "partial" if diagnostics else "supported"

    for declaration in analysis.declarations:
        graph.add_node(
            endpoint(declaration.local_id),
            name=name(declaration.local_id),
            native_name=declaration.name,
            kind=declaration.kind,
            owner_id=declaration.owner_id,
            interpretation_status=interpretation(declaration.local_id),
            binding_status="not_attempted",
            runtime_status="not_evaluated",
            resolution_status="resolved",
            evidence_status="native",
            derivation_status="declared",
            **evidence(declaration.location),
        )
    occurrences = {item.occurrence_id: item for item in analysis.occurrences}
    for connection in analysis.connections:
        for local in (connection.source, connection.target):
            if endpoint(local) not in graph:
                identity = analysis.endpoints[local]
                kind = {"object": "Object", "field": "Field", "literal": "Literal"}.get(
                    identity.namespace, "Resource"
                )
                attributes = {}
                if kind == "Object":
                    attributes["attrs"] = {
                        "node_kind": kind,
                        "object": identity.native_name,
                    }
                elif kind == "Field":
                    obj, _, field = identity.native_name.partition(".")
                    attributes["attrs"] = {
                        "node_kind": kind,
                        "object": obj,
                        "field": field,
                    }
                elif identity.namespace == "terminal":
                    attributes["attrs"] = {"synthetic_terminal": True}
                graph.add_node(
                    endpoint(local),
                    kind=kind,
                    name=name(local),
                    native_name=native_name(local),
                    reference_kind=identity.namespace,
                    canonical_endpoint_id=local,
                    interpretation_status="uninterpreted",
                    binding_status="not_attempted",
                    runtime_status="not_evaluated",
                    resolution_status="not_applicable"
                    if kind == "Literal"
                    else "resolved"
                    if identity.namespace == "terminal"
                    else "unresolved",
                    evidence_status="native",
                    derivation_status="referenced",
                    **attributes,
                )
        edge_id = root_id + "/edge/" + quote(connection.connection_id, safe="")
        graph.add_edge(
            endpoint(connection.source),
            endpoint(connection.target),
            key=edge_id,
            edge_id=edge_id,
            canonical_connection_id=connection.connection_id,
            family=connection.family,
            relation=connection.family,
            role=connection.role,
            owner_id=connection.owner_id,
            source_reference=native_name(connection.source),
            target_reference=native_name(connection.target),
            interpretation_status=interpretation(connection.owner_id),
            binding_status="not_attempted",
            runtime_status="not_evaluated",
            resolution_status=_edge_resolution_status(
                graph, endpoint(connection.source), endpoint(connection.target)
            ),
            evidence_type="inferred",
            evidence_status="native",
            derivation_status="inferred",
            derivation_kind=(
                "lexical_formula"
                if connection.location.start is not None
                else "derived_mapping"
                if connection.role
                in {"assignment_value", "lookup_field", "maps_input", "maps_output"}
                else "native_property"
            ),
            **{
                key: True
                for key in ("structural", "synthetic_projection")
                if getattr(analysis.connection_traits[connection.connection_id], key)
            },
            occurrence_ids=[scoped(item) for item in connection.occurrence_ids],
            reference_occurrences=[
                {
                    "reference": occurrences[item].reference,
                    "occurrence_id": scoped(item),
                    **evidence(occurrences[item].location),
                }
                for item in connection.occurrence_ids
            ],
            **evidence(connection.location),
        )
    graph._owner_node_ids = {
        declaration.local_id: endpoint(declaration.local_id)
        for declaration in analysis.declarations
    }
    return graph


def _node_status(kind, attrs, source_path, objects, fields, relationships):
    if attrs.get("synthetic_terminal"):
        return "resolved"
    if attrs.get("reference_status") == "unmapped":
        return "unresolved"
    if kind == "Literal":
        return "not_applicable"
    if kind == "Object":
        return "resolved" if attrs.get("object") in objects else "unresolved"
    if kind == "Field":
        identity = (attrs.get("object"), attrs.get("field"))
        return (
            "resolved"
            if resolve_field(*identity, fields, relationships)
            else "unresolved"
        )
    return "resolved" if source_path else "unresolved"


def _add_canonical_flow(
    graph,
    expressions,
    record,
    raw,
    analysis,
    objects,
    fields,
    relationships,
    owner_node_ids,
    *,
    catalog_verified,
    source_file,
    catalog,
):
    root_id = f"{quote(graph.graph['org'], safe='')}/flow/{quote(record.Id, safe='')}"
    name = record.Metadata.fullName or record.FullName
    metadata_path = analysis.source.metadata_base
    projected = project_canonical_graph(analysis, flow_name=name)
    graph.add_node(
        root_id,
        kind="Flow",
        name=name,
        flow_name=name,
        flow_version_id=record.Id,
        resolution_status="resolved",
        source_file=source_file,
        source_path=metadata_path.removesuffix("/Metadata"),
        source_record=NativeDocument(raw).export(),
        interpretation_status="partial" if analysis.diagnostics else "supported",
        binding_status="not_applicable",
        runtime_status="not_evaluated",
        evidence_status="native",
        derivation_status="declared",
        analysis_diagnostics=[
            {
                "code": item.code,
                "message": item.message,
                "pointer": item.location.pointer,
                "start": item.location.start,
                "end": item.location.end,
                "owner_id": item.owner_id,
                "consequence": item.consequence,
            }
            for item in analysis.diagnostics
        ],
    )
    for node, attrs in projected.nodes(data=True):
        attrs = dict(attrs)
        native_kind = attrs["kind"]
        kind = "FlowElement" if native_kind.startswith("Flow") else native_kind
        if kind == "Resource" and attrs.get("reference_kind") == "reference":
            reference = attrs["native_name"]
            root, dot, field = reference.partition(".")
            obj = analysis.record_types.get(root)
            if root == "$Setup" and dot:
                obj, _, field = field.partition(".")
            if dot and obj and field:
                kind = "Field"
                attrs["attrs"] = {"node_kind": kind, "object": obj, "field": field}
        status = _node_status(
            kind,
            attrs.get("attrs", {}),
            attrs.get("source_path"),
            objects,
            fields,
            relationships,
        )
        if kind == "Field":
            identity = attrs["attrs"]
            status = catalog.resolve(identity["object"], identity["field"]).status
        graph.add_node(
            node,
            **(
                attrs
                | dict(
                    kind=kind,
                    native_kind=native_kind,
                    flow_name=name,
                    flow_version_id=record.Id,
                    resolution_status=status,
                    source_file=source_file,
                    binding_status=status
                    if kind in {"Field", "Object"}
                    else "not_applicable",
                )
            ),
        )
    for source, target, key, attrs in projected.edges(keys=True, data=True):
        resolution = _edge_resolution_status(graph, source, target)
        graph.add_edge(
            source,
            target,
            key=key,
            **(
                attrs
                | dict(
                    flow_name=name,
                    flow_version_id=record.Id,
                    source_file=source_file,
                    resolution_status=resolution,
                )
            ),
        )
    owners = projected._owner_node_ids
    owner_node_ids.update({(record.Id, owner): node for owner, node in owners.items()})
    expressions.extend(
        dict(row, source_file=source_file)
        for row in native_expressions(
            root_id=root_id,
            base_path=metadata_path,
            owners=owners,
            context=SqlContext(
                record_types=dict(analysis.record_types),
                relationships=relationships,
                fields=fields if catalog_verified else None,
                scalar_names=frozenset(
                    variable.name
                    for variable in record.Metadata.variables or []
                    if variable.dataType != "SObject"
                ),
            ),
            analysis=analysis,
        )
    )


def _add_flow(
    graph,
    expressions,
    record,
    raw,
    source_path,
    objects,
    fields,
    relationships,
    *,
    catalog_verified=False,
    source_file="Flow.json",
    analysis,
    owner_node_ids=None,
):
    """Project shared native facts with scoped IDs and retained native evidence."""
    flow_name = record.Metadata.fullName or record.FullName
    root_id = f"{quote(graph.graph['org'], safe='')}/flow/{quote(record.Id, safe='')}"
    metadata_path = f"{source_path}/Metadata"

    graph.add_node(
        root_id,
        kind="Flow",
        name=flow_name,
        flow_name=flow_name,
        flow_version_id=record.Id,
        resolution_status="resolved",
        source_path=source_path,
        source_file=source_file,
        source_record=NativeDocument(raw).export(),
    )
    model = record.Metadata.model_copy(
        update={
            "fullName": flow_name,
            "label": record.Metadata.label or record.MasterLabel,
        }
    )
    model_graph = project_model_graph(model, analysis=analysis)
    occurrence_facts = {item.occurrence_id: item for item in analysis.occurrences}
    node_ids = {
        name: f"{root_id}/node/{quote(str(name), safe='')}" for name in model_graph
    }
    owners = {
        owner: node_ids[node] for owner, node in model_graph._owner_node_ids.items()
    }
    if owner_node_ids is not None:
        owner_node_ids.update({
            (record.Id, owner): node for owner, node in owners.items()
        })
    for name, data in sorted(
        model_graph.nodes(data=True), key=lambda item: str(item[0])
    ):
        local_name = str(name).removeprefix(flow_name + ".")
        relative_path = data.get("source_path")
        path = metadata_path + relative_path if relative_path is not None else None
        attrs = data.get("attrs", {})
        model_kind = attrs.get("node_kind", "Resource")
        kind = "FlowElement" if model_kind.startswith("Flow") else model_kind
        status = _node_status(kind, attrs, path, objects, fields, relationships)
        graph.add_node(
            node_ids[name],
            **(
                data
                | dict(
                    kind=kind,
                    name=str(name),
                    flow_name=flow_name,
                    flow_version_id=record.Id,
                    resolution_status=status,
                    source_path=path,
                    source_file=source_file,
                )
            ),
        )
        if path:
            owners[local_name] = node_ids[name]

    for source, target, key, data in sorted(
        model_graph.edges(keys=True, data=True),
        key=lambda item: tuple(str(part) for part in item[:3]),
    ):
        edge_id = (
            root_id
            + "/edge/"
            + "/".join(
                quote(part, safe="")
                for part in (str(source), str(target), canonical_json(key))
            )
        )
        relative_path = data.get("source_path")
        path = metadata_path + relative_path if relative_path is not None else None
        endpoints = {"source": source, "target": target}
        endpoint_references = {
            side: data.get(side + "_reference", endpoint)
            for side, endpoint in endpoints.items()
        }
        reference_path = data.get("reference_path")
        view = model_graph._edge_views[source, target, key]
        matches = [
            dict(
                reference=fact.reference,
                source_path=fact.location.pointer,
                **(
                    dict(start=fact.location.start, end=fact.location.end)
                    if fact.location.start is not None
                    else {}
                ),
            )
            for occurrence_id in view.legacy_occurrence_ids
            for fact in [occurrence_facts[occurrence_id]]
        ]
        # An exact token shared by several occurrences cannot identify this edge.
        evidence = []
        for occurrence in matches:
            if (
                sum(other["reference"] == occurrence["reference"] for other in matches)
                == 1
            ):
                side = data.get("reference_endpoint")
                matched_nodes = (
                    {node_ids[endpoints[side]]}
                    if reference_path is not None and side in endpoints
                    else {
                        node_ids[endpoints[side]]
                        for side, reference in endpoint_references.items()
                        if reference == occurrence["reference"]
                    }
                )
                evidence.append(
                    {key: value for key, value in occurrence.items()}
                    | {
                        "source_file": source_file,
                        "source_path": metadata_path + occurrence["source_path"],
                        **(
                            {"node_id": next(iter(matched_nodes))}
                            if len(matched_nodes) == 1
                            else {}
                        ),
                    }
                )
        graph.add_edge(
            node_ids[source],
            node_ids[target],
            key=edge_id,
            **(
                data
                | dict(
                    edge_id=edge_id,
                    original_key=key,
                    flow_name=flow_name,
                    flow_version_id=record.Id,
                    source_path=path,
                    source_file=source_file,
                    reference_occurrences=evidence,
                    relation=data["relation"],
                    evidence_type="inferred",
                    resolution_status="unresolved",
                )
            ),
        )

    bindings = dict(analysis.record_types)
    context = SqlContext(
        record_types=bindings,
        relationships=relationships,
        source={
            "source_org": graph.graph["org"],
            "source_file": source_file,
            "source_paths": [metadata_path],
            "flow_version_id": record.Id,
            "flow_name": flow_name,
        },
        scalar_names=frozenset(
            variable.name
            for variable in record.Metadata.variables or []
            if variable.dataType != "SObject"
        ),
        fields=fields if catalog_verified else None,
        object=getattr(record.Metadata.start, "object", None),
    )
    expressions.extend(
        dict(row, source_file=source_file)
        for row in native_expressions(
            raw["Metadata"],
            root_id=root_id,
            base_path=metadata_path,
            owners=owners,
            context=context,
            analysis=analysis,
        )
    )


def compile_lineage(
    snapshot: FlowSnapshot,
    *,
    org: str,
    source_file: str = "Flow.json",
    contract_version: str = CONTRACT_VERSION,
) -> CompiledLineage:
    """Compile a saved snapshot without filesystem or network operations."""
    if not re.fullmatch(r"[A-Za-z0-9_-]+", org):
        raise ValueError(
            "Org must be a nonempty alias containing letters, digits, _ or -"
        )
    if contract_version not in {"lineage/v1", "lineage/v2"}:
        raise ValueError(f"Unknown Flow lineage contract: {contract_version}")
    graph = nx.MultiDiGraph(contract_version=contract_version, org=org)
    catalog = (
        CatalogIndex(
            snapshot.objects,
            (FieldIdentity(obj, field) for obj, field in snapshot.fields),
            snapshot.relationships,
        )
        if contract_version == "lineage/v2"
        else None
    )
    expressions = []
    analyses, owner_node_ids = {}, {}
    for source in snapshot.selected:
        analysis = flow_analysis.analyze_flow(
            source.raw["Metadata"],
            source=SourceIdentity(
                source_file=source_file,
                metadata_base=source.source_path + "/Metadata",
                org=org,
                version_id=source.model.Id,
                source_sha256=snapshot.sources.get(source_file, {}).get("sha256"),
                origin="native",
            ),
        )
        analyses[source.model.Id] = analysis
        if contract_version == "lineage/v2":
            _add_canonical_flow(
                graph,
                expressions,
                source.model,
                source.raw,
                analysis,
                snapshot.objects,
                snapshot.fields,
                snapshot.relationships,
                owner_node_ids,
                catalog_verified=bool(snapshot.coverage),
                source_file=source_file,
                catalog=catalog,
            )
            continue
        _add_flow(
            graph,
            expressions,
            source.model,
            source.raw,
            source.source_path,
            snapshot.objects,
            snapshot.fields,
            snapshot.relationships,
            catalog_verified=bool(snapshot.coverage),
            source_file=source_file,
            analysis=analysis,
            owner_node_ids=owner_node_ids,
        )
    expressions.sort(key=lambda row: row["expression_id"])
    inventory = [
        dict(
            flow_version_id=raw["Id"],
            flow_name=raw.get("FullName"),
            status=raw["Metadata"].get("status"),
            source_path=path,
            selected=raw["Metadata"].get("status") == "Active",
        )
        for path, raw in sorted(snapshot.records, key=lambda item: item[1]["Id"])
    ]
    manifest = dict(
        contract_version=contract_version,
        org=org,
        sources=snapshot.sources,
        active_version_selection="Metadata.status == Active; duplicate IDs/names rejected",
        flow_versions=inventory,
        coverage=snapshot.coverage,
        coverage_warnings=snapshot.warnings,
        coverage_complete=bool(snapshot.coverage)
        and all(report["coverage_complete"] for report in snapshot.coverage.values()),
        api_versions=sorted({
            str(record.Metadata.apiVersion)
            for record in (source.model for source in snapshot.selected)
            if record.Metadata.apiVersion is not None
        }),
        row_counts=dict(
            nodes=graph.number_of_nodes(),
            edges=graph.number_of_edges(),
            expressions=len(expressions),
        ),
        limitations=[
            "Only active versions with readable metadata are graphed",
            "Edges retain inferred semantics; audit checks artifact and graph integrity without execution equivalence",
            "Field resolution uses exact catalog fields and unambiguous saved relationship names",
            "Unknown metadata is retained; parser coverage is checked by regression tests, not flow-audit",
            "SQLGlot output is illustrative; physical binding and executable equivalence are unverified",
            "Git release identity is attached during publication; DVC owns artifact content identity",
        ],
    )
    return CompiledLineage(
        graph,
        expressions,
        manifest,
        MappingProxyType(analyses),
        MappingProxyType(owner_node_ids),
    )
