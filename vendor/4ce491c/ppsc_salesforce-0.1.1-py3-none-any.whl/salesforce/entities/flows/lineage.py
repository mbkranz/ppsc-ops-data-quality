"""Label implicit lineage nodes using the Flow's declared record context."""

from salesforce.core.catalog import resolve_field as resolve_field
from salesforce.core.analysis import SourceIdentity

from . import analysis as flow_analysis


def reference_occurrences(metadata=None, *, analysis=None):
    """Yield native reference evidence with relative JSON Pointers and owner paths.

    These occurrences do not resolve names or create graph relationships.
    """
    analysis = analysis or flow_analysis.analyze_flow(metadata)
    for occurrence in analysis.occurrences:
        location = occurrence.location
        parts = location.pointer.split("/")
        owner = "/".join(
            parts[:3] if len(parts) > 2 and parts[2].isdigit() else parts[:2]
        )
        yield dict(
            reference=occurrence.reference,
            source_path=location.pointer,
            owner_path=owner,
            **(
                dict(start=location.start, end=location.end)
                if location.start is not None
                else {}
            ),
        )


def record_types(flow=None, *, analysis=None):
    if analysis is None:
        from .graph import _native_model_data

        analysis = flow_analysis.analyze_flow(
            _native_model_data(flow), source=SourceIdentity(origin="normalized-model")
        )
    return dict(analysis.record_types), set(analysis.objects)


def label_references(flow, graph, *, analysis=None):
    records, objects = record_types(flow, analysis=analysis)
    for node, data in graph.nodes(data=True):
        attrs = data.setdefault("attrs", {})
        # All nodes belong to this process, including upstream schema sources.
        data.update(
            process_name=flow.fullName,
            process_kind=flow.node_kind,
            process_type=flow.processType,
            process_label=flow.label,
        )
        if not attrs.get("node_kind") and data.get("node_kind"):
            attrs["node_kind"] = {
                "apexClass": "ApexClass",
                "parameter": "Resource",
                "Parameter": "Resource",
            }.get(data["node_kind"], data["node_kind"])
        if attrs.get("node_kind"):
            continue
        root, dot, field = str(node).partition(".")
        obj = records.get(root, root if root in objects else None)
        if dot and root == "$Setup":
            obj, _, field = field.partition(".")
        if dot and obj and field:
            attrs.update(
                node_kind="Field",
                node_hierarchy="Entity.Field",
                object=obj,
                field=field,
            )
        elif node in objects:
            attrs.update(
                node_kind="Object", node_hierarchy="Entity.Object", object=node
            )
        elif str(node).startswith("Literal["):
            attrs.update(node_kind="Literal", node_hierarchy="Resource.Literal")
        else:
            attrs["reference_status"] = "unmapped"
