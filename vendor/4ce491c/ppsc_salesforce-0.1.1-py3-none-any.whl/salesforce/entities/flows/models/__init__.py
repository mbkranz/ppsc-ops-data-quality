from __future__ import annotations
from typing import Literal

from pydantic import Field, RootModel

import networkx as nx

from salesforce.core.models import (
    Metadata,
    QueryResult,
    InsufficientAccessErrorResponse,
)
from . import elements
from . import types


class Flow(Metadata):
    """

    [Flow Elements](https://help.salesforce.com/s/articleView?id=platform.flow_ref_elements.htm&type=5):

    An element represents an action that the flow can execute.
    Examples include reading or writing Salesforce data,
    displaying information and collecting data from flow users,
    executing business logic, or manipulating data.

    Flow Node: A node is a type of element that’s visible in the flow diagram. It extends FlowElement and inherits all its fields.

    Flow Element Connectors: https://help.salesforce.com/s/articleView?id=platform.flow_ref_connectors.htm&type=5

    Flow Resources: Essentially the workspace of things referenced or set throughout the flow or called by particular parts of the flow. https://help.salesforce.com/s/articleView?id=platform.flow_ref_resources.htm&type=5

    **User inteface examples**
    Example of updating multiple records based on conditionals (ie decision): https://help.salesforce.com/s/articleView?id=platform.flow_ref_elements_loop_example.htm&type=5
    Example of user interface for screen, records, assignment, action, loop: https://help.salesforce.com/s/articleView?id=platform.flow_ref_elements_screen_flow_screen_actions.htm&type=5
    """

    fullName: str | None = Field(
        default=None,
        description="Name of field as it appears in the Metadata API files",
    )
    label: str | None = Field(
        default=None,
        description="The label of the flow as it appears in the Flow Builder UI.",
    )
    description: str | None = None
    processType: types.enums.FlowProcessType
    interviewLabel: str | None = Field(
        default=None,
        description="The label of the interview -- ie an instance/run of the flow.",
    )
    apiVersion: float | None = None
    status: str | None = None

    customProperties: list[elements.FlowCustomProperty] | None = None
    # Flow elements and references
    variables: list[elements.FlowVariable] | None = None
    formulas: list[elements.FlowFormula] | None = None
    constants: list[elements.FlowConstant] | None = None
    stages: list[elements.FlowStage] | None = None
    choices: list[elements.FlowChoice] | None = None
    dynamicChoiceSets: list[elements.FlowDynamicChoiceSet] | None = None
    textTemplates: list[elements.FlowTextTemplate] | None = None

    # Flow nodes
    start: elements.FlowStart | None = Field(
        default=None,
        description="First node which contains triggers and record filters. Note, the auto launch start node type was created to further specify flow types (eg trigger v no triggers)",
    )
    startElementReference: str | None = Field(
        default=None,
        description="[Deprecated] field that referenced which node was the starting node. Now, there is the `start` node.",
    )

    decisions: list[elements.FlowDecision] | None = None
    assignments: list[elements.FlowAssignment] | None = None
    waits: list[elements.FlowWait] | None = None
    transforms: list[elements.FlowTransform] | None = None
    loops: list[elements.FlowLoop] | None = None
    screens: list[elements.FlowScreen] | None = None
    subflows: list[elements.FlowSubFlow] | None = None
    apexPluginCalls: list[elements.FlowApexPluginCall] | None = None
    recordUpdates: list[elements.FlowRecordUpdate] | None = None
    recordCreates: list[elements.FlowRecordCreate] | None = None
    recordDeletes: list[elements.FlowRecordDelete] | None = None
    recordRollbacks: list[elements.FlowRecordRollback] | None = None
    actionCalls: list[elements.FlowActionCall] | None = None
    recordLookups: list[elements.FlowRecordLookup] | None = None
    collectionProcessors: list[elements.FlowCollectionProcessor] | None = None

    areMetricsLoggedToDataCloud: bool | None = Field(
        default=None,
        description="Indicates whether flow metrics are logged to Data Cloud. All false from Aug APMP release.",
    )

    runInMode: str | None
    environments: list[types.enums.FlowEnvironment] | None = None

    def to_graph(self, name=None, *, analysis=None) -> nx.MultiDiGraph:
        from ..graph import project_model_graph

        return project_model_graph(self, analysis=analysis)


class FlowRecord(Metadata):
    attributes: dict[Literal["type", "url"], str]
    Id: str
    MasterLabel: str
    FullName: str
    Metadata: Flow

    def to_graph(self, *, analysis=None):

        metadata = self.Metadata.model_copy(
            update={
                "fullName": self.Metadata.fullName or self.FullName,
                "label": self.Metadata.label or self.MasterLabel,
            }
        )
        G_flow = metadata.to_graph(analysis=analysis)

        return G_flow


class FlowQueryResult(QueryResult):
    """Flow Record Extract from a a query from the tooling API Flow object"""

    size: int
    totalSize: int
    done: bool
    queryLocator: str | None
    entityTypeName: str
    records: list[FlowRecord]

    def to_graphs(self) -> list[nx.MultiDiGraph]:
        return map(lambda record: record.to_graph(), self.records)


class FlowQueryResultNoRecords(QueryResult):
    """Flow Record Extract from a a query from the tooling API Flow object"""

    size: Literal[0]
    totalSize: Literal[0]
    done: bool
    queryLocator: str | None
    entityTypeName: None
    records: list[None]


class FlowQueryResultsList(RootModel):
    root: list[
        FlowQueryResult
        | list[InsufficientAccessErrorResponse]
        | FlowQueryResultNoRecords
    ]


# expose all Flow top level objects
__all__ = [ref for ref in dir() if ref.startswith("Flow")]


__all__.append("types")


# ### Elements in Salesforce Flow

# [See here for official doc](https://help.salesforce.com/s/articleView?id=platform.flow_ref_elements.htm&type=5)
# The executable building blocks you drag onto the canvas and connect to define behavior (analogous to statements / blocks in code).


# - Start **(always the first defined element in a flow)**: Defines trigger context (record-triggered, schedule, platform event, etc.).
# - Screen: Display info and collect user input (only in screen flows).
# - Subflow: Call another autolaunched/screen flow and leverage its inputs/outputs.
# - Assignment: Set, clear, or increment variable and collection values.
# - Decision: Branch logic by evaluating one or more condition sets.
# - Loop: Iterate over each item in a collection variable.
# - Collection Filter: Produce a new collection containing only items meeting criteria.
# - Collection Sort: Reorder a collection by field(s) and sort direction.
# - Get Records: Query Salesforce records matching filter conditions (Annotatedly first or all).
# - Create Records: Insert one or multiple new records.
# - Update Records: Modify fields on records (queried or referenced).
# - Delete Records: Remove one or multiple records.
# - Roll Back Records: Revert DML done earlier in the current transaction (useful with Fault paths).
# - Pause: Halt a flow interview until a time/date or platform event resumption condition (screen flows & some autolaunched contexts).
# - Wait: (Record-triggered after-save / schedule-triggered) Resume when time-based or event criteria are met (declarative wait points).
# - Choice: Manually defined pickable option for a Screen component.
# - Record Choice Set: Dynamically builds choices from queried records (label vs stored value).
# - Picklist Choice Set: Generates choices from a field’s active picklist values.
# - Collection Choice Set: Creates choices from items in an existing collection (text or records).
# - Fault (implicit path): Error handling connector available on most data/action elements for graceful recovery.


# !!!warning

#     (Descriptions are concise paraphrases taken from a combination of reading and synthesizing docs and using genAI; see official Salesforce documentation for authoritative details.)

# ### Resources in Salesforce Flow

# See here for official doc: [Salesforce Flow Resources](https://help.salesforce.com/s/articleView?id=platform.flow_ref_resources.htm&type=5)


# These are the variables/references of a specific flow. They may be output values (ie the output of elements like actions and decisions), defined constants, names of elements added to a flow, variables etc. Output of a value etc.

# - Variable: Stores a single value (text, number, date, boolean, record, Apex-defined, etc.).
# - Collection Variable: Ordered list of primitive values (not records).
# - Record Variable: Holds one Salesforce record (single sObject instance).
# - Record Collection Variable: list of records of the same object type.
# - Constant: Immutable value defined once and reused.
# - Formula: Real‑time calculated value based on an expression referencing other resources and global variables.
# - Text Template: Reusable chunk of text (can include merge fields) for screens, emails, logs.
# - Choice: Manually defined selectable option for Screen components.
# - Record Choice Set: Dynamically generates choices from queried records (displays a field, stores an Id or other field).
# - Picklist Choice Set: Dynamically lists the active picklist values for a specified field.
# - Collection Choice Set: Builds choices from the items in a collection variable.
# - Stage: Defines steps for a visual progress indicator in a screen flow (Path-style progress).
# - Global Variables (system-provided, read-only):
#     - $Flow (flow metadata like InterviewGuid, CurrentDateTime, ExecutionMode)
#     - $User, $UserRole
#     - $Record (current record), $Record__Prior (before-update values in record-triggered flows)
#     - $System, $Organization, $Profile, $Permission
#     - $Label (custom labels), $Setup (custom settings / custom metadata)
#     - $Api, $Locale, $Site (in Experience context)
#     - $User.UITheme, $User.UIThemeDisplayed
# - Apex-Defined Variable: Structured variable based on an Apex-defined data type.
# - Apex-Defined Collection: Collection of Apex-defined typed items.

# Notes:
# - Record vs Collection Variable distinction is critical for Get/Loop/Assignment operations.
# - Dynamic choice sets (Record / Picklist / Collection) are resolved at runtime.
# - Global variables are not created in Flow Builder; they are implicitly available.
# - Use formulas instead of assignments when a value is purely derived to reduce element count.
# - Constants help avoid hard-coding repeated literals (e.g., status codes, limits).
# - Text Templates support rich text and can simplify maintenance of long messages.
# - Apex-defined types enable typed data exchange with Invocable Apex and External Services.
