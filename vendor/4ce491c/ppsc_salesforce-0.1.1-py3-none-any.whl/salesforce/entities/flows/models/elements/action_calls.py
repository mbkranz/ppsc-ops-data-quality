from pydantic import Field, ConfigDict, BaseModel
from .base import (
    FlowBaseElement,
    FlowInputParameter,
    FlowNode,
    FlowConnector,
    FlowDataTypeMapping,
)
from ..types.enums import (
    InvocableActionType,
    FlowTransactionModel,
    FlowScheduledPathOffsetUnit,
)


__all__ = [
    "FlowActionCallInputParameter",
    "FlowActionCallOutputParameter",
    "FlowActionCallPath",
    "FlowActionCall",
]


class FlowActionCallInputParameter(FlowInputParameter):
    # TODO: technically from FlowBaseElement but has same fields as FlowInputParameter so just used this
    pass


class FlowActionCallOutputParameter(FlowBaseElement):
    name: str
    assignToReference: str | None = None


class FlowActionCallPath(BaseModel):
    connector: FlowConnector
    pathName: str


class FlowActionCall(FlowNode):
    """Invoke reusable functionality (Apex, email alert, quick action, platform action, HTTP callout, etc.)."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Action",
            "description": "Invoke reusable functionality (Apex, email alert, quick action, platform action, HTTP callout, etc.).",
        }
    )

    actionCallPaths: list[FlowActionCallPath] = Field(default_factory=list)
    actionName: str
    actionType: InvocableActionType
    connector: FlowConnector | None = None
    dataTypeMappings: list[FlowDataTypeMapping] = Field(default_factory=list)
    einsteinDecidePath: str | None = None
    faultConnector: FlowConnector | None = None
    flowTransactionModel: FlowTransactionModel = "Automatic"
    inputParameters: list[FlowActionCallInputParameter] = Field(default_factory=list)
    isWaitUntilCompleted: bool | None = None
    nameSegment: str | None = Field(default=None, description="Deprecated in API 62.0+")
    offset: int | None = None
    offsetUnit: FlowScheduledPathOffsetUnit | None = None
    outputParameters: list[FlowActionCallOutputParameter] = Field(default_factory=list)
    storeOutputAutomatically: bool | None = None
    timeoutConnector: FlowConnector | None = None
    versionSegment: int | None = Field(
        default=None, description="Deprecated in API 62.0+"
    )
    versionString: str | None = None
