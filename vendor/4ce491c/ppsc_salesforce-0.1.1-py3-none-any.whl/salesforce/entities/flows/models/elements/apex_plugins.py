from pydantic import ConfigDict

from .base import FlowBaseElement, FlowConnector, FlowInputParameter, FlowNode


__all__ = [
    "FlowApexPluginCallInputParameter",
    "FlowApexPluginCallOutputParameter",
    "FlowApexPluginCall",
]


class FlowApexPluginCallInputParameter(FlowInputParameter):
    pass


class FlowApexPluginCallOutputParameter(FlowBaseElement):
    assignToReference: str
    name: str


class FlowApexPluginCall(FlowNode):
    """Action (Apex Plugin Call subset): Invoke reusable functionality (Apex, email alert, quick action, platform action, HTTP callout, etc.)."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Action",
            "description": "Invoke reusable functionality (Apex, email alert, quick action, platform action, HTTP callout, etc.).",
        }
    )
    apexClass: str
    connector: FlowConnector
    faultConnector: FlowConnector | None = None
    inputParameters: list[FlowApexPluginCallInputParameter]
    outputParameters: list[FlowApexPluginCallOutputParameter]
