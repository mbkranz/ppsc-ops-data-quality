from pydantic import ConfigDict, field_validator

from .base import FlowBaseElement, FlowElementReferenceOrValue, FlowConnector, FlowNode
from ..types.enums import FlowAssignmentOperator


__all__ = ["FlowAssignment", "FlowAssignmentItem"]


class FlowAssignmentItem(FlowBaseElement):
    assignToReference: str
    operator: FlowAssignmentOperator
    value: FlowElementReferenceOrValue | None = None

    @field_validator("value", mode="after")
    def placeholder(cls, value):
        # Implement your validation logic here
        if value is None:
            return FlowElementReferenceOrValue()
        return value


class FlowAssignment(FlowNode):
    """Assignment: Set, clear, or increment variable and collection values."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Assignment",
            "description": "Set, clear, or increment variable and collection values.",
        }
    )
    connector: FlowConnector | None = None
    assignmentItems: list[FlowAssignmentItem] | None = None
