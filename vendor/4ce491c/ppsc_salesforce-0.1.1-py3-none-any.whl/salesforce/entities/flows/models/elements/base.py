from __future__ import annotations

import networkx as nx
from datetime import datetime, date
from typing import Literal, Self
from pydantic import Field, RootModel, field_validator, model_validator
from pydantic_core import PydanticCustomError
from ...expressions import display_conditions
from ..types.enums import FlowComparisonOperator, FlowWaitConditionType
from salesforce.core.models import Metadata


__all__ = [
    "FlowBaseElement",
    "FlowElement",
    "FlowConnector",
    "FlowStopConnector",
    "FlowNode",
    "FlowElementReferenceOrValue",
    "FlowInputParameter",
    "FlowCustomProperty",
    "FlowDataTypeMapping",
    "FlowRecordFilter",
    "FlowCondition",
    "add_filter_edges",
    "add_connector_edge",
    "add_connector_edges",
    "add_input_param_nodes_and_edges",
    "add_output_param_nodes_and_edges",
    "format_composite_condition",
    "FlowElementList",
]


class FlowMetadataValue(Metadata):
    name: str
    value: str


class FlowBaseElement(Metadata):
    processMetadataValues: list[FlowMetadataValue] = Field(
        description="list of process metadata values."
    )


class FlowElement(FlowBaseElement):
    name: str | None = None
    description: str | None = None

    def add_to_graph(self, graph):
        from ...graph import project_element

        return project_element(self, graph)


class FlowConnector(FlowBaseElement):
    """A connector determines the path that a flow takes at run time."""

    isGoTo: bool | None = Field(default=None, description="")
    targetReference: str = Field(
        description="Which node to execute after current node (required)"
    )


class FlowStopConnector(FlowConnector):
    """

    A custom (non salesforce) class to represent a STOP connector.
    A stop connector determines the end of a flow path.

    """

    targetReference: str = Field("STOP", pattern=r"\.STOP$")
    not_salesforce_class: Literal[True] = Field(
        True,
        description="Indicates this is a custom class, not part of Salesforce metadata.",
    )
    processMetadataValues: list[None] = Field(default_factory=list)


class FlowNode(FlowElement):
    """
    A node is a type of element that’s visible in the flow diagram.
    It extends FlowElement and inherits all its fields.

    NOTE: in the docs, all inherited fields are not explicitly listed.
    """

    name: str
    label: str | None = None
    locationX: int | None = None
    locationY: int | None = None


def add_connector_edge(
    flowelement: FlowElement | tuple[FlowElement] | list[FlowElement],
    G: nx.MultiDiGraph,
    conn: FlowConnector | None,
    connname: str | None = None,
    label: str | None = None,
    relation: str = "navigates_to",
    **kwargs,
):

    if not isinstance(conn, FlowConnector):
        conn = FlowStopConnector()
    if isinstance(conn, FlowStopConnector):
        G.add_node(
            conn.targetReference,
            attrs=dict(conn.model_dump(exclude_none=True), synthetic_terminal=True),
        )

    if isinstance(flowelement, FlowElement):
        name = flowelement.name
    elif isinstance(flowelement, (tuple, list)):
        name = ".".join(x.name for x in flowelement)
    # for k,v in kwargs.items():
    # if k in __
    # G.nodes[flowelement.name][connname or "connector"] = conn.model_dump(exclude_none=True)
    G.add_edge(
        name,
        conn.targetReference,
        key=name + "." + (connname or "connector"),
        relation=relation,
        **kwargs,
    )


def add_connector_edges(
    flowelement: FlowElement,
    G: nx.MultiDiGraph,
    **conns: dict[str, FlowConnector | None],
):
    for label, conn in conns.items():
        add_connector_edge(flowelement, G, conn, connname=label, label=label)


def add_input_param_nodes_and_edges(flowelement: FlowElement, G: nx.MultiDiGraph):
    from ...graph import project_element

    return project_element(flowelement, G, relations={"read_input_resource_into"})


def add_output_param_nodes_and_edges(
    flowelement: FlowElement, G: nx.MultiDiGraph, storeOutputAutomatically=False
):
    from ...graph import project_element

    model = flowelement.model_copy(
        update={"storeOutputAutomatically": storeOutputAutomatically}
    )
    return project_element(model, G, relations={"assign_output_resource_to"})


def format_composite_condition(conditions, conditionLogic=None):
    return display_conditions(conditions, conditionLogic)


class FlowCondition(FlowBaseElement):
    aggregationOperator: Literal["Count"] | None = None
    # keep string to allow advanced logic like "1 AND (2 OR 3)"
    conditionLogic: str | None = None
    conditionType: FlowWaitConditionType | None = None
    conditions: list["FlowCondition"] = Field(default_factory=list)
    leftValueReference: str | None = None
    operator: FlowComparisonOperator
    rightValue: FlowElementReferenceOrValue | None = None

    @model_validator(mode="after")
    def check_conditions_or_value(self) -> Self:
        if not self.conditions and self.leftValueReference is None:
            raise PydanticCustomError(
                "flow_condition_requires_operand",
                "FlowCondition must have either conditions or leftValueReference specified",
            )
        return self

    @field_validator("rightValue", mode="before")
    def if_right_value_none(cls, value):
        if value is None:
            return FlowElementReferenceOrValue()
        return value

    def format_condition(self):
        return display_conditions([self])


class FlowElementReferenceOrValue(Metadata):
    # Apex-defined (structured) value
    apexValue: dict | None = Field(
        default=None,
        description="Structured value for an Apex-defined type (key -> primitive/reference).",
    )
    complexValue: str | None = Field(default=None)
    transformReference: str | None = Field(
        default=None,
        description="API name of a Transform resource whose output supplies the value.",
    )
    # Literal values
    booleanValue: bool | None = Field(
        default=None, description="Boolean literal value."
    )

    complexValueType: (
        Literal["JoinDefinition", "FieldReference", "ComplexObjectFieldDetails"] | None
    ) = None

    elementReference: str | None = Field(
        default=None,
        description="API name of another Flow element reference. NOTE: if specifying a value reference, do not use",
    )
    dateTimeValue: datetime | None = Field(
        default=None, description="Date/time literal value (UTC)."
    )
    dateValue: date | None = Field(default=None, description="Date literal value.")
    numberValue: float | None = Field(
        default=None, description="Numeric literal value."
    )
    stringValue: str | None = Field(default=None, description="String literal value.")

    @model_validator(mode="after")
    def only_one_value_or_reference(self) -> Self:
        non_none_count = sum(
            value is not None
            for name, value in self.__dict__.items()
            if name != "complexValueType"
        )
        if non_none_count > 1:
            raise ValueError(
                f"{self.__class__.__name__} can only have one value or reference specified"
            )
        return self

    def format_values(self):
        from ...analysis import format_value

        return format_value(self.model_dump(exclude_none=True))


class FlowInputParameter(FlowBaseElement):
    """
    While not part of the Flow metadata model, many of the flow elements have the same pattern
    (action calls, screen, etc.) so
    this provides a convenient way to define input parameters
    """

    name: str
    value: FlowElementReferenceOrValue

    @field_validator("value", mode="before")
    def if_value_none(cls, value):
        if value is None:
            return FlowElementReferenceOrValue()
        return value


class FlowCustomProperty(Metadata):
    """
    Simple name/value pair used for Flow-level customProperties.
    """

    name: str
    value: FlowElementReferenceOrValue | None = None


class FlowDataTypeMapping(Metadata):
    genericType: str | None = None
    mappedObjectType: str | None = None


class FlowRecordFilter(FlowBaseElement):
    field: str
    operator: FlowComparisonOperator
    value: FlowElementReferenceOrValue

    @field_validator("value", mode="before")
    def if_value_none(cls, value):
        if value is None:
            return FlowElementReferenceOrValue()
        return value

    def to_expression(self):
        return display_conditions([self])


def add_filter_edges(node, graph):
    """Retain native read relationships independently of SQL translation."""
    from ...graph import project_element

    return project_element(node, graph, key_contains=".filters[")


FlowElementList = RootModel[list[FlowNode | FlowElement]]


def add_condition_edges(node, graph, conditions, prefix="conditions"):
    """Record each condition input without asserting execution equivalence."""
    from ...graph import project_conditions

    return project_conditions(node, graph, conditions, prefix=prefix)
