from pydantic import Field, ConfigDict

from .base import (
    Metadata,
    FlowElementReferenceOrValue,
    FlowConnector,
    FlowNode,
    FlowCondition,
)
from ..types.enums import FlowAssignmentOperator, FlowCollectionProcessorType, SortOrder


__all__ = [
    "FlowCollectionProcessor",
    "FlowCollectionMapItem",
    "FlowCollectionSortOption",
]


class FlowCollectionSortOption(Metadata):
    """API v51.0+"""

    doesPutEmptyStringAndNullFirst: bool = False
    sortField: str | None = None
    sortOrder: SortOrder


class FlowCollectionMapItem(Metadata):
    assignToFieldReference: str
    operator: FlowAssignmentOperator
    value: FlowElementReferenceOrValue | None = None


class FlowCollectionProcessor(FlowNode):
    """Collection Filter / Collection Sort: Filter or reorder items in a collection."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Collection Processor",
            "description": "Filter or sort a collection (Collection Filter / Collection Sort).",
        }
    )
    connector: FlowConnector | None = None
    faultConnector: FlowConnector | None = None
    assignNextValueToReference: str | None = None
    collectionProcessorType: FlowCollectionProcessorType
    collectionReference: str
    conditionLogic: str | None = None
    conditions: list[FlowCondition]
    formula: str | None = None
    limit: int | None = None
    mapItems: list[FlowCollectionMapItem] = Field(
        default=None, description="Map items to transform collection elements."
    )
    outputSObjectType: str | None = None
    sortOptions: list[FlowCollectionSortOption] = Field(default_factory=list)
