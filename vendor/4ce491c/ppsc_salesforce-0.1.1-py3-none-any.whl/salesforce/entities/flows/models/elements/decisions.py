from pydantic import ConfigDict, Field


from .base import (
    FlowElement,
    FlowCondition,
    FlowConnector,
    FlowNode,
    format_composite_condition,
)

__all__ = ["FlowDecision", "FlowRule"]


class FlowRule(FlowElement):
    name: str
    label: str | None = None
    connector: FlowConnector | None = None
    conditionLogic: str | None = None
    conditions: list[FlowCondition] = None
    doesRequireRecordChangedToMeetCriteria: bool | None = None

    def format_conditions(self):
        if self.conditions:
            return format_composite_condition(self.conditions, self.conditionLogic)
        return None


class FlowDecision(FlowNode):
    """Decision: Branch logic by evaluating one or more condition sets."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Decision",
            "description": "Branch logic by evaluating one or more condition sets.",
        }
    )
    defaultConnector: FlowConnector | None = None
    defaultConnectorLabel: str | None = None
    rules: list[FlowRule] = Field(
        description="An array of rules for the decision. The rules are evaluated in the order that they're listed, and the connector of the first true rule is used. If no rules are true, then the default connector is used. In Flow Builder, rules are referred to as decision outcomes."
    )
