from typing import Literal

from pydantic import Field, ConfigDict

from .base import FlowNode, FlowConnector


__all__ = ["FlowLoop"]


class FlowLoop(FlowNode):
    """Loop: Iterate over each item in a collection variable."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Loop",
            "description": "Iterate over each item in a collection variable.",
        }
    )
    assignNextValueToReference: str | None = Field(
        default=None,
        description=(
            "The variable assigned the current value in the collection before navigating to nextValueConnector."
        ),
    )
    collectionReference: str
    iterationOrder: Literal["Asc", "Desc"]
    nextValueConnector: FlowConnector
    noMoreValuesConnector: FlowConnector
