"""Record operation metadata and graph relationships; SQL lives in expressions."""

from typing import Literal
from pydantic import Field, ConfigDict, field_validator
from .base import (
    Metadata,
    FlowBaseElement,
    FlowElementReferenceOrValue,
    FlowConnector,
    FlowNode,
    FlowRecordFilter,
)
from ..types.enums import SortOrder


class FlowInputFieldAssignment(FlowBaseElement):
    """
    User interface example: Under the Set Field Values for the Membership Record section, for Field, select Membership Status and for value, select Inactive.
    """

    field: str = Field(
        description="API name of the target field to assign the value to."
    )
    value: FlowElementReferenceOrValue = Field(
        description="The value to assign to the target field."
    )

    @field_validator("value", mode="before")
    def placeholder(cls, value):
        if value is None:
            return FlowElementReferenceOrValue()
        return value


class FlowOutputFieldAssignment(Metadata):
    field: str = Field(description="API name of source field on queried record.")
    assignToReference: str = Field(
        description="Variable (field) or record variable to assign into."
    )


class FlowRelatedRecordLookup(FlowBaseElement):
    relationshipField: str = Field(
        description="Relationship field path on the primary object."
    )
    relatedObject: str = Field(description="Related object API name.")
    queriedFields: list[str] | None = None


class FlowRecordLookup(FlowNode):
    """Get Records: Query Salesforce records matching filter conditions (first or all)."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Get Records",
            "description": "Query Salesforce records matching filter conditions (first or all).",
            "references": {
                "ui-docs": "https://help.salesforce.com/s/articleView?id=platform.flow_ref_elements_data_get.htm&type=5",
                "ui-screenshot": "https://sf-zdocs-cdn-prod.zoominsoftware.com/tdta-platform_automation-256-12-0-production-enus/75487ccc-a9be-4424-8822-41abdda6e2e2/platform_automation/images/flow/flow_ref_get_records.png",
            },
        }
    )
    assignNullValuesIfNoRecordsFound: bool | None = None
    connector: FlowConnector | None = None
    faultConnector: FlowConnector | None = None
    filterLogic: str | None = None
    filters: list[FlowRecordFilter] | None = None
    getFirstRecordOnly: bool | None = None
    limit: FlowElementReferenceOrValue | None = None
    object: str
    outputAssignments: list[FlowOutputFieldAssignment] | None = Field(
        default=None,
        description="Manual per-field assignments (eg contains the full <object.field> convention) for the output of the record lookup.",
    )
    outputReference: str | None = Field(
        default=None,
        description="Name of the object or collection to assign the lookup to. Will always be sobject shape. Automatically store all fields in queriedFields in this object",
    )
    queriedFields: list[str] | None = None
    relatedRecords: list[FlowRelatedRecordLookup] | None = None
    sortField: str | None = None
    sortOrder: SortOrder | None = None
    storeOutputAutomatically: bool | None = None


class FlowRecordUpdate(FlowNode):
    """Update Records: Modify fields on records (queried or referenced)."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Update Records",
            "description": "Modify fields on records (queried or referenced).",
            "references": {
                "ui-docs": "https://help.salesforce.com/s/articleView?id=platform.flow_ref_elements_data_update.htm&type=5"
            },
        }
    )

    # Specified properties
    connector: FlowConnector | None = None
    faultConnector: FlowConnector | None = None
    filterLogic: str | None = None
    filters: list[FlowRecordFilter] | None = Field(
        default=None,
        description="An array that specifies the criteria used to select the records to update in the database.",
    )
    inputAssignments: list[FlowInputFieldAssignment] | None = Field(
        default=None,
        description="An array of field-value pairs that specifies the field values to update in the records.",
    )

    inputReference: str | None = Field(
        default=None,
        description="Record variable whose field values are used to update the record's fields.",
    )
    object: str | None = Field(
        description="API name of the object whose records are updated."
    )


class FlowRecordCreate(FlowNode):
    """Create Records: Insert one or multiple new records."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Create Records",
            "description": "Insert one or multiple new records.",
        }
    )
    assignRecordIdToReference: str | None = None
    connector: FlowConnector | None = None
    doesUpsert: bool | None = False
    doesUpsertAllOrNone: bool | None = None
    faultConnector: FlowConnector | None = None
    filterLogic: str | None = Field(
        default=None,
        description="Logic for filters when doing conditional upsert (API 61+).",
    )
    filters: list[FlowRecordFilter]
    inputAssignments: list[FlowInputFieldAssignment]
    inputReference: str | None = Field(
        default=None,
        description="Record var whose field values populate the new record.",
    )
    object: str | None = Field(
        default=None, description="API name of the object to create."
    )
    operationMultMatchingRecords: (
        Literal["None", "UpdateAllRecords", "UpdateLatestRecord"] | None
    ) = None
    operationOneMatchingRecord: Literal["None", "UpdateAllRecords"] | None = None
    operationZeroMatchingRecords: Literal["None"] | None = None
    storeOutputAutomatically: bool | None = None
    upsertExternalIdField: str | None = None
    upsertStandardIdField: str | None = None


class FlowRecordDelete(FlowNode):
    """Delete Records: Remove one or multiple records."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Delete Records",
            "description": "Remove one or multiple records.",
        }
    )
    connector: FlowConnector | None = None
    faultConnector: FlowConnector | None = None
    filters: list[FlowRecordFilter]
    inputReference: str | None = Field(
        default=None, description="Record var supplying Id to delete."
    )
    object: str | None = None


class FlowRecordRollback(FlowNode):
    """Record Rollback: Undoes record changes made earlier in the flow."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Record Rollback",
            "description": "Undoes record changes made earlier in the flow.",
        }
    )
    connector: FlowConnector | None = None
