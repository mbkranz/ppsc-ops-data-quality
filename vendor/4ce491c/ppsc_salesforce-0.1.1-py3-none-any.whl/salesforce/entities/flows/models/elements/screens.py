from __future__ import annotations

from typing import Literal
from pydantic import ConfigDict, Field


from .base import (
    Metadata,
    FlowCondition,
    FlowElement,
    FlowConnector,
    FlowInputParameter,
    FlowNode,
    FlowElementReferenceOrValue,
)
from ..types.enums import (
    FlowDataType,
    FlowRegionContainerType,
    FlowScreenFieldInputsRevisited,
    FlowScreenFieldType,
)


__all__ = [
    "FlowInputValidationRule",
    "FlowScreenActionInputParameter",
    "FlowScreenAction",
    "FlowScreenFieldInputParameter",
    "FlowScreenFieldOutputParameter",
    "FlowScreenFieldStyleProperties",
    "FlowScreenTriggerHandler",
    "FlowScreenTrigger",
    "FlowVisibilityRule",
    "FlowScreenField",
    "FlowScreen",
]


class FlowInputValidationRule(Metadata):
    """Used to validate the user input of a screen field."""

    errorMessage: str
    formulaExpression: str


class FlowScreenActionInputParameter(FlowInputParameter):
    pass


class FlowScreenAction(Metadata):
    actionName: str
    actionType: list[None]  # InvocableActionType (placeholder per current code)
    inputParameters: list[FlowScreenActionInputParameter]
    label: str
    nameSegment: str | None = None
    versionSegment: int | None = None
    versionString: str | None = None  # v63.0+


class FlowScreenFieldInputParameter(Metadata):
    name: str
    value: FlowElementReferenceOrValue | None = None


class FlowScreenFieldOutputParameter(Metadata):
    assignToReference: str
    name: str


class FlowScreenFieldStyleProperties(Metadata):
    width: FlowElementReferenceOrValue | None = None  # 1..12
    verticalAlignment: FlowElementReferenceOrValue | None = None  # top|middle|bottom


class FlowScreenTriggerHandler(Metadata):
    conditions: list[FlowCondition]  # v63.0+
    conditionLogic: str | None = None
    initBehavior: Literal["runOnLoad", "runOnRevisit"] | None = None  # v64.0+
    screenActionName: str


class FlowScreenTrigger(Metadata):
    eventName: str
    eventSource: str
    handlers: list[FlowScreenTriggerHandler]


# Visibility rule


# Visibility rule
class FlowVisibilityRule(Metadata):
    conditionLogic: str = Field(
        description="Logical expression: and/or or advanced (e.g. 1 AND (2 OR 3))"
    )
    conditions: list[FlowCondition]


class FlowScreenField(FlowElement):
    choiceReferences: list[str] | None = None
    dataType: FlowDataType | None = None
    dataTypeMappings: list[dict] | None = None
    defaultSelectedChoiceReference: str | None = None
    defaultValue: FlowElementReferenceOrValue | None = None
    extensionName: str | None = None
    fields: list["FlowScreenField"] | None = None  # sections/columns
    fieldText: str | None = None
    fieldType: FlowScreenFieldType
    helpText: str | None = None
    inputParameters: list[FlowScreenFieldInputParameter]
    inputsOnNextNavToAssocScrn: FlowScreenFieldInputsRevisited | None = None  # noqa: F821
    isRequired: bool | None = None
    isVisible: bool | None = None
    objectFieldReference: str | None = None
    outputParameters: list[FlowScreenFieldOutputParameter]
    regionContainerType: FlowRegionContainerType | None = None
    scale: int | None = None
    sourceTemplateApiName: str | None = None  # v62.0+
    sourceTemplateProviderType: str | None = None  # v62.0+
    storeOutputAutomatically: bool | None = None
    styleProperties: FlowScreenFieldStyleProperties | None = None  # v64.0+
    validationRule: FlowInputValidationRule | None = (
        None  # FlowInputValidationRule – model elsewhere if you have it
    )
    visibilityRule: FlowVisibilityRule | None = (
        None  # FlowVisibilityRule – model elsewhere if you have it
    )

    # TODO: each screen field is a flow element which should be given flow element
    # defaultValue (if present)
    def add_to_graph(self, graph, parent_node_path):
        from ...graph import project_element

        return project_element(self, graph, parent_node_path=parent_node_path)


class FlowScreen(FlowNode):
    """Screen: Display info and collect user input (only in screen flows)."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Screen",
            "description": "Display info and collect user input (only in screen flows).",
        }
    )
    actions: list[FlowScreenAction]
    allowBack: bool = True
    allowFinish: bool = True
    allowPause: bool = True
    backButtonLabel: str | None = None
    connector: FlowConnector | None = None
    fields: list[FlowScreenField] | None = None
    helpText: str | None = None
    nextOrFinishButtonLabel: str | None = None
    pauseButtonLabel: str | None = None
    pausedText: str | None = None
    rules: list[None] = None  # reserved for future use
    showFooter: bool = True
    showHeader: bool = True
    # stageReference: FlowElementReferenceOrValue | None = None
    stageReference: Literal[None] = None  # not in data but in docs
    triggers: list[None] = (
        None  # in docs and defined here as FlowScreenTrigger but set to None as not in any current flows
    )
    elementSubType: Literal[None] = None  # not in docs but was in data
