from pydantic import Field


from .base import (
    Metadata,
    FlowCondition,
    FlowElement,
    FlowElementReferenceOrValue,
    FlowInputParameter,
)
from ..types.enums import FlowStageStepAssigneeType, InvocableActionType


__all__ = [
    "FlowStageStepAssignee",
    "FlowStageStepEntryActionInputParameter",
    "FlowStageStepEntryActionOutputParameter",
    "FlowStageStepExitActionInputParameter",
    "FlowStageStepExitActionOutputParameter",
    "FlowStageStepInputParameter",
    "FlowStageStepOutputParameter",
    "FlowStageStep",
    "FlowStage",
]


class FlowStageStepAssignee(Metadata):
    assignee: FlowElementReferenceOrValue | None = None
    assigneeType: FlowStageStepAssigneeType


class FlowStageStepEntryActionInputParameter(FlowInputParameter):
    pass


class FlowStageStepEntryActionOutputParameter(Metadata):
    assignToReference: str | None = None  # reserved
    name: str  # e.g., "isOrchestrationConditionMet"


class FlowStageStepExitActionInputParameter(FlowInputParameter):
    pass


class FlowStageStepExitActionOutputParameter(Metadata):
    assignToReference: str | None = None  # reserved
    name: str  # "isOrchestrationConditionMet"


class FlowStageStepInputParameter(FlowInputParameter):
    pass


class FlowStageStepOutputParameter(Metadata):
    assignToReference: str | None = None  # reserved
    name: str


class FlowStageStep(Metadata):
    actionName: str
    actionType: InvocableActionType
    assignees: list[FlowStageStepAssignee] = Field(default_factory=list)
    entryActionInputParameters: list[FlowStageStepEntryActionInputParameter] = Field(
        default_factory=list
    )
    entryActionName: str | None = None
    entryActionOutputParameters: list[FlowStageStepEntryActionOutputParameter] = Field(
        default_factory=list
    )
    entryActionType: InvocableActionType | None = (
        None  # "EvaluationFlow" or "exploreConversation"
    )
    entryConditionLogic: str | None = None
    entryConditions: list[FlowCondition] = Field(default_factory=list)
    exitActionInputParameters: list[FlowStageStepExitActionInputParameter] = Field(
        default_factory=list
    )
    exitActionName: str | None = None
    exitActionOutputParameters: list[FlowStageStepExitActionOutputParameter] = Field(
        default_factory=list
    )
    exitActionType: InvocableActionType | None = (
        None  # "EvaluationFlow" or "exploreConversation"
    )
    exitConditionLogic: str | None = None
    exitConditions: list[FlowCondition] = Field(default_factory=list)
    inputParameters: list[FlowStageStepInputParameter] = Field(default_factory=list)
    label: str
    # outputConfigParams: list[FlowStageStepOutputConfigParam] = Field(default_factory=list)
    outputParameters: list[FlowStageStepOutputParameter] = Field(default_factory=list)
    requiresAsyncProcessing: bool | None = None
    shouldLock: bool | None = None
    stepSubtype: str | None = None  # reserved/internal


class FlowStage(FlowElement):
    isActive: bool | None = None
    label: str | None = None
    stageOrder: int | None = None
    steps: list[FlowStageStep] | None = None
