from datetime import time, date
from typing import Literal
from pydantic import ConfigDict, Field, field_validator


from .base import (
    Metadata,
    FlowRecordFilter,
    FlowElement,
    FlowConnector,
    FlowNode,
    FlowElementReferenceOrValue,
)

# Autolaunch flows have all props	record lookup filter properties only in Autolaunch	Screen nodes only in Appointments and flows
__all__ = [
    "FlowStart"
    # "FlowStartAutoLaunchedFlow"
]


class FlowScheduledPath(FlowElement):
    """
    Scheduled path for an auto-launched flow

    """

    connector: FlowConnector | None = Field(
        default=None, description="Which node to execute after scheduled path"
    )
    maxBatchSize: int | None
    offsetNumber: int | None
    offsetUnit: Literal["Minutes", "Hours", "Days"] | None
    pathType: Literal["AsyncAfterCommit"] | None
    recordField: str | None = Field(
        default=None,
        description="API name of field used -- see the object name in start.object",
    )
    timeSource: Literal["RecordField", "RecordTriggerEvent"] | None = None


class FlowSchedule(Metadata):
    frequency: Literal["Once", "Daily", "Weekly", "OnActivate"] = Field(
        description="Execution frequency."
    )
    startDate: date | None = Field(
        default=None, description="Date the schedule starts."
    )
    startTime: time | None = Field(
        default=None, description="Time the schedule starts."
    )


class FlowStart(FlowNode):
    """Start: Defines trigger context (record-triggered, schedule, platform event, etc.).

    First node that specifies how and when the flow starts.
    """

    model_config = ConfigDict(json_schema_extra={"title": "Start"})

    # input
    object: str | None = Field(
        default=None,
        description="The object qualified API name that initialized/triggered the flow.",
    )
    inputs: list[FlowElementReferenceOrValue] | None = Field(
        default=None,
        description=(
            "The input parameters for start element. Not in any of the existing flows as it is relatively new"
        ),
    )

    # output
    connector: FlowConnector | None = None
    # rarely-present / reserved
    triggeringDataGraph: Literal[None]
    triggeringDataModelObjectPath: Literal[None]
    eventName: Literal[None]
    eventType: Literal[None]
    form: Literal[None]
    publishSegment: Literal[None]
    segment: Literal[None]
    entryType: Literal[None]
    capabilityTypes: list[None] | Literal[None]
    objectContainer: Literal[None]

    # Autolaunch flow params

    filterFormula: str | None = Field(
        default=None,
        description=(
            "A formula that's used to filter what records execute the flow during a save. "
            "Available only in record-triggered flows."
        ),
    )
    filterLogic: str | None = Field(
        default=None, description="Logical operator between multiple filter conditions."
    )
    filters: list[FlowRecordFilter] | None = None
    triggerType: (
        Literal[
            "RecordAfterSave",
            "RecordBeforeSave",
            "RecordBeforeDelete",
            "Scheduled",
            "PlatformEvent",
        ]
        | None
    ) = None
    recordTriggerType: (
        Literal["Create", "Update", "CreateAndUpdate", "Delete"] | None
    ) = None
    flowRunAsUser: Literal["TriggeringUser", "DefaultWorkflowUser"] | None = None
    schedule: FlowSchedule | None = Field(
        default=None,
        description="Schedule settings (only when triggerType == 'Scheduled').",
    )
    scheduledPaths: list[FlowScheduledPath] | None = None

    doesRequireRecordChangedToMeetCriteria: bool | None = Field(
        default=None,
        description=(
            "Evaluate true only if record changed from not meeting to meeting conditions."
        ),
    )

    @field_validator("name", mode="before")
    def add_name_to_start_node(cls, value):
        """
        Name the start node "Start" if it doesn't have a name.

        Despite the definition of a node requiring a name,
        some start nodes are none. This makes sense because there can only be one
        start node so it is guaranteed to be unique."""
        if value is None:
            return "start"


# class FlowStartAutoLaunchedFlow(FlowStart):
#     """
#     Auto-Launched Flow: A flow that runs in the background and doesn't have a user interface.
#     """
#     not_salesforce_class: Literal[True] = Field(True, description="Indicates this is a custom class, not part of Salesforce metadata.")


# class FlowStartScreenFlow(BaseFlowStart):
#     pass


# class FlowStartAppointment(BaseFlowStart):
#     pass

# class FlowStartRoutingFlow(BaseFlowStart):
#     pass


# class FlowStartRecordTrigger(FlowStart):
#     pass

# class FlowStartEventTrigger(FlowStart):
#     pass

# class FlowStart
