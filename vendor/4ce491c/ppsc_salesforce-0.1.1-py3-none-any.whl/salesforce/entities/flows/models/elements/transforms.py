from typing import Literal

from pydantic import ConfigDict, Field

from .base import (
    Metadata,
    FlowElement,
    FlowElementReferenceOrValue,
    FlowInputParameter,
    FlowNode,
    FlowConnector,
)
from ..types.enums import (
    InvocableActionType,
    FlowTransformValueActionType,
    FlowTransformDataType,
)


__all__ = [
    "FlowTransformValueActionInputParameter",
    "FlowTransformValueAction",
    "FlowTransformValue",
    "FlowTransform",
]


class FlowTransformValueActionInputParameter(FlowInputParameter):
    name: Literal["aggregationField", "aggregationValues"]


class FlowTransformValueAction(Metadata):
    actionName: str | None = Field(default=None, description="Reserved for future use.")
    actionType: InvocableActionType | None = Field(
        default=None, description="Reserved for future use."
    )
    actionVersionString: str | None = Field(
        default=None, description="Reserved for future use."
    )
    assignToReference: str | None = Field(
        default=None, description="Reserved for future use."
    )
    inputParameters: list[FlowTransformValueActionInputParameter]
    outputFieldApiName: str | None = Field(
        default=None, description="Target data field"
    )
    transformType: FlowTransformValueActionType
    value: FlowElementReferenceOrValue | None = None


class FlowTransformValue(FlowElement):
    transformValueActions: list[FlowTransformValueAction]
    transformValueName: str | None = Field(
        default=None, description="Reserved for future use."
    )
    transformValueLabel: str | None = Field(
        default=None, description="Reserved for future use."
    )
    transformValueDescription: str | None = Field(
        default=None, description="Reserved for future use."
    )


class FlowTransform(FlowNode):
    """Transform: Collection/data shaping element (Count, Map, Join, Sum, etc.)."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Transform",
            "description": "Collection/data shaping element (Count, Map, Join, Sum, etc.).",
        }
    )
    apexClass: str | None = None
    connector: FlowConnector
    dataType: FlowTransformDataType
    isCollection: bool = False
    objectType: str | None = None
    scale: int | None = Field(default=None, ge=0, le=17)
    storeOutputAutomatically: bool = False
    transformValues: list[FlowTransformValue]
