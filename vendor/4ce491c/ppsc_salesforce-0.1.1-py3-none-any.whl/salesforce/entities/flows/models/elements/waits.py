from datetime import time
from typing import Literal
from pydantic import ConfigDict


from .base import (
    Metadata,
    FlowInputParameter,
    FlowRecordFilter,
    FlowCondition,
    FlowElement,
    FlowConnector,
    FlowNode,
)
from ..types.enums import (
    FlowWaitInteractionType,
    InvocableActionType,
    FlowScheduledPathOffsetUnit,
    RecordTriggerType,
)


__all__ = [
    "FlowWait",
    "FlowWaitEvent",
    "FlowWaitEventInputParameter",
    "FlowWaitEventOutputParameter",
]


class FlowWaitEventInputParameter(FlowInputParameter):
    pass


class FlowWaitEventOutputParameter(Metadata):
    assignToReference: str
    name: str


class FlowWaitEvent(FlowElement):
    """Wait Event: Component of a Wait; resumes flow based on time or event criteria."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Wait Event",
            "description": "Component of a Wait; resumes flow based on time or event criteria.",
        }
    )
    conditionLogic: str | None = None
    associatedElement: str | None = None
    conditions: list[FlowCondition]
    automationEventName: str | None = None
    automationEventType: InvocableActionType | None = None
    connector: FlowConnector | None = None
    eventType: Literal["AlarmEvent", "DateRefAlarmEvent"]
    extendUntil: time | None = None
    filters: list[FlowRecordFilter]
    filterLogic: str | None = None
    inputParameters: list[FlowWaitEventInputParameter]
    interactionType: FlowWaitInteractionType | None = None
    label: str
    object: str | None = None
    offset: int | None = None
    offsetUnit: FlowScheduledPathOffsetUnit | None = None
    outputParameters: list[FlowWaitEventOutputParameter]
    recordTriggerType: RecordTriggerType | None = None


class FlowWait(FlowNode):
    """Wait: Resume when time-based or event criteria are met (declarative wait point)."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Wait",
            "description": "Resume when time-based or event criteria are met (declarative wait point).",
        }
    )
    defaultConnector: FlowConnector
    defaultConnectorLabel: str
    faultConnector: FlowConnector | None = None
    timeZoneId: str | None = None
    waitEvents: list[FlowWaitEvent]
