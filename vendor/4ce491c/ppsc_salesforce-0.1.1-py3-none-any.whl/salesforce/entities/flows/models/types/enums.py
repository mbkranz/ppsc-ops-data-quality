from enum import Enum, StrEnum
from typing import Literal, Annotated
from pydantic import Field

FlowProcessType = Literal[
    "AutoLaunchedFlow", "Flow", "Appointments", "TransactionSecurityFlow", "RoutingFlow"
]
FlowEnvironment = Literal["Default", "Offline", "Slack", "Default"]


class FlowDataType(StrEnum):
    APEX = "Apex"
    BOOLEAN = "Boolean"
    CURRENCY = "Currency"
    DATE = "Date"
    DATETIME = "DateTime"
    TIME = "Time"
    NUMBER = "Number"
    MULTIPICKLIST = "Multipicklist"
    PICKLIST = "Picklist"
    STRING = "String"
    SOBJECT = "SObject"


FlowTransformDataType = Literal[
    "Apex", "Boolean", "Currency", "Date", "DateTime", "Number", "String", "SObject"
]
FlowTransformValueActionType = Annotated[
    Literal["Count", "GetItemByIndex", "InnerJoin", "InvocableAction", "Map", "Sum"],
    Field(
        description="""
Required. The type of transformation from source data to target data. Valid types are:
Count—Calculates the number of items in a source collection.
GetItemByIndex—Reserved for future use.
InnerJoin—Joins selected data from two source collections that are stored in a target collection in a flow. This value is available in API version 63.0 and later. See complexValueType on FlowElementReferenceOrValue.
InvocableAction—Reserved for future use.
Map—Specifies a mapping between the datasets in flows. In Flow Builder, it corresponds to the mapping between source data fields and target data fields.
Sum—Adds the numeric values of a field on each item in a collection.
    """
    ),
]

FlowScreenFieldType = Literal[
    "DisplayText",
    "InputField",
    "LargeTextArea",
    "PasswordField",
    "RadioButtons",
    "DropdownBox",
    "MultiSelectCheckboxes",
    "MultiSelectPicklist",
    "ComponentInstance",
    "ComponentChoice",
    "ComponentInput",
    "Region",
    "RegionContainer",
    "ObjectProvided",
]


class FlowComparisonOperator(str, Enum):
    contains = "Contains"
    ends_with = "EndsWith"
    equal_to = "EqualTo"
    greater_than = "GreaterThan"
    greater_than_or_equal_to = "GreaterThanOrEqualTo"
    has_error = "HasError"  # v64.0+
    in_ = "In"  # v56.0+
    is_blank = "IsBlank"  # v61.0+
    is_changed = "IsChanged"  # v52.0+
    is_empty = "IsEmpty"  # v61.0+
    is_null = "IsNull"
    less_than = "LessThan"
    less_than_or_equal_to = "LessThanOrEqualTo"
    none = "None"  # v58.0+
    not_equal_to = "NotEqualTo"
    not_in = "NotIn"  # v56.0+
    starts_with = "StartsWith"
    was_selected = "WasSelected"
    was_set = "WasSet"  # v30.0+
    was_visited = "WasVisited"


class FlowAssignmentOperator(StrEnum):
    """Assignment operations supported by Flow assignment and mapping elements."""

    ADD = "Add"
    ADD_AT_START = "AddAtStart"
    ADD_ITEM = "AddItem"
    ASSIGN = "Assign"
    ASSIGN_COUNT = "AssignCount"
    REMOVE_AFTER_FIRST = "RemoveAfterFirst"
    REMOVE_ALL = "RemoveAll"
    REMOVE_BEFORE_FIRST = "RemoveBeforeFirst"
    REMOVE_FIRST = "RemoveFirst"
    REMOVE_POSITION = "RemovePosition"
    REMOVE_UNCOMMON = "RemoveUncommon"
    SUBTRACT = "Subtract"


StandardInvocableActionType = Literal[
    "flow",
    "component",
    "apex",
    "emailSimple",
    "saveAppointment",
    "getVerificationData",
    "buildIdentityVerification",
    "cancelAppointment",
    "routeWork",
    "addScreenPop",
    "dataProcessingEngineAction",
    "generatePromptResponse",
    "getConvTscpForRecord",
    "adjustMktExpertCampaign",
    "approveMktExpertCampArmRemoval",
]

HealthCloudActionTypes = Literal[
    "createQuoteForHomeVisits",
    "createReferral",
    "getResourcesForMnlScheduling",
    "getTranscriptForConversation",
    "handleResourceAbsence",
    "invokeGenericFHIR",
    "processReceivedDocument",
    "scheduleHomeVisitManually",
    "scheduleHomeVisit",
    "scheduleRecurringHomeVisit",
]

InvocableActionType = StandardInvocableActionType | HealthCloudActionTypes

# Extend offset unit enum (added Months for async action waits)
FlowScheduledPathOffsetUnit = Literal["Minutes", "Hours", "Days", "Months"]

FlowWaitInteractionType = Literal["SmsResponse", "WhatsappResponse"]
RecordTriggerType = Literal["Create", "Update", "CreateAndUpdate"]

# --- Supporting enums not yet declared ---
SortOrder = Literal["Asc", "Desc"]

# Transaction model for invocable actions (already documented earlier)
FlowTransactionModel = Literal["Automatic", "CurrentTransaction", "NewTransaction"]


FlowRegionContainerType = Literal["SectionWithHeader", "SectionWithoutHeader"]

FlowScreenFieldInputsRevisited = Literal["UseStoredValues", "ResetValues"]

FlowStageStepAssigneeType = Literal["Group", "Queue", "User", "invalid"]


class FlowCollectionProcessorType(StrEnum):
    SORT = "SortCollectionProcessor"  # v50.0+
    RECOMMENDATION_MAP = "RecommendationMapCollectionProcessor"  # v53.0+
    FILTER = "FilterCollectionProcessor"  # v53.0+


FlowWaitConditionType = Literal["Container", "EntryCondition", "ExitCondition"]
