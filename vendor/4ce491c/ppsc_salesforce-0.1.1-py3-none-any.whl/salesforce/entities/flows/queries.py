"""Compile a selected native Flow graph to one logical SQLGlot SELECT.

The query is metadata-only: its named input relations are explicit binding points
for consumers. No lake/history policy, service client or Ibis table is required.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping
from copy import deepcopy
from dataclasses import asdict
from hashlib import sha256
import json

from sqlglot import exp, parse_one

from salesforce.core.formulas import formula_reference_occurrences
from salesforce.core.provenance import annotate, source_metadata

from .analysis import ELEMENT_KINDS, FlowAnalysis, analyze_flow
from .expressions import (
    SqlContext,
    UnsupportedTranslation,
    condition_logic,
    predicate_to_ast,
    value_to_ast,
)


class UnsupportedFlowError(ValueError):
    """The selected native workflow cannot be represented faithfully."""


def _column(name, table=None):
    return exp.column(name, table=table, quoted=True)


def _alias(expression, name):
    return exp.alias_(expression, name, quoted=True)


def _table(name, alias=None):
    value = exp.Table(this=exp.to_identifier(name, quoted=True))
    if alias:
        value.set("alias", exp.TableAlias(this=exp.to_identifier(alias, quoted=True)))
    return value


def _and(*values):
    return exp.and_(*(value.copy() for value in values)) if values else exp.true()


def _or(*values):
    return exp.or_(*(value.copy() for value in values)) if values else exp.false()


def _is_true(value):
    return exp.Is(this=exp.Paren(this=value.copy()), expression=exp.true())


def _not(value):
    return exp.Not(this=exp.Paren(this=value.copy()))


def _not_null(value):
    return exp.Not(
        this=exp.Is(this=exp.Paren(this=value.copy()), expression=exp.Null())
    )


def _case(guard, yes, no):
    return exp.Case(ifs=[exp.If(this=guard.copy(), true=yes.copy())], default=no.copy())


def _references(value):
    if isinstance(value, Mapping):
        for key, item in value.items():
            if key in {"elementReference", "leftValueReference"} and isinstance(
                item, str
            ):
                yield item
            else:
                yield from _references(item)
    elif isinstance(value, (tuple, list)):
        for item in value:
            yield from _references(item)


def _update_target(node, trigger):
    assignments = node.get("inputAssignments") or ()
    if not assignments:
        raise UnsupportedFlowError(
            f"Record update has no explicit field assignments: {node.get('name')}"
        )
    if node.get("inputReference"):
        if node["inputReference"] != "$Record" or not trigger:
            raise UnsupportedFlowError(
                "Record-variable writes require explicit native state semantics"
            )
        return trigger, "$Record.Id"
    filters = node.get("filters") or ()
    if (
        not node.get("object")
        or len(filters) != 1
        or (node.get("filterLogic") or "and").lower() != "and"
        or filters[0].get("field") != "Id"
        or filters[0].get("operator") != "EqualTo"
        or not (filters[0].get("value") or {}).get("elementReference")
    ):
        raise UnsupportedFlowError(
            f"Record update needs one explicit Id target: {node.get('name')}"
        )
    return node["object"], filters[0]["value"]["elementReference"]


def to_sqlglot(
    flow_record,
    *,
    path_type=None,
    object_name=None,
    target_reference=None,
    fields=None,
    source=None,
    field_definitions=(),
    simplify=False,
) -> exp.Select:
    """Return a faithful SELECT over explicit logical event and lookup inputs.

    ``flow_record`` may be a saved API record, native Metadata mapping, or an
    already prepared ``FlowAnalysis``. Select an unambiguous entry/target group;
    defaults cover every reachable assignment in that group. Missing native
    FieldDefinitions are recorded as unresolved type evidence, never inferred.
    """
    if isinstance(flow_record, FlowAnalysis):
        analysis = flow_record
        record_identity = {}
        metadata = analysis.document.export()
    else:
        if not isinstance(flow_record, Mapping):
            raise TypeError(
                "Supply a native Flow record, Metadata mapping or FlowAnalysis"
            )
        record_identity = {
            key: flow_record[key]
            for key in ("Id", "FullName", "MasterLabel")
            if flow_record.get(key) is not None
        }
        metadata = deepcopy(dict(flow_record.get("Metadata", flow_record)))
        analysis = analyze_flow(metadata)
    source = {
        **{
            key: value
            for key, value in {
                "source_file": analysis.source.source_file,
                "source_metadata_path": analysis.source.metadata_base,
                "source_org": analysis.source.org,
                "flow_version_id": analysis.source.version_id,
                "source_sha256": analysis.source.source_sha256,
            }.items()
            if value is not None
        },
        **record_identity,
        **dict(source or {}),
    }
    source.setdefault("flow_version_id", record_identity.get("Id"))
    source.setdefault(
        "flow_name", record_identity.get("FullName") or metadata.get("fullName")
    )
    source["metadata_sha256"] = sha256(
        json.dumps(
            metadata, sort_keys=True, separators=(",", ":"), allow_nan=False
        ).encode()
    ).hexdigest()
    source["metadata_sha256_scope"] = (
        "canonical Metadata JSON; sorted keys, compact UTF-8"
    )

    elements = {
        name: (kind, index, analysis.document.export(owner), owner)
        for name, (kind, index, owner) in analysis.elements.items()
    }
    entries = {
        key: tuple(value for value in values if value)
        for key, values in analysis.entry_paths.items()
        if any(values)
    }
    immediate = analysis.connector_targets.get("/start/connector")
    if immediate:
        entries["Immediate"] = (immediate,)
    if path_type is None:
        if len(entries) != 1 or len(next(iter(entries.values()), ())) != 1:
            raise UnsupportedFlowError(
                "Select one unambiguous Flow entry path explicitly"
            )
        path_type = next(iter(entries))
    if len(entries.get(path_type, ())) != 1:
        raise UnsupportedFlowError(f"Expected one native {path_type} entry path")
    entry = entries[path_type][0]
    reachable, ordered, visiting, discovered = set(), [], set(), []

    def visit(name):
        if not name:
            return
        if name in visiting:
            raise UnsupportedFlowError(f"Cyclic Flow connector: {name}")
        if name in reachable:
            return
        if name not in elements or name in analysis.duplicate_names:
            raise UnsupportedFlowError(f"Unresolved or repeated Flow element: {name}")
        visiting.add(name)
        discovered.append(name)
        for successor in analysis.control_targets.get(name, ()):
            visit(successor)
        visiting.remove(name)
        reachable.add(name)
        ordered.append(name)

    visit(entry)
    # Stable topological order respects native connector/rule traversal order
    # while waiting for every incoming branch before a reconvergence.
    predecessors = {
        name: {
            parent
            for parent in reachable
            if name in analysis.control_targets.get(parent, ())
        }
        for name in reachable
    }
    ordered = []
    remaining = set(reachable)
    while remaining:
        ready = [
            name
            for name in discovered
            if name in remaining and not (predecessors[name] & remaining)
        ]
        if not ready:
            raise UnsupportedFlowError("Cyclic native control graph")
        ordered.extend(ready)
        remaining.difference_update(ready)
    trigger = (metadata.get("start") or {}).get("object")
    targets = {}
    for name in ordered:
        if elements[name][0] == "recordUpdates":
            node = elements[name][2]
            declared_object = node.get("object") or (
                trigger if node.get("inputReference") == "$Record" else None
            )
            if (
                object_name is not None
                and declared_object is not None
                and declared_object != object_name
            ):
                continue
            filters = node.get("filters") or ()
            declared_target = (
                "$Record.Id"
                if node.get("inputReference") == "$Record"
                else (
                    (filters[0].get("value") or {}).get("elementReference")
                    if len(filters) == 1 and filters[0].get("field") == "Id"
                    else None
                )
            )
            if (
                target_reference is not None
                and declared_target is not None
                and declared_target != target_reference
            ):
                continue
            targets[name] = _update_target(node, trigger)
    groups = list(dict.fromkeys(targets.values()))
    selected = [
        group
        for group in groups
        if (object_name is None or group[0] == object_name)
        and (target_reference is None or group[1] == target_reference)
    ]
    if len(selected) != 1:
        raise UnsupportedFlowError(
            "Select one unambiguous output object/target group explicitly"
        )
    object_name, target_reference = selected[0]
    if target_reference.partition(".")[0] in {
        node.get("name")
        for node in metadata.get("recordLookups") or ()
        if isinstance(node, Mapping)
    }:
        raise UnsupportedFlowError(
            "Lookup-derived update targets require an independent target-BEFORE "
            "relation; this compiler currently requires a record-bound target"
        )
    selected_updates = [name for name in ordered if targets.get(name) == selected[0]]
    available = tuple(
        dict.fromkeys(
            item["field"]
            for name in selected_updates
            for item in elements[name][2].get("inputAssignments") or ()
        )
    )
    fields = available if fields is None else tuple(fields)
    if (
        not fields
        or len(set(fields)) != len(fields)
        or not set(fields) <= set(available)
    ):
        raise UnsupportedFlowError("Select unique reachable output fields")
    parents = defaultdict(set)
    for name in ordered:
        for successor in analysis.control_targets.get(name, ()):
            parents[successor].add(name)
    closure = {
        name
        for name in selected_updates
        if any(
            item.get("field") in fields
            for item in elements[name][2].get("inputAssignments") or ()
        )
    }
    pending = list(closure)
    while pending:
        for parent in parents[pending.pop()]:
            if parent not in closure:
                closure.add(parent)
                pending.append(parent)
    ordered = [name for name in ordered if name in closure]
    decision_prefix = {}
    for name in ordered:
        if elements[name][0] != "decisions":
            continue
        node, owner = elements[name][2], elements[name][3]
        rules = node.get("rules") or ()
        if analysis.connector_targets.get(owner + "/defaultConnector") in closure:
            decision_prefix[name] = len(rules)
        else:
            needed = [
                index
                for index in range(len(rules))
                if analysis.connector_targets.get(owner + f"/rules/{index}/connector")
                in closure
            ]
            decision_prefix[name] = max(needed, default=-1) + 1

    def needed_diagnostic(name, path):
        owner = elements[name][3]
        if path != owner and not path.startswith(owner + "/"):
            return False
        if name in decision_prefix and path.startswith(owner + "/rules/"):
            index = path.removeprefix(owner + "/rules/").split("/", 1)[0]
            if index.isdigit() and int(index) >= decision_prefix[name]:
                return False
        return True

    for diagnostic in analysis.diagnostics:
        if diagnostic.consequence == "structural" and any(
            needed_diagnostic(name, diagnostic.location.pointer) for name in ordered
        ):
            raise UnsupportedFlowError(diagnostic.message)
    for name in ordered:
        kind, _, node, _ = elements[name]
        if kind not in {"decisions", "recordLookups", "recordUpdates"} or node.get(
            "faultConnector"
        ):
            raise UnsupportedFlowError(
                f"Unsupported active Flow operation: {kind}/{name}"
            )
        if kind == "recordUpdates" and targets.get(name) != selected[0]:
            raise UnsupportedFlowError(
                f"Read/write state crosses selected target: {name}"
            )
    # Resource expressions are lazy: unrelated unsupported formulas do not block
    # a selected output, and every used formula is lowered only once per stage.
    formulas = {
        node["name"]: (f"/formulas/{i}", node)
        for i, node in enumerate(metadata.get("formulas") or ())
        if isinstance(node, Mapping) and isinstance(node.get("name"), str)
    }
    constants = {
        node["name"]: node.get("value")
        for node in metadata.get("constants") or ()
        if isinstance(node, Mapping) and isinstance(node.get("name"), str)
    }
    assigned_state_fields = tuple(
        dict.fromkeys(
            item["field"]
            for name in ordered
            if elements[name][0] == "recordUpdates"
            for item in elements[name][2].get("inputAssignments") or ()
        )
    )
    live_state = set(fields)
    needed_assignments = {}

    def expanded_references(value, active=()):
        for reference in _references(value):
            if reference in formulas:
                if reference in active:
                    raise UnsupportedFlowError(
                        f"Cyclic formula dependency: {reference}"
                    )
                text = formulas[reference][1].get("expression")
                if not isinstance(text, str):
                    raise UnsupportedFlowError(
                        f"Missing native formula expression: {reference}"
                    )
                yield from expanded_references(
                    [
                        {"elementReference": item.text}
                        for item in formula_reference_occurrences(text)
                    ],
                    (*active, reference),
                )
            else:
                yield reference

    for name in reversed(ordered):
        kind, _, node, _ = elements[name]
        if kind == "recordUpdates":
            needed_assignments[name] = {
                item["field"]
                for item in node.get("inputAssignments") or ()
                if item["field"] in live_state
            }
            values = [
                item.get("value")
                for item in node.get("inputAssignments") or ()
                if item["field"] in needed_assignments[name]
            ]
        elif kind == "decisions":
            values = list(node.get("rules") or ())[: decision_prefix[name]]
        else:
            values = node
        if object_name == trigger and target_reference == "$Record.Id":
            live_state.update(
                reference.removeprefix("$Record.")
                for reference in expanded_references(values)
                if reference.startswith("$Record.")
                and reference.removeprefix("$Record.") in assigned_state_fields
            )
    state_fields = tuple(
        field for field in assigned_state_fields if field in live_state
    )
    if "Id" in state_fields:
        raise UnsupportedFlowError("Native Id mutation is not a supported target state")

    def node_dependencies(name):
        kind, _, node, _ = elements[name]
        if kind == "recordUpdates":
            return {
                **node,
                "inputAssignments": [
                    item
                    for item in node.get("inputAssignments") or ()
                    if item["field"] in needed_assignments[name]
                ],
            }
        if kind == "decisions":
            return {
                **node,
                "rules": list(node.get("rules") or ())[: decision_prefix[name]],
            }
        return node

    lookups = {
        name: elements[name][2]
        for name in ordered
        if elements[name][0] == "recordLookups"
    }
    needed_lookup_fields = {name: {"Id"} for name in lookups}
    formula_references = {}

    def note(reference, stack=()):
        if reference.partition(".")[0] in analysis.duplicate_names:
            raise UnsupportedFlowError(f"Ambiguous native reference: {reference}")
        if reference in formulas:
            if reference in stack:
                raise UnsupportedFlowError(f"Cyclic formula dependency: {reference}")
            text = formulas[reference][1].get("expression")
            if not isinstance(text, str):
                raise UnsupportedFlowError(
                    f"Missing native formula expression: {reference}"
                )
            refs = tuple(item.text for item in formula_reference_occurrences(text))
            formula_references[reference] = refs
            for dependency in refs:
                note(dependency, (*stack, reference))
        elif reference.partition(".")[0] in lookups:
            resource, _, field = reference.partition(".")
            if not field:
                raise UnsupportedFlowError(
                    f"Record resource needs a scalar field: {reference}"
                )
            needed_lookup_fields[resource].add(field)

    for name in ordered:
        for reference in _references(node_dependencies(name)):
            note(reference)
    definitions, limitations = {}, []
    from salesforce.entities.field_definitions.schemas import (
        UnsupportedFieldError,
        to_sqlglot as field_to_sqlglot,
    )

    for definition in field_definitions:
        try:
            column = (
                definition.copy()
                if isinstance(definition, exp.ColumnDef)
                else field_to_sqlglot(definition)
            )
            identity = column.meta.get("ppsc", {}).get("target_field")
            if identity:
                if identity in definitions:
                    raise UnsupportedFlowError(
                        f"Repeated native field definition: {identity}"
                    )
                definitions[identity] = column
        except UnsupportedFieldError as error:
            limitations.append(str(error))

    def definition_type(identity):
        definition = definitions.get(identity)
        kind = definition.args.get("kind") if definition is not None else None
        if kind is None:
            return None, False
        name = str(kind.this.value).upper()
        if name == "DATE":
            return "date", False
        if name in {"TIMESTAMP", "TIMESTAMPTZ", "DATETIME"}:
            return "datetime", False
        numeric = {
            "TINYINT",
            "SMALLINT",
            "INT",
            "BIGINT",
            "UTINYINT",
            "USMALLINT",
            "UINT",
            "UBIGINT",
            "DECIMAL",
            "DOUBLE",
            "FLOAT",
            "REAL",
        }
        if name in numeric:
            integral = name not in {"DECIMAL", "DOUBLE", "FLOAT", "REAL"}
            if name == "DECIMAL" and len(kind.expressions) == 2:
                scale = kind.expressions[1].this
                integral = (
                    isinstance(scale, exp.Literal)
                    and scale.is_int
                    and int(scale.this) == 0
                )
            return "number", integral
        return None, False

    formula_types = {}

    def typed_reference(value, reference, identity=None):
        kind, integral = definition_type(identity) if identity else (None, False)
        value.meta["flow_reference"] = reference
        if kind:
            value.meta["flow_value_type"] = kind
            value.meta["flow_integral"] = integral
        return value

    required, columns, ctes, node_order = {}, [], [], []
    edge_guards = defaultdict(list)
    lookup_outputs, completed_formulas = [], set()
    written = False
    current = "Flow_Inputs"
    used_names = {"Flow_Record", current, *["FlowLookup." + name for name in lookups]}

    def require(
        column,
        reference,
        role,
        native_object=None,
        field_path=None,
        table="Flow_Record",
        data_type=None,
    ):
        if table == "Flow_Record" and column in {
            "flow_row_id",
            "flow_record_id",
            "flow_target_id",
        }:
            raise UnsupportedFlowError(
                f"Native input collides with reserved row identity: {column}"
            )
        key = table, column
        item = dict(
            table=table,
            column=column,
            reference=reference,
            role=role,
            object_name=native_object,
            field_path=field_path,
        )
        if data_type:
            item["data_type"] = data_type
        required.setdefault(key, item)
        if table == "Flow_Record" and column not in columns:
            columns.append(column)
        return _column(column)

    def ref(reference):
        if reference.partition(".")[0] in analysis.duplicate_names:
            raise UnsupportedFlowError(f"Ambiguous native reference: {reference}")
        if reference in constants:
            return native_value(constants[reference])
        if reference in formulas:
            ensure_formula(reference)
            value = _column("__formula." + reference)
            value.meta["flow_value_type"] = formula_types.get(reference)
            return value
        if reference.startswith("$Record."):
            field = reference.removeprefix("$Record.")
            if (
                object_name == trigger
                and target_reference == "$Record.Id"
                and field in state_fields
            ):
                return typed_reference(
                    _column("__state." + field), reference, object_name + "." + field
                )
            return typed_reference(
                require(field, reference, "record", trigger, field),
                reference,
                str(trigger) + "." + field,
            )
        if reference.startswith("$Record__Prior."):
            field = reference.removeprefix("$Record__Prior.")
            return typed_reference(
                require("Prior." + field, reference, "prior_record", trigger, field),
                reference,
                str(trigger) + "." + field,
            )
        if reference in {"$Flow.CurrentDate", "flow_run_date"}:
            value = require(
                "__flow_run_date", reference, "runtime_date", data_type="DATE"
            )
            value.meta["flow_value_type"] = "date"
            return value
        if reference == "$Flow.CurrentDateTime":
            return require(
                "__flow_run_datetime",
                reference,
                "runtime_datetime",
                data_type="TIMESTAMP",
            )
        resource, _, field = reference.partition(".")
        if resource in lookups and reference in columns:
            if written and lookups[resource].get("object") == object_name:
                raise UnsupportedFlowError(
                    f"Read-after-write resource needs native state semantics: {reference}"
                )
            return typed_reference(
                _column(reference),
                reference,
                str(lookups[resource].get("object")) + "." + field,
            )
        if reference.startswith("$Setup.") or reference.startswith("$User."):
            return require(reference, reference, "external", field_path=reference)
        raise UnsupportedFlowError(
            f"Unbound or unsupported native reference: {reference}"
        )

    def known(reference, *, existence=False):
        if reference in constants or reference.startswith("$Flow."):
            return exp.true()
        if reference in formulas:
            ensure_formula(reference)
            return _column("__known.__formula." + reference)
        if reference.startswith("$Record."):
            field = reference.removeprefix("$Record.")
            if (
                object_name == trigger
                and target_reference == "$Record.Id"
                and field in state_fields
            ):
                return _column("__state_known." + field)
            return require(
                "__known." + field,
                reference,
                "record_evidence",
                trigger,
                field,
                data_type="BOOLEAN",
            )
        if reference.startswith("$Record__Prior."):
            field = reference.removeprefix("$Record__Prior.")
            return require(
                "__known.Prior." + field,
                reference,
                "prior_record_evidence",
                trigger,
                field,
                data_type="BOOLEAN",
            )
        resource, _, field = reference.partition(".")
        if resource in lookups and reference in columns:
            return _column(
                "__exists_known." + resource
                if existence and field == "Id"
                else "__known." + reference
            )
        ref(reference)
        return require(
            "__known." + reference,
            reference,
            "external_evidence",
            field_path=reference,
            data_type="BOOLEAN",
        )

    def bind(tree):
        def replace(node):
            if isinstance(node, exp.Column) and node.table != "Candidate":
                return ref(".".join(part.name for part in node.parts))
            return node

        return tree.transform(replace)

    def native_value(value):
        if isinstance(value, Mapping):
            active = [
                key
                for key, item in value.items()
                if item is not None
                and key
                in {
                    "elementReference",
                    "transformReference",
                    "apexValue",
                    "complexValue",
                    "booleanValue",
                    "numberValue",
                    "stringValue",
                    "dateValue",
                    "dateTimeValue",
                    "timeValue",
                }
            ]
            if len(active) > 1:
                raise UnsupportedFlowError(
                    "Ambiguous native value has multiple active alternatives"
                )
            if active == ["timeValue"]:
                return exp.Cast(
                    this=exp.Literal.string(value["timeValue"]),
                    to=exp.DataType.build("TIME"),
                )
        try:
            return bind(value_to_ast(value))
        except UnsupportedTranslation as error:
            raise UnsupportedFlowError(str(error)) from error

    def native_conditions(items, logic=None, *, candidate=False, prior=False):
        native = deepcopy(list(items or ()))
        if prior:
            for item in native:
                refs = list(_references(item))
                if any(
                    not reference.startswith("$Record.")
                    and not reference.startswith("$Flow.")
                    for reference in refs
                ):
                    raise UnsupportedFlowError(
                        "Changed-to-meet decision requires explicit prior native record inputs"
                    )

                def prior_value(value):
                    if isinstance(value, dict):
                        return {
                            key: (
                                item.replace("$Record.", "$Record__Prior.", 1)
                                if key in {"leftValueReference", "elementReference"}
                                and isinstance(item, str)
                                and item.startswith("$Record.")
                                else prior_value(item)
                            )
                            for key, item in value.items()
                        }
                    if isinstance(value, list):
                        return [prior_value(item) for item in value]
                    return value

                item.update(prior_value(item))

        def condition(item):
            if item.get("conditions"):
                return condition_logic(
                    [condition(child) for child in item["conditions"]],
                    item.get("conditionLogic"),
                )
            if item.get("aggregationField") or item.get("aggregationOperator"):
                raise UnsupportedTranslation(
                    "Aggregated native conditions require collection semantics"
                )
            value_key = "value" if "field" in item else "rightValue"
            if item.get(value_key) is None:
                raise UnsupportedTranslation(
                    "Native conditions require an explicit operand value"
                )
            predicate = bind(
                predicate_to_ast(
                    item, SqlContext(alias="Candidate" if candidate else None)
                )
            )
            # Native condition comparisons produce False for a NULL operand;
            # apply this before numbered NOT/AND/OR, rather than to the result.
            return exp.Coalesce(this=predicate, expressions=[exp.false()])

        try:
            tree = (
                condition_logic([condition(item) for item in native], logic)
                if native
                else exp.true()
            )
        except UnsupportedTranslation as error:
            raise UnsupportedFlowError(str(error)) from error
        evidence = []
        for item in native:
            for reference in _references(item):
                evidence.append(
                    known(reference, existence=item.get("operator") == "IsNull")
                )
        complete = _and(*evidence)
        return _case(_is_true(complete), tree, exp.Null()), complete

    def append(name, expressions, owner=None, kind=None, native=None):
        nonlocal current
        base = name
        while name.casefold() in {item.casefold() for item in used_names}:
            name += "_Input"
        used_names.add(name)
        additions = dict(expressions)
        query = exp.select(
            *[
                _alias(additions.pop(column, _column(column)), column)
                for column in columns
            ],
            *[_alias(value, column) for column, value in additions.items()],
        ).from_(_table(current))
        for column in expressions:
            if column not in columns:
                columns.append(column)
        facts = source_metadata(
            native or {},
            source=source,
            name=base,
            owner_id=owner,
            kind=kind,
            source_paths=["/Metadata" + owner] if owner else [],
            description="Native Flow stage: " + base,
        )
        annotate(query, facts)
        cte = exp.CTE(
            this=query, alias=exp.TableAlias(this=exp.to_identifier(name, quoted=True))
        )
        annotate(cte, facts)
        ctes.append(cte)
        if owner:
            node_order.append(dict(name=base, cte=name, owner_id=owner, kind=kind))
        current = name

    def ensure_formula(name, stack=()):
        if name in completed_formulas:
            return
        if name in stack:
            raise UnsupportedFlowError(f"Cyclic formula: {name}")
        owner, node = formulas[name]
        for dependency in formula_references.get(name, ()):
            if dependency in formulas:
                ensure_formula(dependency, (*stack, name))
        text = node["expression"]
        for occurrence in reversed(list(formula_reference_occurrences(text))):
            start, end = occurrence.start, occurrence.end
            if text[max(0, start - 2) : start] == "{!" and text[end : end + 1] == "}":
                start, end = start - 2, end + 1
            text = (
                text[:start]
                + '"'
                + occurrence.text.replace('"', '""')
                + '"'
                + text[end:]
            )
        try:
            tree = parse_one(text)
        except Exception as error:
            raise UnsupportedFlowError(f"Unsupported native formula: {name}") from error
        allowed = (
            exp.Column,
            exp.Identifier,
            exp.Literal,
            exp.Paren,
            exp.Add,
            exp.Sub,
            exp.Mul,
            exp.Div,
            exp.Floor,
            exp.Anonymous,
            exp.Boolean,
            exp.Null,
            exp.Neg,
        )
        for node_ in tree.walk():
            if (
                not isinstance(node_, allowed)
                or isinstance(node_, exp.Anonymous)
                and (node_.name.upper() != "TODAY" or node_.expressions)
            ):
                raise UnsupportedFlowError(
                    f"Unsupported native formula node in {name}: {type(node_).__name__}"
                )

        native_result = {
            "Date": "date",
            "DateTime": "datetime",
            "Number": "number",
            "Currency": "number",
            "Percent": "number",
        }.get(node.get("dataType"))

        def result(value, kind):
            if kind:
                value.meta["flow_value_type"] = kind
            return value

        def kind(value):
            if isinstance(value, exp.Literal) and value.is_number:
                return "number"
            return value.meta.get("flow_value_type")

        def date_offset(date_value, offset, subtract=False):
            if not (
                isinstance(offset, exp.Literal)
                and offset.is_int
                or offset.meta.get("flow_integral")
            ):
                raise UnsupportedFlowError(
                    f"Date offsets require an integral native operand: {name}"
                )
            delta = exp.Neg(this=offset.copy()) if subtract else offset.copy()
            return result(
                exp.Cast(
                    this=exp.DateAdd(
                        this=date_value.copy(),
                        expression=delta,
                        unit=exp.Var(this="DAY"),
                    ),
                    to=exp.DataType.build("DATE"),
                ),
                "date",
            )

        def lower(value, expected=None):
            if isinstance(value, exp.Column):
                return ref(value.name)
            if isinstance(value, exp.Anonymous):
                return ref("$Flow.CurrentDate")
            if isinstance(value, exp.Paren):
                child = lower(value.this, expected)
                return result(exp.Paren(this=child), kind(child))
            if isinstance(value, exp.Floor):
                return result(exp.Floor(this=lower(value.this, "number")), "number")
            if isinstance(value, exp.Neg):
                return result(exp.Neg(this=lower(value.this, "number")), "number")
            if isinstance(value, (exp.Mul, exp.Div)):
                lowered = value.copy()
                lowered.set("this", lower(value.this, "number"))
                lowered.set("expression", lower(value.expression, "number"))
                return result(lowered, "number")
            if isinstance(value, (exp.Add, exp.Sub)):
                left, right = lower(value.this), lower(value.expression)
                left_type, right_type = kind(left), kind(right)
                if "datetime" in {left_type, right_type}:
                    raise UnsupportedFlowError(
                        f"Datetime arithmetic requires explicit precision semantics: {name}"
                    )
                if left_type == "date" and right_type == "number":
                    return date_offset(left, right, isinstance(value, exp.Sub))
                if (
                    isinstance(value, exp.Add)
                    and left_type == "number"
                    and right_type == "date"
                ):
                    return date_offset(right, left)
                if (
                    isinstance(value, exp.Sub)
                    and left_type == "date"
                    and (
                        right_type == "date"
                        or right_type is None
                        and expected == "number"
                    )
                ):
                    if right_type is None:
                        reference = right.meta.get("flow_reference")
                        if not reference:
                            raise UnsupportedFlowError(
                                f"Unresolved native date operand: {name}"
                            )
                        for item in required.values():
                            if item["reference"] == reference:
                                item["semantic_type_requirement"] = "DATE"
                                item["type_requirement_source"] = (
                                    "/Metadata" + owner + "/expression"
                                )
                    return result(
                        exp.DateDiff(
                            this=left, expression=right, unit=exp.Var(this="DAY")
                        ),
                        "number",
                    )
                if "date" in {left_type, right_type}:
                    raise UnsupportedFlowError(
                        f"Unresolved native date arithmetic: {name}"
                    )
                if (
                    isinstance(value, exp.Sub)
                    and left_type is None
                    and right_type is None
                ):
                    raise UnsupportedFlowError(
                        f"Subtraction needs native operand types: {name}"
                    )
                lowered = value.copy()
                lowered.set("this", left)
                lowered.set("expression", right)
                return result(
                    lowered,
                    "number"
                    if expected == "number" or left_type == right_type == "number"
                    else None,
                )
            return value.copy()

        tree = lower(tree, native_result)
        formula_types[name] = kind(tree) or native_result
        evidence = _and(
            *(known(reference) for reference in formula_references.get(name, ()))
        )
        append(
            "FlowFormula." + name,
            {"__formula." + name: tree, "__known.__formula." + name: evidence},
            owner,
            "FlowFormula",
            node,
        )
        completed_formulas.add(name)

    # Internal state columns are never supplied by the consumer.
    require("__eligible", "eligibility", "runtime_eligibility", data_type="BOOLEAN")
    target = ref(target_reference)
    target_known = known(target_reference)
    for field in state_fields:
        require(
            "Before." + field, object_name + "." + field, "before", object_name, field
        )
    initial_state = {
        "flow_row_id": exp.Window(this=exp.RowNumber()),
        "flow_record_id": require("Id", "$Record.Id", "record", trigger, "Id"),
        "flow_target_id": target,
    }
    initial_state.update({
        "__state." + field: _column("Before." + field) for field in state_fields
    })
    initial_state.update({
        "__state_known." + field: exp.true() for field in state_fields
    })
    initial_state.update({"__assigned." + field: exp.false() for field in state_fields})
    columns.extend(initial_state)
    edge_guards[entry].append(_column("__eligible"))
    output_paths = {field: [] for field in state_fields}
    output_refs = {field: [] for field in state_fields}

    for name in ordered:
        kind, _, node, owner = elements[name]
        incoming = _or(*edge_guards[name])
        guard_column = "__active." + name
        append(
            ELEMENT_KINDS[kind] + "." + name + ".Entry",
            {guard_column: incoming},
            owner,
            ELEMENT_KINDS[kind],
            node,
        )
        guard = _column(guard_column)
        if kind == "decisions":
            previous = exp.false()
            for index, rule in enumerate(
                list(node.get("rules") or ())[: decision_prefix[name]]
            ):
                predicate, _ = native_conditions(
                    rule.get("conditions"), rule.get("conditionLogic")
                )
                if rule.get("doesRequireRecordChangedToMeetCriteria"):
                    prior, _ = native_conditions(
                        rule.get("conditions"), rule.get("conditionLogic"), prior=True
                    )
                    predicate = _and(predicate, _not(prior))
                rule_name = rule.get("name") or f"rule_{index}"
                rule_column = "__rule." + name + "." + rule_name
                append(
                    "FlowRule." + name + "." + rule_name,
                    {rule_column: _and(guard, _not(previous), predicate)},
                    owner + f"/rules/{index}",
                    "FlowRule",
                    rule,
                )
                successor = analysis.connector_targets.get(
                    owner + f"/rules/{index}/connector"
                )
                if successor in closure:
                    edge_guards[successor].append(_column(rule_column))
                previous = _or(previous, predicate)
            successor = analysis.connector_targets.get(owner + "/defaultConnector")
            if successor in closure:
                edge_guards[successor].append(_and(guard, _not(previous)))
        elif kind == "recordLookups":
            if (
                node.get("getFirstRecordOnly") is not True
                or node.get("storeOutputAutomatically") is not True
                or node.get("outputAssignments")
            ):
                raise UnsupportedFlowError(
                    f"Only native automatic first-record lookups are supported: {name}"
                )
            if written and node.get("object") == object_name:
                raise UnsupportedFlowError(
                    f"Read-after-write lookup requires native state semantics: {name}"
                )
            selected_fields = sorted(
                needed_lookup_fields[name]
                | ({node["sortField"]} if node.get("sortField") else set())
            )
            logical_source = "FlowLookup." + name
            for field in sorted(
                set(selected_fields)
                | {item["field"] for item in node.get("filters") or ()}
            ):
                require(
                    field,
                    name + "." + field,
                    "lookup",
                    node.get("object"),
                    field,
                    table=logical_source,
                )
            predicate, dependency_known = native_conditions(
                node.get("filters"), node.get("filterLogic"), candidate=True
            )
            active_known = _and(_not_null(guard), _or(_not(guard), dependency_known))
            marker = "__match." + name
            prefix_columns = list(columns)
            candidate_fields = sorted(
                set(selected_fields)
                | {item["field"] for item in node.get("filters") or ()}
            )
            candidate = (
                exp.select(
                    *[_column(field) for field in candidate_fields],
                    _alias(exp.Literal.number(1), marker),
                )
                .from_(_table(logical_source))
                .subquery(exp.to_identifier("Candidate", quoted=True))
            )
            query = exp.select(
                *[
                    _alias(_column(column, "Event"), column)
                    for column in prefix_columns
                ],
                *[
                    _alias(_column(field, "Candidate"), name + "." + field)
                    for field in selected_fields
                ],
                _alias(_column(marker, "Candidate"), marker),
                _alias(active_known, "__lookup_known." + name),
            ).from_(_table(current, "Event"))
            # Qualify event references independently from candidate field refs.
            join_predicate = _and(
                _is_true(guard), _is_true(dependency_known), predicate
            )
            join_predicate = join_predicate.transform(
                lambda value: _column(value.name, "Event")
                if isinstance(value, exp.Column) and not value.table
                else value
            )
            query = query.join(candidate, on=join_predicate, join_type="LEFT")
            candidates_name = "FlowRecordLookup." + name + ".Candidates"
            ctes.append(
                exp.CTE(
                    this=query,
                    alias=exp.TableAlias(
                        this=exp.to_identifier(candidates_name, quoted=True)
                    ),
                )
            )
            current = candidates_name
            columns.extend(
                [name + "." + field for field in selected_fields]
                + [marker, "__lookup_known." + name]
            )
            count = exp.Window(
                this=exp.Count(this=_column(marker)),
                partition_by=[_column("flow_row_id")],
            )
            sort = node.get("sortField")
            order = None
            if sort:
                if node.get("sortOrder") not in {"Asc", "Desc"}:
                    raise UnsupportedFlowError(f"Unsupported lookup ordering: {name}")
                order = exp.Order(
                    expressions=[
                        exp.Ordered(
                            this=_column(name + "." + sort),
                            desc=node["sortOrder"] == "Desc",
                            nulls_first=node["sortOrder"] == "Asc",
                        )
                    ]
                )
            rank = exp.Window(
                this=exp.RowNumber(), partition_by=[_column("flow_row_id")], order=order
            )
            ties = (
                exp.Window(
                    this=exp.Count(this=_column(marker)),
                    partition_by=[_column("flow_row_id"), _column(name + "." + sort)],
                )
                if sort
                else count.copy()
            )
            append(
                "FlowRecordLookup." + name + ".Ranked",
                {
                    name + ".match_count": count,
                    "__rank." + name: rank,
                    "__ties." + name: ties,
                },
            )
            known_value = _column("__lookup_known." + name)
            expressions = {"__exists_known." + name: known_value}
            for field in selected_fields:
                value_known = _and(
                    known_value,
                    exp.true()
                    if field == sort
                    else exp.LTE(
                        this=_column("__ties." + name), expression=exp.Literal.number(1)
                    ),
                )
                expressions["__known." + name + "." + field] = value_known
                if field != "Id":
                    expressions[name + "." + field] = _case(
                        _is_true(value_known), _column(name + "." + field), exp.Null()
                    )
            append(
                "FlowRecordLookup." + name, expressions, owner, "FlowRecordLookup", node
            )
            ctes[-1].this.where(
                exp.EQ(
                    this=_column("__rank." + name), expression=exp.Literal.number(1)
                ),
                copy=False,
            )
            lookup_outputs.extend([
                name + ".Id",
                name + ".match_count",
                "__exists_known." + name,
                *["__known." + name + "." + field for field in selected_fields],
            ])
            for field in selected_fields:
                if field not in {"Id"}:
                    lookup_outputs.append(name + "." + field)
            successor = analysis.connector_targets.get(owner + "/connector")
            if successor in closure:
                edge_guards[successor].append(guard)
        elif kind == "recordUpdates":
            if _update_target(node, trigger) != selected[0]:
                raise UnsupportedFlowError(f"Update crosses selected target: {name}")
            assignments = {}
            for index, assignment in enumerate(node.get("inputAssignments") or ()):
                field = assignment.get("field")
                if field not in needed_assignments[name]:
                    continue
                if field in assignments:
                    raise UnsupportedFlowError(
                        f"Repeated field assignment: {name}.{field}"
                    )
                if assignment.get("value") is None:
                    raise UnsupportedFlowError(
                        f"Missing assignment value: {name}.{field}"
                    )
                value = native_value(assignment["value"])
                value_known = _and(
                    *(
                        known(reference)
                        for reference in _references(assignment["value"])
                    )
                )
                assignments[field] = value, value_known
                pointer = "/Metadata" + owner + f"/inputAssignments/{index}"
                output_paths[field].append(pointer)
                output_refs[field].extend(_references(assignment["value"]))
            expressions = {}
            for field, (value, value_known) in assignments.items():
                route_known = _not_null(guard)
                expressions["__state." + field] = _case(
                    _is_true(route_known),
                    _case(
                        _is_true(guard),
                        _case(_is_true(value_known), value, exp.Null()),
                        _column("__state." + field),
                    ),
                    exp.Null(),
                )
                expressions["__state_known." + field] = _and(
                    route_known,
                    _case(
                        _is_true(guard),
                        _is_true(value_known),
                        _column("__state_known." + field),
                    ),
                )
                expressions["__assigned." + field] = _case(
                    _is_true(route_known),
                    _or(_column("__assigned." + field), guard),
                    exp.Null(),
                )
            append(
                "FlowRecordUpdate." + name, expressions, owner, "FlowRecordUpdate", node
            )
            written = True
            completed_formulas.clear()
            successor = analysis.connector_targets.get(owner + "/connector")
            if successor in closure:
                edge_guards[successor].append(guard)
    # Dependencies discovered while lowering expressions are input columns, not
    # additional state-stage outputs. Every CTE projects its required predecessor.
    input_columns = [
        item["column"] for item in required.values() if item["table"] == "Flow_Record"
    ]
    initial = exp.select(
        *[_column(column) for column in input_columns],
        *[_alias(value, name) for name, value in initial_state.items()],
    ).from_(_table("Flow_Record"))
    ctes.insert(
        0,
        exp.CTE(
            this=initial,
            alias=exp.TableAlias(this=exp.to_identifier("Flow_Inputs", quoted=True)),
        ),
    )
    # Newly discovered external inputs must survive earlier stages too.
    for cte in ctes[1:]:
        query = cte.this
        projected = {item.alias_or_name for item in query.selects}
        for column in input_columns:
            if column not in projected:
                table = "Event" if cte.alias_or_name.endswith(".Candidates") else None
                query.select(
                    _alias(_column(column, table), column), append=True, copy=False
                )
    for item in required.values():
        if item["role"] in {"record", "prior_record", "before", "lookup"}:
            identity = f"{item['object_name']}.{item['field_path']}"
            definition = definitions.get(identity)
            item["definition_status"] = (
                "native" if definition is not None else "unresolved"
            )
            if definition is not None:
                item["column_definition"] = definition.dump()

    def output_dependencies(field):
        owners = {
            name
            for name in ordered
            if elements[name][0] == "recordUpdates"
            and any(
                assignment.get("field") == field
                for assignment in elements[name][2].get("inputAssignments") or ()
            )
        }
        pending = list(owners)
        while pending:
            for parent in parents[pending.pop()]:
                if parent in closure and parent not in owners:
                    owners.add(parent)
                    pending.append(parent)
        references = [target_reference, *output_refs[field]]
        paths = [*output_paths[field]]
        entities = []
        for name in ordered:
            if name in owners:
                paths.append("/Metadata" + elements[name][3])
                entities.append(ELEMENT_KINDS[elements[name][0]] + "." + name)
                references.extend(_references(node_dependencies(name)))
        pending = list(references)
        expanded = set()
        native_fields = [object_name + "." + field]
        while pending:
            reference = pending.pop()
            if reference in expanded:
                continue
            expanded.add(reference)
            if reference in formulas:
                paths.append("/Metadata" + formulas[reference][0] + "/expression")
                entities.append("FlowFormula." + reference)
                pending.extend(formula_references.get(reference, ()))
            elif reference.startswith(("$Record.", "$Record__Prior.")):
                native_fields.append(
                    (trigger or reference.partition(".")[0])
                    + "."
                    + reference.partition(".")[2]
                )
            elif reference.partition(".")[0] in lookups:
                resource, _, native_field = reference.partition(".")
                lookup = lookups[resource]
                paths.append("/Metadata" + elements[resource][3])
                entities.append("FlowRecordLookup." + resource)
                native_fields.append(str(lookup.get("object")) + "." + native_field)
                native_fields.extend(
                    str(lookup.get("object")) + "." + item["field"]
                    for item in lookup.get("filters") or ()
                )
                pending.extend(_references(lookup))
        return {
            "source_paths": list(dict.fromkeys(paths)),
            "source_entities": list(dict.fromkeys(entities)),
            "dependencies": sorted(expanded),
            "field_references": list(dict.fromkeys(native_fields)),
            "dependency_scope": "selected control and data closure",
        }

    output_metadata, projections = (
        {},
        [_column("flow_row_id"), _column("flow_record_id"), _column("flow_target_id")],
    )
    for field in fields:
        output = "expected__" + field
        evidence = source_metadata(
            {},
            source=source,
            target_field=object_name + "." + field,
            target_reference=target_reference,
            **output_dependencies(field),
            value_column=output,
            assigned_column=output + "__assigned",
            deterministic_column=output + "__deterministic",
        )
        definition = definitions.get(object_name + "." + field)
        evidence["definition_status"] = (
            "native" if definition is not None else "unresolved"
        )
        if definition is not None:
            evidence["column_definition"] = definition.dump()
        else:
            limitations.append(
                "Missing native type definition: " + object_name + "." + field
            )
        output_metadata[field] = evidence
        projections.extend([
            annotate(_alias(_column("__state." + field), output), evidence),
            _alias(_column("__assigned." + field), output + "__assigned"),
            _alias(
                _and(_column("__state_known." + field), _is_true(target_known)),
                output + "__deterministic",
            ),
        ])
    projections.extend(_column(name) for name in dict.fromkeys(lookup_outputs))
    query = exp.select(*projections).from_(_table(current))
    query.set("with_", exp.With(expressions=ctes))
    graph = dict(
        declarations=[asdict(item) for item in analysis.declarations],
        connections=[asdict(item) for item in analysis.connections],
        occurrences=[asdict(item) for item in analysis.occurrences],
    )
    query = annotate(
        query,
        source_metadata(
            metadata,
            source=source,
            description="Native Flow expected-state SELECT",
            binding_status="logical_template",
            path_type=path_type,
            object_name=object_name,
            target_reference=target_reference,
            input_relation="Flow_Record",
            row_identity="flow_row_id distinguishes occurrences within one query; it is not an immutable source event ID",
            record_identity={
                "column": "flow_record_id",
                "reference": "$Record.Id",
                "object_name": trigger,
            },
            required_inputs=list(required.values()),
            outputs=output_metadata,
            node_order=node_order,
            source_graph=graph,
            type_limitations=list(dict.fromkeys(limitations)),
            eligibility_contract={
                "column": "__eligible",
                "native_start": metadata.get("start"),
                "meaning": "Caller establishes native trigger eligibility including prior-state/change-to-meet policy; NULL means unknown",
            },
            simplification="faithful",
        ),
    )
    return _simplify_select(query) if simplify else query


def _simplify_select(query: exp.Select) -> exp.Select:
    """Prune and fold this compiler's pure single-use stages, retaining evidence.

    Qualification uses known column *names* with UNKNOWN storage types where no
    runtime type is declared. This is scope resolution, not native type inference.
    Targeted SQLGlot rules preserve join/window/filter boundaries and cap copying
    of shared expressions; no general optimizer or physical planning is invoked.
    """
    from sqlglot.errors import OptimizeError
    from sqlglot.optimizer.eliminate_ctes import eliminate_ctes
    from sqlglot.optimizer.merge_subqueries import merge_subqueries
    from sqlglot.optimizer.pushdown_projections import pushdown_projections
    from sqlglot.optimizer.qualify import qualify
    from sqlglot.optimizer.scope import Scope, traverse_scope
    from sqlglot.schema import MappingSchema

    evidence = deepcopy(query.meta["ppsc"])
    inputs = evidence["required_inputs"]
    schema = {}
    for item in inputs:
        schema.setdefault(item["table"], {})[item["column"]] = item.get(
            "data_type", "UNKNOWN"
        )
    before = {
        "ctes": len(query.ctes),
        "ast_nodes": sum(1 for _ in query.walk()),
        "sql_utf8_bytes": len(query.sql(dialect="athena").encode("utf-8")),
    }
    try:
        result = qualify(query.copy(), schema=MappingSchema(schema, normalize=False))
        result = pushdown_projections(result)
        result = merge_subqueries(
            result, leave_tables_isolated=True, max_copy_factor=1, min_copy_budget=1000
        )
        result = eliminate_ctes(pushdown_projections(result))
    except OptimizeError as error:
        raise UnsupportedFlowError(
            f"Cannot simplify native Flow SELECT: {error}"
        ) from error
    if result.named_selects != query.named_selects:
        raise UnsupportedFlowError("Flow simplification changed output identities")

    reads = set()
    for scope in traverse_scope(result):
        for alias, (_, source) in scope.selected_sources.items():
            if isinstance(source, Scope):
                continue
            reads.update(
                (source.name, column.name)
                for column in scope.columns
                if column.table == alias
            )
    evidence["original_required_inputs"] = inputs
    evidence["required_inputs"] = [
        item for item in inputs if (item["table"], item["column"]) in reads
    ]
    retained = {cte.alias_or_name for cte in result.ctes}
    evidence["simplification"] = {
        "mode": "bounded_native_stages",
        "rules": ["projection_pruning", "single_use_stage_folding", "unused_ctes"],
        "removed_ctes": [
            {"name": cte.alias_or_name, "source": deepcopy(cte.meta.get("ppsc", {}))}
            for cte in query.ctes
            if cte.alias_or_name not in retained
        ],
        "before": before,
        "after": {
            "ctes": len(result.ctes),
            "ast_nodes": sum(1 for _ in result.walk()),
            "sql_utf8_bytes": len(result.sql(dialect="athena").encode("utf-8")),
        },
    }
    result.meta["ppsc"] = evidence
    by_column = {
        output[key]: output
        for output in evidence["outputs"].values()
        for key in ("value_column", "assigned_column", "deterministic_column")
    }
    for projection in result.selects:
        if projection.alias_or_name in by_column:
            projection.meta["ppsc"] = deepcopy(by_column[projection.alias_or_name])
    return result
