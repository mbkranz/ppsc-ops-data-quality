"""Collect Tooling validation rules and build the workbook rule table."""

import json
from importlib import import_module
from pathlib import Path

from .analysis import ValidationRuleAnalysis, analyze_validation_rule

__all__ = [
    "ValidationRuleAnalysis",
    "analyze_validation_rule",
    "describe",
    "read_api",
    "to_graph",
    "payload_to_df",
    "models",
]


def __getattr__(name):
    if name == "models":
        return import_module(f"{__name__}.models")
    raise AttributeError(name)


def describe(salesforce_client):
    return salesforce_client.describe("ValidationRule", use_tooling_api=True)


def read_api(salesforce_client):
    from salesforce import soql_templates
    from salesforce.client import query_records

    templates = soql_templates.tooling.by_entity.ValidationRule
    inventory = query_records(
        salesforce_client.query(templates.inventory, use_tooling_api=True),
        "ValidationRule inventory",
    )
    pages = []
    for record in inventory:
        response = list(
            salesforce_client.query(
                templates.metadata.format(id=record["Id"]), use_tooling_api=True
            )
        )
        rules = query_records(response, "ValidationRule metadata")
        if (
            len(rules) != 1
            or rules[0]["Id"] != record["Id"]
            or not rules[0].get("Metadata")
        ):
            raise ValueError(f"Incomplete ValidationRule metadata for {record['Id']}")
        pages.extend(response)
    return pages


def to_graph(filepath, graph=None):
    import networkx as nx

    from salesforce.client import query_records
    from . import models

    if graph is None:
        graph = nx.MultiDiGraph()
    # Each envelope is a separate singleton query, rather than pagination of one query.
    for page in json.loads(Path(filepath).read_text()):
        for raw in query_records([page], "ValidationRule graph input"):
            models.ValidationRuleRecord.model_validate(raw).add_to_graph(graph)
    return graph


def payload_to_df(filepath):
    import pandas as pd

    from salesforce.client import query_records
    from . import models

    rows = {}
    for page in json.loads(Path(filepath).read_text()):
        for raw in query_records([page], "ValidationRule table input"):
            record = models.ValidationRuleRecord.model_validate(raw)
            if not record.Metadata or not record.FullName:
                raise ValueError("ValidationRule requires FullName and Metadata")
            row = record.Metadata.model_dump(exclude_none=True)
            row.update(
                object=(record.EntityDefinition or {}).get("QualifiedApiName")
                or record.FullName.split(".")[0],
                name=record.ValidationName or record.FullName.split(".")[-1],
            )
            for key, value in (
                ("active", record.Active),
                ("description", record.Description),
                ("errorDisplayField", record.ErrorDisplayField),
                ("errorMessage", record.ErrorMessage),
            ):
                if row.get(key) is None:
                    row[key] = value
            rows[record.FullName] = row
    frame = pd.DataFrame.from_dict(rows, orient="index")
    return frame.reindex(
        columns=[
            "object",
            "name",
            "description",
            "active",
            "errorConditionFormula",
            "errorDisplayField",
            "errorMessage",
            "node_kind",
            "node_hierarchy",
        ]
    )
