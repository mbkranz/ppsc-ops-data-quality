"""Pure native validation-rule evidence, independent of acquisition and graphs."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal

from salesforce.core.analysis import (
    Connection,
    Declaration,
    Diagnostic,
    Expression,
    NativeDocument,
    ReferenceOccurrence,
    SourceIdentity,
    SourceLocation,
)
from salesforce.core.catalog import CatalogIndex, FieldBinding, canonical_field_id
from salesforce.core.formulas import formula_references

__all__ = ["ValidationRuleAnalysis", "analyze_validation_rule"]


@dataclass(frozen=True)
class ValidationRuleAnalysis:
    document: NativeDocument
    source: SourceIdentity
    owner_id: str
    full_name: str
    object_name: str
    declarations: tuple[Declaration, ...]
    references: tuple[ReferenceOccurrence, ...]
    connections: tuple[Connection, ...]
    expressions: tuple[Expression, ...]
    diagnostics: tuple[Diagnostic, ...]
    bindings: tuple[tuple[str, FieldBinding], ...]


def analyze_validation_rule(
    metadata: Mapping[str, Any] | None,
    full_name: str,
    *,
    object_name: str | None = None,
    catalog: CatalogIndex | None = None,
    source: SourceIdentity | None = None,
) -> ValidationRuleAnalysis:
    """Analyze Metadata, not a Tooling envelope; inactive rules retain evidence.

    Locations are metadata-relative. Missing acquisition and unsupported
    interpretation are distinct diagnostics. Bindings preserve exact catalog
    status (including ambiguity); unresolved occurrences are never discarded.
    The model wrapper supplies its effective error-display operand separately
    from native analysis so its historical record-level policy remains intact.
    """
    if not isinstance(full_name, str) or not full_name:
        raise ValueError("ValidationRule requires a nonempty full_name")
    object_name = object_name or full_name.split(".", 1)[0]
    document = NativeDocument(metadata if metadata is not None else {})
    owner_id = f"ValidationRule/{full_name}"
    references: list[ReferenceOccurrence] = []
    connections = [
        Connection(
            f"EntityDefinition/{object_name}",
            owner_id,
            "contains",
            "validation_rule_defined_on",
            owner_id,
            SourceLocation(""),
        )
    ]
    expressions: list[Expression] = []
    diagnostics: list[Diagnostic] = []
    bindings: list[tuple[str, FieldBinding]] = []
    if metadata is None:
        diagnostics.append(
            Diagnostic(
                "incomplete_metadata",
                "Validation-rule metadata was not acquired",
                SourceLocation(""),
                owner_id,
                "structural",
            )
        )

    def reference(
        value,
        role: str,
        location: SourceLocation,
        syntax: Literal["native", "bare", "merge"] = "native",
    ):
        if not isinstance(value, str) or not value:
            if value is not None and value != "":
                diagnostics.append(
                    Diagnostic(
                        "invalid_reference",
                        "Native references require strings",
                        location,
                        owner_id,
                        "structural",
                    )
                )
            return
        occurrence = ReferenceOccurrence(value, location, owner_id, role, syntax)
        references.append(occurrence)
        if value.startswith("$"):
            endpoint = f"FormulaGlobal/{value}"
            diagnostics.append(
                Diagnostic(
                    "uninterpreted_global_reference",
                    "Global formula references are retained without field binding",
                    location,
                    owner_id,
                    "uninterpreted",
                )
            )
        else:
            obj, path = object_name, value
            prefix, dot, tail = value.partition(".")
            if dot and (
                prefix == object_name
                or (catalog is not None and prefix in catalog.objects)
            ):
                obj, path = prefix, tail
            binding = (
                catalog.resolve(obj, path) if catalog else FieldBinding("unresolved")
            )
            bindings.append((occurrence.occurrence_id, binding))
            identity = binding.identity
            endpoint = (
                canonical_field_id(identity)
                if identity
                else f"FieldReference/{obj}.{path}"
            )
            if binding.status != "resolved":
                diagnostics.append(
                    Diagnostic(
                        "catalog_unavailable"
                        if catalog is None
                        else f"{binding.status}_field",
                        "Field binding is unavailable"
                        if catalog is None
                        else f"Exact field binding is {binding.status}: {value}",
                        location,
                        owner_id,
                        "binding",
                    )
                )
            elif (
                identity is not None
                and identity.kind == "EntityParticle"
                and identity.parent_name
                and catalog is not None
            ):
                parent = catalog.resolve(identity.object_name, identity.parent_name)
                if parent.identity and parent.identity.kind == "FieldDefinition":
                    connections.append(
                        Connection(
                            canonical_field_id(parent.identity),
                            endpoint,
                            "contains",
                            "field_particle",
                            owner_id,
                            location,
                            (occurrence.occurrence_id,),
                        )
                    )
        connections.append(
            Connection(
                endpoint,
                owner_id,
                "reads",
                role,
                owner_id,
                location,
                (occurrence.occurrence_id,),
            )
        )

    formula = document.root.get("errorConditionFormula")
    if "errorConditionFormula" in document.root:
        location = SourceLocation("/errorConditionFormula")
        if isinstance(formula, str):
            parsed = formula_references(formula)
            for item in parsed["references"]:
                start, end = item["start"], item["end"]
                reference(
                    item["reference"],
                    "validation_condition",
                    SourceLocation(location.pointer, start, end),
                    "merge" if formula[max(0, start - 2) : start] == "{!" else "bare",
                )
            for item in parsed["unparsed"]:
                diagnostics.append(
                    Diagnostic(
                        "unparsed_formula",
                        "Unsupported native formula notation",
                        SourceLocation(location.pointer, item["start"], item["end"]),
                        owner_id,
                        "uninterpreted",
                    )
                )
        elif formula is not None:
            diagnostics.append(
                Diagnostic(
                    "invalid_formula",
                    "Formula text is not a string",
                    location,
                    owner_id,
                    "structural",
                )
            )
        expressions.append(
            Expression(
                owner_id,
                location,
                "salesforce_formula",
                tuple(item.occurrence_id for item in references),
            )
        )
    reference(
        document.root.get("errorDisplayField"),
        "validation_error_display",
        SourceLocation("/errorDisplayField"),
    )
    return ValidationRuleAnalysis(
        document,
        source or SourceIdentity(),
        owner_id,
        full_name,
        object_name,
        (
            Declaration(
                owner_id,
                full_name.rsplit(".", 1)[-1],
                "ValidationRule",
                SourceLocation(""),
            ),
        ),
        tuple(references),
        tuple(connections),
        tuple(expressions),
        tuple(diagnostics),
        tuple(bindings),
    )
