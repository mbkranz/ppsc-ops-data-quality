"""Offline native metadata evidence and optional Ibis compilation.

Import individual adapters explicitly. Importing this package does not load an
engine, an acquisition client, or a document-rendering dependency.
"""

__version__ = "0.3.0"
