"""Verify a versioned native-source and APMP-definition selection offline."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

LAKE_ROLES = frozenset({"catalog", "ddl", "bindings", "view", "schema"})


class MetadataArtifact(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    path: str = Field(min_length=1)
    role: Literal[
        "flow", "source", "rollup", "catalog", "ddl", "bindings", "view", "schema"
    ]
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @field_validator("path")
    @classmethod
    def relative_path(cls, value: str) -> str:
        path = PurePosixPath(value)
        if (
            path.is_absolute()
            or ".." in path.parts
            or "\\" in value
            or str(path) != value
        ):
            raise ValueError("Artifact paths must be normalized relative POSIX paths")
        return value


def definition_identity(artifacts: tuple[MetadataArtifact, ...]) -> str:
    """Identify the complete selected lake definition bytes, independent of location."""
    selected = [
        item.model_dump(mode="json")
        for item in sorted(artifacts, key=lambda item: item.path)
        if item.role in LAKE_ROLES
    ]
    return hashlib.sha256(
        json.dumps(selected, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


class MetadataManifest(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    version: Literal["projection-inputs/v2"] = "projection-inputs/v2"
    org: str = Field(min_length=1)
    flow_name: str | None = Field(default=None, min_length=1)
    flow_version_id: str | None = Field(default=None, min_length=1)
    source_revision: str = Field(pattern=r"^[0-9a-f]{40}$")
    definition_revision: str = Field(pattern=r"^[0-9a-f]{40}$")
    definition_id: str = Field(pattern=r"^[0-9a-f]{64}$")
    provisional: bool
    coverage: str = Field(min_length=1)
    artifacts: tuple[MetadataArtifact, ...] = Field(min_length=3)

    @model_validator(mode="before")
    @classmethod
    def migrate_v1(cls, value):
        if isinstance(value, dict) and value.get("version") == "projection-inputs/v1":
            raise ValueError(
                "projection-inputs/v1 is retired; regenerate native/APMP inputs as projection-inputs/v2"
            )
        return value

    @model_validator(mode="after")
    def validate_selection(self):
        paths = [item.path for item in self.artifacts]
        if len(paths) != len(set(paths)):
            raise ValueError("Metadata artifact paths must be unique")
        if bool(self.flow_name) != bool(self.flow_version_id):
            raise ValueError("Select the exact Flow name and version together")
        for role in ("flow", "rollup", "catalog", "bindings"):
            count = sum(item.role == role for item in self.artifacts)
            expected = (
                1
                if role in {"catalog", "bindings"}
                or (role == "flow" and self.flow_name)
                else None
            )
            if count > 1 or (expected is not None and count != expected):
                raise ValueError(
                    f"Select {'exactly one' if expected else 'at most one'} {role} artifact"
                )
            if role == "flow" and count and not self.flow_name:
                raise ValueError(
                    "A Flow artifact requires an exact selected Flow identity"
                )
        if not any(item.role in {"ddl", "schema"} for item in self.artifacts):
            raise ValueError(
                "Select at least one lake table DDL or verified output schema"
            )
        if definition_identity(self.artifacts) != self.definition_id:
            raise ValueError(
                "APMP definition identity does not match selected artifact hashes"
            )
        return self


class MetadataBundle(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    manifest: MetadataManifest
    manifest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    flow: dict[str, Any] = Field(default_factory=dict)
    rollups: dict[str, dict[str, Any]] = Field(default_factory=dict)
    source_catalog: dict[str, Any] = Field(default_factory=dict)
    artifacts: dict[str, str] = Field(default_factory=dict)


class MetadataReceipt(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    manifest: MetadataManifest
    manifest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    compiler_version: str = Field(min_length=1)
    definition_id: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def matching_definition(self):
        if self.definition_id != self.manifest.definition_id:
            raise ValueError(
                "Receipt definition identity must match its selected manifest"
            )
        return self


def load_metadata_bundle(root: Path, manifest_path: Path) -> MetadataBundle:
    """Verify installed bytes and return fresh parsed values; never acquire evidence."""
    root = root.resolve()
    if not manifest_path.resolve().is_relative_to(root):
        raise ValueError("Metadata manifest escapes its root")
    payload = manifest_path.read_bytes()
    manifest = MetadataManifest.model_validate_json(payload)
    selected: dict[str, str] = {}
    artifacts: dict[str, str] = {}
    for artifact in manifest.artifacts:
        path = (root / artifact.path).resolve()
        if not path.is_relative_to(root):
            raise ValueError(f"Metadata artifact escapes its root: {artifact.path}")
        content = path.read_bytes()
        if hashlib.sha256(content).hexdigest() != artifact.sha256:
            raise ValueError(f"Metadata artifact hash mismatch: {artifact.path}")
        try:
            text = content.decode("utf-8")
        except UnicodeDecodeError:
            if artifact.role != "source":
                raise ValueError(
                    f"Selected {artifact.role} must be UTF-8 text: {artifact.path}"
                ) from None
            continue
        artifacts[artifact.path] = text
        if artifact.role in {"flow", "rollup"}:
            selected[artifact.role] = text
    flow = json.loads(selected["flow"]) if "flow" in selected else {}
    if manifest.flow_name:
        if (
            flow.get("Id") != manifest.flow_version_id
            or flow.get("FullName") != manifest.flow_name
        ):
            raise ValueError("Selected Flow identity does not match its manifest")
        if not isinstance(flow.get("Metadata"), dict):
            raise ValueError("Selected Flow must retain its native Metadata")
    rollups = json.loads(selected["rollup"]) if "rollup" in selected else {}
    if not isinstance(rollups, dict) or any(
        not isinstance(name, str) or not isinstance(value, dict)
        for name, value in rollups.items()
    ):
        raise ValueError("Selected rollups must map field names to native metadata")
    source_catalog = (
        json.loads(artifacts["source_catalog.json"])
        if "source_catalog.json" in artifacts
        else {}
    )
    if not isinstance(source_catalog, dict):
        raise ValueError("Native source catalog must be an object")
    return MetadataBundle(
        manifest=manifest,
        manifest_sha256=hashlib.sha256(payload).hexdigest(),
        flow=flow,
        rollups=rollups,
        source_catalog=source_catalog,
        artifacts=artifacts,
    )
