"""Native projection provenance, independent of a contract or execution service."""

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ProjectionEvidence(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    target_field: str = Field(min_length=1)
    source_entities: tuple[str, ...]
    source_paths: tuple[str, ...]
    description: str
    branches: tuple[dict[str, Any], ...] = ()
    dependencies: tuple[str, ...] = ()
    field_references: tuple[str, ...] = ()
