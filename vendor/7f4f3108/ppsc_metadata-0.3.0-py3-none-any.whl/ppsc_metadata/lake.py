"""Explicit lake bindings shared as static evidence, without clients or Ibis imports."""

from __future__ import annotations

from pathlib import PurePosixPath
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


def _unique_names(values: tuple[str, ...] | list[str], label: str) -> None:
    if any(not value.strip() for value in values) or len({
        v.casefold() for v in values
    }) != len(values):
        raise ValueError(
            f"{label} must contain nonempty, unique names without case collisions"
        )


class DatasetBinding(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    native_object: str = Field(min_length=1)
    catalog: str = Field(min_length=1)
    database: str = Field(min_length=1)
    relation: str = Field(min_length=1)
    kind: Literal["table", "view"] = "table"
    ddl_path: str | None = None
    schema_path: str | None = None
    columns: dict[str, str] = Field(min_length=1)
    keys: tuple[str, ...] = Field(min_length=1)
    grain: str = Field(min_length=1)
    partition_columns: tuple[str, ...] = ()
    history_fields: tuple[str, ...] = ()
    history_boundaries: tuple[str, ...] = ()
    history_grain: Literal["timestamp", "date", "unestablished"] = "unestablished"
    authored_descriptions: dict[str, str] = Field(default_factory=dict)
    ddl_completeness: Literal["schema-only", "executable"] = "schema-only"
    provisional: bool = True

    @model_validator(mode="after")
    def validate_binding(self) -> DatasetBinding:
        for values, name in (
            (list(self.columns), "Physical columns"),
            (list(self.columns.values()), "Logical columns"),
            (self.keys, "Keys"),
            (self.partition_columns, "Partitions"),
            (self.history_fields, "History fields"),
        ):
            _unique_names(values, name)
        logical = set(self.columns.values())
        if not set(self.keys + self.history_fields).issubset(logical):
            raise ValueError(
                "Keys and history fields must select mapped logical columns"
            )
        if not set(self.partition_columns).issubset(self.columns):
            raise ValueError("Partition columns must select mapped physical columns")
        _unique_names(self.history_boundaries, "History boundary fields")
        if not set(self.history_boundaries).issubset(self.history_fields):
            raise ValueError("History boundaries must select mapped history fields")
        if self.history_grain != "unestablished" and not self.history_boundaries:
            raise ValueError(
                "Declared history grain requires explicit state boundary fields"
            )
        if not set(self.authored_descriptions).issubset(logical):
            raise ValueError(
                "Authored descriptions must identify mapped logical columns"
            )
        if self.kind == "table" and (not self.ddl_path or self.schema_path):
            raise ValueError(
                "A physical table requires ddl_path and no derived schema_path"
            )
        if self.kind == "view" and (not self.ddl_path or not self.schema_path):
            raise ValueError(
                "A registered view requires SQL and its verified output-schema sidecar"
            )
        for path in (self.ddl_path, self.schema_path):
            if path is not None:
                parts = PurePosixPath(path)
                if parts.is_absolute() or ".." in parts.parts or "\\" in path:
                    raise ValueError(
                        f"Binding artifact path must stay within its bundle: {path}"
                    )
        return self


class RelationshipBinding(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    source_object: str = Field(min_length=1)
    source_fields: tuple[str, ...] = Field(min_length=1)
    target_object: str = Field(min_length=1)
    target_fields: tuple[str, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_pairs(self) -> RelationshipBinding:
        _unique_names(self.source_fields, "Source relationship fields")
        _unique_names(self.target_fields, "Target relationship fields")
        if len(self.source_fields) != len(self.target_fields):
            raise ValueError("Relationship keys require equal ordered arity")
        return self


class LakeBindings(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    version: Literal["apmp-bindings/v1"] = "apmp-bindings/v1"
    datasets: dict[str, DatasetBinding] = Field(min_length=1)
    relationships: tuple[RelationshipBinding, ...] = ()

    @model_validator(mode="after")
    def validate_resources(self) -> LakeBindings:
        _unique_names(list(self.datasets), "Dataset selections")
        objects = [item.native_object for item in self.datasets.values()]
        _unique_names(objects, "Native object bindings")
        by_object = {item.native_object: item for item in self.datasets.values()}
        relations = [
            (
                item.catalog.casefold(),
                item.database.casefold(),
                item.relation.casefold(),
            )
            for item in self.datasets.values()
        ]
        if len(set(relations)) != len(relations):
            raise ValueError("Each selected dataset needs a distinct physical relation")
        seen = set()
        for relationship in self.relationships:
            identity = (relationship.source_object, relationship.source_fields)
            if identity in seen:
                raise ValueError("Conflicting or duplicate relationship declaration")
            seen.add(identity)
            for obj, fields in (
                (relationship.source_object, relationship.source_fields),
                (relationship.target_object, relationship.target_fields),
            ):
                if obj not in by_object or not set(fields).issubset(
                    by_object[obj].columns.values()
                ):
                    raise ValueError(
                        f"Relationship refers to unmapped fields: {obj}.{fields}"
                    )
        return self
