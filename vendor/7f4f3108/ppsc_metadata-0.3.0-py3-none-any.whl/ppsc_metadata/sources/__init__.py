"""Normalize saved source artifacts; acquisition remains in source applications."""
