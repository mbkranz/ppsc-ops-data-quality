"""Compile native rollup metadata; snapshots and empty-result policy are explicit."""

from __future__ import annotations

import operator
import math
from collections.abc import Mapping
from functools import reduce
from typing import Any

import ibis
import ibis.expr.types as ir
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StrictStr,
    StrictInt,
    StrictFloat,
    StrictBool,
)

from ..evidence import ProjectionEvidence


class CountRollupRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    output_field: str = Field(min_length=1)
    child_object: str = Field(min_length=1)
    parent_key: str = Field(default="Id", min_length=1)


class RollupRequest(CountRollupRequest):
    model_config = ConfigDict(extra="forbid", frozen=True, allow_inf_nan=False)
    # Required even when NULL: do not infer an org's empty/all-null policy.
    empty_value: StrictStr | StrictInt | StrictFloat | StrictBool | None


def _child_field(reference: Any, request: CountRollupRequest) -> str:
    prefix = request.child_object + "."
    if not isinstance(reference, str) or not reference.startswith(prefix):
        raise ValueError("Bind a direct native child field explicitly")
    name = reference.removeprefix(prefix)
    if not name or "." in name:
        raise ValueError("Bind a direct native child field explicitly")
    return name


def rollup_values(
    parent: ir.Table,
    child: ir.Table,
    metadata: Mapping[str, Any],
    request: RollupRequest,
) -> ir.Table:
    """Return one expected aggregate per parent input row, including duplicates.

    Only COUNT/SUM/MIN/MAX and scalar conjunctive native filters are supported.
    empty_value applies to empty/all-null aggregates. The caller supplies the
    eligible child snapshot and owns deletion, currency and temporal policies.
    """
    operation = metadata.get("summaryOperation")
    if any(
        metadata.get(key) not in (None, "and")
        for key in ("summaryFilterLogic", "filterLogic")
    ):
        raise ValueError("Unsupported native rollup filter logic")
    if operation not in {"count", "sum", "min", "max"}:
        raise ValueError(f"Unsupported native rollup operation: {operation}")
    if operation == "count" and (
        type(request.empty_value) is not int or request.empty_value != 0
    ):
        raise ValueError("Native COUNT requires empty_value=0")
    if request.empty_value is not None and type(request.empty_value) not in {
        str,
        int,
        float,
        bool,
    }:
        raise ValueError("Rollup empty_value must be a scalar or NULL")
    if (
        request.parent_key not in parent.columns
        or request.output_field in parent.columns
    ):
        raise ValueError("Rollup parent key is unbound or output column collides")
    key = _child_field(metadata.get("summaryForeignKey"), request)
    if key not in child.columns:
        raise ValueError(f"Unbound native rollup field: {key}")
    if parent[request.parent_key].type().copy(nullable=True) != child[key].type().copy(
        nullable=True
    ):
        raise ValueError("Rollup parent/child key types must match")
    predicates = []
    operations = {
        "equals": operator.eq,
        "notEqual": operator.ne,
        "greaterThan": operator.gt,
        "greaterOrEqual": operator.ge,
        "lessThan": operator.lt,
        "lessOrEqual": operator.le,
    }
    for item in metadata.get("summaryFilterItems") or []:
        if (
            item.get("valueField")
            or item.get("valueSetName")
            or item.get("operation") not in operations
        ):
            raise ValueError("Unsupported native rollup filter")
        name = _child_field(item.get("field"), request)
        if name not in child.columns:
            raise ValueError(f"Unbound native rollup field: {name}")
        value = item.get("value")
        if type(value) not in {str, int, float, bool}:
            raise ValueError("Rollup filter requires a scalar literal")
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("Rollup filter requires a finite literal")
        dtype = child[name].type()
        if dtype.is_boolean() and isinstance(value, str):
            if value.lower() not in {"true", "false"}:
                raise ValueError("Boolean rollup filters require true or false")
            value = value.lower() == "true"
        right = ibis.literal(value).cast(dtype)
        predicates.append(
            operations[item["operation"]](child[name], right).fill_null(False)
        )
    child = child.filter(reduce(operator.and_, predicates)) if predicates else child
    if operation == "count":
        aggregate = child.count()
    else:
        field = _child_field(metadata.get("summarizedField"), request)
        if field not in child.columns:
            raise ValueError(f"Unbound native rollup field: {field}")
        value = child[field]
        if operation == "sum" and not value.type().is_numeric():
            raise ValueError("SUM requires a numeric native field")
        aggregate = getattr(value, operation)()
    summarized = child.group_by(child[key].name("__ppsc_rollup_key")).aggregate(
        __ppsc_rollup_value=aggregate
    )
    joined = parent.left_join(
        summarized, parent[request.parent_key] == summarized.__ppsc_rollup_key
    )
    result = summarized.__ppsc_rollup_value
    if request.empty_value is not None:
        result = result.fill_null(ibis.literal(request.empty_value).cast(result.type()))
    return joined.select(parent, result.name(request.output_field))


def count_rollup(
    parent: ir.Table,
    child: ir.Table,
    metadata: Mapping[str, Any],
    request: CountRollupRequest,
) -> ir.Table:
    """Compatible COUNT entry point with explicit zero-child behavior."""
    if metadata.get("summaryOperation") != "count":
        raise ValueError("The native COUNT adapter requires summaryOperation=count")
    return rollup_values(
        parent, child, metadata, RollupRequest(**request.model_dump(), empty_value=0)
    )


def rollup_lineage(
    metadata: Mapping[str, Any], request: CountRollupRequest, *, parent_object: str
) -> ProjectionEvidence:
    """Retain native aggregation, join and filter references independently of SQL."""
    references = [f"{parent_object}.{request.parent_key}"]
    paths = ["/summaryOperation", "/summaryForeignKey"]
    for key in ("summaryForeignKey", "summarizedField"):
        if metadata.get(key):
            references.append(metadata[key])
            paths.append("/" + key)
    for index, item in enumerate(metadata.get("summaryFilterItems") or []):
        paths.append(f"/summaryFilterItems/{index}")
        references.extend(item[key] for key in ("field", "valueField") if item.get(key))
    return ProjectionEvidence(
        target_field=f"{parent_object}.{request.output_field}",
        source_entities=(f"FieldDefinition.{parent_object}.{request.output_field}",),
        source_paths=tuple(dict.fromkeys(paths)),
        description=f"Native {metadata.get('summaryOperation')} rollup over {request.child_object}; caller binds the eligible snapshot and empty aggregate policy",
        dependencies=tuple(dict.fromkeys(references)),
        field_references=tuple(dict.fromkeys(references)),
    )
