"""Salesforce acquisition, native metadata and offline query interpretation.

Import domain modules explicitly. Importing this package creates no clients.
"""

from importlib import import_module

__all__ = ["entities", "records", "soql_templates", "templates"]


def __getattr__(name):
    if name in __all__:
        return import_module(
            f"{__name__}.{'soql_templates' if name == 'templates' else name}"
        )
    raise AttributeError(name)
