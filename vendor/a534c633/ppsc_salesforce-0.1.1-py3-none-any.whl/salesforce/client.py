"""Compatible Salesforce client backed by simple-salesforce.

Local SSO is managed by Salesforce CLI; explicit refresh-token authentication
remains available for existing unattended workflows.
"""

from __future__ import annotations

import json
import logging
import math
import os
import re
import subprocess
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import UTC, datetime
from email.utils import parsedate_to_datetime
from hashlib import sha256
from pathlib import Path
from random import uniform
from tempfile import NamedTemporaryFile
from time import monotonic, sleep
from typing import Annotated
from urllib.parse import urlsplit

import requests
import simple_salesforce
from pydantic import (
    AwareDatetime,
    BaseModel,
    ConfigDict,
    Field,
    InstanceOf,
    ValidationInfo,
    model_validator,
)
from simple_salesforce import Salesforce
from simple_salesforce.exceptions import (
    SalesforceError,
    SalesforceExpiredSession,
    SalesforceMalformedRequest,
)
from simple_salesforce.metadata import MetadataType
from zeep import Client as ZeepClient
from zeep import Settings
from zeep.exceptions import Fault, TransportError
from zeep.helpers import serialize_object
from zeep.transports import Transport

from salesforce import soql_templates


Digest = Annotated[str, Field(pattern=r"^[a-f0-9]{64}$")]
EntityName = Annotated[str, Field(pattern=r"^[A-Za-z0-9_]+$")]
NonEmptyString = Annotated[str, Field(min_length=1)]
CHECKPOINT_CONFIG = ConfigDict(
    strict=True,
    extra="forbid",
    revalidate_instances="always",
    hide_input_in_errors=True,
)


class CheckpointScope(BaseModel):
    model_config = CHECKPOINT_CONFIG

    instance_url: Annotated[str, Field(pattern=r"^https://[^/?#]+$")]
    org_id: Annotated[str, Field(pattern=r"^00D[A-Za-z0-9]{12}$")]
    user_id: Annotated[str, Field(pattern=r"^005[A-Za-z0-9]{12}$")]
    language: NonEmptyString
    locale: NonEmptyString
    api_version: Annotated[str, Field(pattern=r"^v\d+\.\d+$")]
    template_hash: Digest


class CheckpointEntry(BaseModel):
    model_config = CHECKPOINT_CONFIG

    digest: Digest
    fetched_at: AwareDatetime = Field(default_factory=lambda: datetime.now(UTC))


@contextmanager
def atomic_output(path: Path):
    """Replace one file only after its temporary output has been written."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with NamedTemporaryFile(
        dir=path.parent, prefix=f".{path.name}.", delete=False
    ) as file:
        temporary = Path(file.name)
    try:
        yield temporary
        with temporary.open("rb") as file:
            os.fsync(file.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def save_payload(directory: Path, value) -> CheckpointEntry:
    payload = json.dumps(value, separators=(",", ":")).encode("utf-8")
    digest = sha256(payload).hexdigest()
    with atomic_output(directory / "payloads" / f"{digest}.json") as temporary:
        temporary.write_bytes(payload)
    return CheckpointEntry(digest=digest)


def load_payload(directory: Path, entry: CheckpointEntry):
    entry = CheckpointEntry.model_validate(entry)
    payload = (directory / "payloads" / f"{entry.digest}.json").read_bytes()
    if sha256(payload).hexdigest() != entry.digest:
        raise ValueError("Checkpoint payload checksum mismatch")
    return json.loads(payload)


READ_RETRY_DELAYS = (1, 2)
RETRYABLE_READ_STATUSES = {500, 502, 503, 504}
PERMANENT_READ_CODES = {
    "INVALID_SESSION_ID",
    "MALFORMED_QUERY",
    "INVALID_FIELD",
    "INVALID_TYPE",
    "INSUFFICIENT_ACCESS",
    "INSUFFICIENT_ACCESS_OR_READONLY",
    "API_DISABLED_FOR_ORG",
    "REQUEST_LIMIT_EXCEEDED",
    "INVALID_QUERY_FILTER_OPERATOR",
    "EXCEEDED_ID_LIMIT",
}
READ_RETRY_ERRORS = (
    SalesforceError,
    requests.ConnectionError,
    requests.Timeout,
    requests.exceptions.ChunkedEncodingError,
    requests.exceptions.JSONDecodeError,
    TransportError,
)


def is_transient_read_error(error: Exception) -> bool:
    """Conservative read-only classification; unknown quota failures stop collection."""
    if isinstance(error, requests.exceptions.SSLError):
        return False
    if isinstance(error, SalesforceError):
        details = error.content if isinstance(error.content, list) else []
        codes = {item.get("errorCode") for item in details if isinstance(item, dict)}
        if codes & PERMANENT_READ_CODES:
            return False
        return error.status in RETRYABLE_READ_STATUSES | {429}
    if isinstance(error, TransportError):
        return error.status_code in RETRYABLE_READ_STATUSES | {429}
    return isinstance(error, READ_RETRY_ERRORS)


def can_defer_read_error(error: Exception) -> bool:
    """Only isolated transient failures may enter an export's final recovery pass."""
    status = getattr(error, "status", getattr(error, "status_code", None))
    return (
        is_transient_read_error(error)
        and status != 429
        and not getattr(error, "_salesforce_stop_collection", False)
    )


def retry_after_seconds(value: str | None) -> float | None:
    if not isinstance(value, str):
        return None
    value = value.strip()
    if re.fullmatch(r"[0-9]+", value):
        try:
            return float(value)
        except OverflowError:
            return float("inf")
    try:
        when = parsedate_to_datetime(value)
        if when.tzinfo is None:
            return None
        return max(0.0, (when - datetime.now(UTC)).total_seconds())
    except (ValueError, TypeError, OverflowError):
        return None


class RequestBudgetExceeded(RuntimeError):
    """Collection stopped before dispatching work beyond its configured allowance."""


@dataclass
class RunBudget:
    """Local HTTP dispatch accounting and a cooperative monotonic deadline."""

    max_requests: int | None = None
    max_elapsed_seconds: float | None = None
    started: float = field(default_factory=lambda: monotonic())
    requests: int = 0
    oauth_requests: int = 0
    retries: int = 0
    refreshes: int = 0
    api_usage: str | None = None

    def __post_init__(self):
        if self.max_requests is not None and (
            type(self.max_requests) is not int or self.max_requests < 0
        ):
            raise ValueError("max_requests must be a nonnegative integer")
        if self.max_elapsed_seconds is not None and (
            isinstance(self.max_elapsed_seconds, bool)
            or not math.isfinite(self.max_elapsed_seconds)
            or self.max_elapsed_seconds < 0
        ):
            raise ValueError("max_elapsed_seconds must be finite and nonnegative")

    @property
    def elapsed(self):
        return monotonic() - self.started

    def check(self, *, wait=0.0, dispatch=False):
        if (
            dispatch
            and self.max_requests is not None
            and self.requests >= self.max_requests
        ):
            raise RequestBudgetExceeded("Salesforce run request allowance exhausted")
        if (
            self.max_elapsed_seconds is not None
            and self.elapsed + wait >= self.max_elapsed_seconds
        ):
            raise RequestBudgetExceeded("Salesforce run elapsed allowance exhausted")


@dataclass(frozen=True)
class ResponseMetadata:
    status: int
    retry_after: str | None = None
    api_usage: str | None = None


def _response_metadata(response):
    usage = response.headers.get("Sforce-Limit-Info")
    match = re.search(r"(?:^|[;,]\s*)api-usage=(\d+)/(\d+)(?:$|[;,])", usage or "")
    return ResponseMetadata(
        response.status_code,
        response.headers.get("Retry-After"),
        f"{match[1]}/{match[2]}" if match else None,
    )


class MalformedQueryError(Exception):
    """A malformed SOQL query, retained for existing callers."""


class AuthenticationError(RuntimeError):
    """A sanitized authentication failure."""


class IncompleteQueryError(ValueError):
    """A completed query whose rows do not match the server's total."""

    def __init__(self, context, expected, page_counts):
        self.context = context
        self.expected = expected
        self.page_counts = tuple(page_counts)
        self.retrieved = sum(page_counts)
        super().__init__(
            f"Incomplete query result for {context}: expected={expected}, "
            f"retrieved={self.retrieved}, pages={list(page_counts)}"
        )


def query_records(pages, context):
    """Validate retained query pages and collect their records."""
    if not isinstance(pages, list) or not pages:
        raise ValueError(f"Malformed query response pages for {context}")
    expected = None
    records = []
    page_counts = []
    for index, page in enumerate(pages):
        QueryResult.model_validate(
            page, context={"query": context, "expected": expected}
        )
        expected = page["totalSize"]
        if page["done"] is not (index == len(pages) - 1):
            raise ValueError(f"Incomplete query pages for {context}")
        page_counts.append(len(page["records"]))
        records.extend(page["records"])
    if len(records) != expected:
        raise IncompleteQueryError(context, expected, page_counts)
    return records


class QueryResult(BaseModel):
    """Envelope shared by retained metadata query models."""

    model_config = ConfigDict(
        extra="allow", revalidate_instances="always", hide_input_in_errors=True
    )
    records: list[InstanceOf[dict]] = Field(strict=True)
    done: bool = Field(strict=True)
    totalSize: int = Field(strict=True, ge=0)
    nextRecordsUrl: str | None = Field(default=None, strict=True)

    @model_validator(mode="after")
    def validate_pagination(self, info: ValidationInfo):
        context = info.context or {}
        query = context.get("query", "query result")
        expected = context.get("expected")
        if expected is not None and self.totalSize != expected:
            raise ValueError(f"Inconsistent totalSize for {query}")
        if self.done:
            if self.nextRecordsUrl:
                raise ValueError(
                    f"Completed query advertises a continuation for {query}"
                )
        elif not self.nextRecordsUrl:
            raise ValueError(f"Missing Salesforce continuation for {query}")
        return self


class InsufficientAccessErrorResponse(BaseModel):
    errorCode: str
    message: str


class TimeoutSession(requests.Session):
    """Serial session boundary for REST and SOAP; no adapter-level retries."""

    def __init__(self):
        super().__init__()
        self.budget: RunBudget | None = None
        self.response_metadata: ResponseMetadata | None = None

    def request(self, method, url, **kwargs):
        if kwargs.get("timeout") is None:
            kwargs["timeout"] = (10, 60)
        return super().request(method, url, **kwargs)

    def send(self, request, **kwargs):
        self.response_metadata = None
        if self.budget is not None and urlsplit(request.url).scheme in {
            "http",
            "https",
        }:
            self.budget.check(dispatch=True)
            self.budget.requests += 1
            if urlsplit(request.url).path == "/services/oauth2/token":
                self.budget.oauth_requests += 1
        response = super().send(request, **kwargs)
        self.response_metadata = _response_metadata(response)
        if self.budget is not None and self.response_metadata.api_usage:
            self.budget.api_usage = self.response_metadata.api_usage
        return response


def _instance_url(value):
    if not isinstance(value, str):
        raise AuthenticationError("Salesforce instance URL must be an HTTPS origin")
    parsed = urlsplit(value or "")
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.username
        or parsed.password
        or parsed.query
        or parsed.fragment
        or parsed.path not in {"", "/"}
    ):
        raise AuthenticationError("Salesforce instance URL must be an HTTPS origin")
    return value.rstrip("/")


def _cli_result(org, *command):
    try:
        result = subprocess.run(
            ["sf", *command, "--target-org", org, "--json"],
            capture_output=True,
            text=True,
            timeout=60,
            check=False,
        )
        payload = json.loads(result.stdout)
        if (
            not isinstance(payload, dict)
            or result.returncode
            or payload.get("status") != 0
        ):
            raise ValueError
        data = payload["result"]
        if not isinstance(data, dict):
            raise ValueError
        return data
    except (OSError, subprocess.TimeoutExpired, ValueError, KeyError, TypeError):
        raise AuthenticationError(
            "Salesforce CLI authentication failed; check installation and explicit org login"
        ) from None


def cli_credentials(org, *, expected_org_id=None, expected_instance_url=None):
    """Read a refreshed token and org identity without exposing CLI output."""
    if not isinstance(org, str) or not org.strip():
        raise AuthenticationError("An explicit Salesforce CLI org is required")
    auth = _cli_result(org, "org", "auth", "show-access-token")
    info = _cli_result(org, "org", "display")
    token = auth.get("accessToken")
    if not isinstance(token, str) or not token:
        raise AuthenticationError("Salesforce CLI returned no access token")
    instance_url = _instance_url(info.get("instanceUrl"))
    org_id = info.get("id")
    if expected_org_id and (
        not isinstance(org_id, str) or org_id[:15] != expected_org_id[:15]
    ):
        raise AuthenticationError(
            "Selected Salesforce org does not match the expected environment"
        )
    if expected_instance_url and instance_url != _instance_url(expected_instance_url):
        raise AuthenticationError(
            "Selected Salesforce instance does not match the expected environment"
        )
    return token, instance_url


class SalesforceClient:
    """Preserve the existing API and individual query pages through composition."""

    def __init__(
        self,
        api_version=None,
        credentials_path=None,
        auth_method=None,
        *,
        org=None,
        sf=None,
        session=None,
        expected_org_id=None,
        expected_instance_url=None,
        max_read_elapsed_seconds=60.0,
    ):
        version = str(api_version).removeprefix("v")
        if not re.fullmatch(r"\d+\.\d+", version):
            raise ValueError("Invalid Salesforce API version")
        self.api_version = "v" + version
        self.auth_start_time = datetime.now()
        self.auth_method = auth_method
        self.org = org
        self.expected_org_id = expected_org_id
        self.expected_instance_url = expected_instance_url
        self._session = session if session is not None else TimeoutSession()
        if max_read_elapsed_seconds < 0 or not math.isfinite(max_read_elapsed_seconds):
            raise ValueError("max_read_elapsed_seconds must be finite and nonnegative")
        self.max_read_elapsed_seconds = max_read_elapsed_seconds
        self._budget = None
        self.last_run = None
        self._owns_transport = session is None and sf is None
        self._response_metadata = None
        capture_session = (
            session if session is not None else getattr(sf, "session", None)
        )
        self._capture_session = (
            capture_session if isinstance(capture_session, requests.Session) else None
        )
        if self._capture_session is not None and not isinstance(
            self._capture_session, TimeoutSession
        ):
            self._capture_session.hooks["response"].append(self._capture_response)
        self._credentials = None
        self._metadata_connection = None
        self._uses_supplied_metadata = sf is not None
        self.sf = sf
        self.instance_url = None
        self.resources_url = None
        if sf is not None:
            self._bind(sf, sf.base_url.split("/services/data/")[0])
        elif auth_method == "cli":
            if credentials_path is not None:
                raise ValueError("CLI auth does not accept a credentials file")
            self._authenticate_cli()
        elif auth_method == "refresh_token":
            credentials = credentials_path
            if not isinstance(credentials, dict):
                if credentials is None:
                    raise AuthenticationError("Refresh-token credentials are required")
                credentials = json.loads(Path(credentials).read_text())
            self.authenticate_with_refresh_token(**credentials)
        elif auth_method is not None:
            raise ValueError("Select cli or refresh_token authentication")

    def _capture_response(self, response, **kwargs):
        # Public Requests hook: never retain a response object or body.
        self._response_metadata = _response_metadata(response)

    @classmethod
    def from_cli(cls, org, api_version=None, **kwargs):
        return cls(api_version, auth_method="cli", org=org, **kwargs)

    def _bind(self, sf, instance_url):
        self._metadata_connection = None
        self.instance_url = _instance_url(instance_url)
        self.resources_url = f"{self.instance_url}/services/data/{self.api_version}"
        self.sf = sf
        self.auth_start_time = datetime.now()

    def _new_client(self, token, instance_url):
        self._uses_supplied_metadata = False
        self._bind(
            Salesforce(
                session_id=token,
                instance_url=instance_url,
                version=self.api_version.removeprefix("v"),
                session=self._session,
            ),
            instance_url,
        )

    def _authenticate_cli(self):
        token, instance_url = cli_credentials(
            self.org,
            expected_org_id=self.expected_org_id,
            expected_instance_url=self.expected_instance_url,
        )
        self._new_client(token, instance_url)

    def authenticate_with_refresh_token(
        self, instance_url, client_id, client_secret, refresh_token, **kwargs
    ):
        instance_url = _instance_url(instance_url)
        credentials = dict(
            client_id=client_id,
            client_secret=client_secret,
            refresh_token=refresh_token,
        )
        if not all(isinstance(value, str) and value for value in credentials.values()):
            raise AuthenticationError("Incomplete Salesforce refresh-token settings")
        try:
            response = self._session.post(
                instance_url + "/services/oauth2/token",
                data={"grant_type": "refresh_token", **credentials},
                timeout=(10, 60),
            )
            response.raise_for_status()
            data = response.json()
            token = data["access_token"]
            if not isinstance(token, str) or not token:
                raise ValueError
            resolved_url = _instance_url(data["instance_url"])
        except (requests.RequestException, ValueError, KeyError, TypeError):
            raise AuthenticationError(
                "Salesforce refresh-token authentication failed"
            ) from None
        self._credentials = dict(instance_url=instance_url, **credentials)
        self.auth_method = "refresh_token"
        self._new_client(token, resolved_url)

    @property
    def access_token(self):
        return self.sf.session_id

    @property
    def headers(self):
        return self.sf.headers

    @contextmanager
    def run_budget(self, *, max_requests=None, max_elapsed_seconds=None):
        """Own one serial export scope; an outer workflow can bound several exports."""
        if self._budget is not None:
            if max_requests is not None or max_elapsed_seconds is not None:
                raise ValueError("Configure limits on the outer run budget")
            yield self._budget
            return
        budget = RunBudget(max_requests, max_elapsed_seconds)
        if max_requests is not None or max_elapsed_seconds is not None:
            if not self._owns_transport:
                raise ValueError(
                    "Exact budgets require the client's owned HTTP session"
                )
            if any(
                adapter.max_retries.total != 0
                for adapter in self._session.adapters.values()
            ):
                raise ValueError("Budgeted sessions cannot have adapter retries")
        self._budget = budget
        if self._owns_transport:
            self._session.budget = budget
        status = "failed"
        try:
            yield budget
            status = "completed"
        finally:
            self.last_run = budget
            self._budget = None
            if self._owns_transport:
                self._session.budget = None
                self._session.response_metadata = None
            logging.getLogger(__name__).info(
                "Salesforce run %s: attempts=%d oauth=%d retries=%d refreshes=%d elapsed=%.3fs api_usage=%s accounting=%s",
                status,
                budget.requests,
                budget.oauth_requests,
                budget.retries,
                budget.refreshes,
                budget.elapsed,
                budget.api_usage,
                "owned-session"
                if self._owns_transport
                else "unobserved-external-session",
            )

    def _read(self, operation):
        if self.sf is None:
            raise AuthenticationError("Authenticate before making Salesforce requests")
        refreshed = False
        retries = 0
        started = monotonic()
        observed = isinstance(self._session, TimeoutSession) and (
            self._owns_transport or self.sf.session is self._session
        )
        try:
            while True:
                if observed:
                    self._session.response_metadata = None
                self._response_metadata = None
                if self._budget is not None:
                    self._budget.check()
                try:
                    return operation()
                except (SalesforceExpiredSession, Fault) as exc:
                    if refreshed or (
                        isinstance(exc, Fault)
                        and str(exc.code).split(":")[-1] != "INVALID_SESSION_ID"
                    ):
                        raise
                    if self._budget is not None:
                        self._budget.check()
                    if self.auth_method == "cli":
                        self._authenticate_cli()
                    elif self.auth_method == "refresh_token" and self._credentials:
                        self.authenticate_with_refresh_token(**self._credentials)
                    else:
                        raise
                    refreshed = True
                    if self._budget is not None:
                        self._budget.refreshes += 1
                except SalesforceMalformedRequest as exc:
                    errors = exc.content if isinstance(exc.content, list) else []
                    if any(
                        isinstance(item, dict)
                        and item.get("errorCode") == "MALFORMED_QUERY"
                        for item in errors
                    ):
                        raise MalformedQueryError(
                            "Malformed Salesforce query"
                        ) from None
                    raise
                except READ_RETRY_ERRORS as exc:
                    if not is_transient_read_error(exc):
                        raise
                    metadata = (
                        self._session.response_metadata
                        if observed
                        else self._response_metadata
                    )
                    status = getattr(exc, "status", getattr(exc, "status_code", None))
                    if metadata is not None and metadata.status != status:
                        metadata = None
                    advised_wait = (
                        retry_after_seconds(metadata.retry_after) if metadata else None
                    )
                    # The native exception survives; exporters must not issue another read early.
                    exc._salesforce_stop_collection = bool(
                        advised_wait and advised_wait > 0
                    )
                    if retries == len(READ_RETRY_DELAYS):
                        exc.add_note(
                            f"Salesforce read exhausted {retries} transient retries; session refreshed: {refreshed}"
                        )
                        raise
                    delay = uniform(0, READ_RETRY_DELAYS[retries])
                    delay = max(delay, advised_wait or 0.0)
                    if monotonic() - started + delay > self.max_read_elapsed_seconds:
                        exc._salesforce_stop_collection = True
                        exc.add_note(
                            "Salesforce read stopped: retry wait exceeds read allowance"
                        )
                        raise
                    if self._budget is not None:
                        try:
                            self._budget.check(wait=delay, dispatch=True)
                        except RequestBudgetExceeded as budget_error:
                            raise budget_error from exc
                        self._budget.retries += 1
                    retries += 1
                    logging.getLogger(__name__).warning(
                        "Transient Salesforce read failure (%s); retrying in %.3fs (%d/%d)",
                        type(exc).__name__,
                        delay,
                        retries,
                        len(READ_RETRY_DELAYS),
                    )
                    sleep(delay)
        finally:
            if observed:
                self._session.response_metadata = None
            self._response_metadata = None

    def _resource(self, value):
        parsed = urlsplit(value)
        if parsed.fragment or parsed.username or parsed.password:
            raise ValueError("Unsupported Salesforce resource URL")
        if parsed.netloc or parsed.scheme:
            if (parsed.scheme, parsed.netloc) != (
                urlsplit(self.instance_url).scheme,
                urlsplit(self.instance_url).netloc,
            ):
                raise ValueError("Resource URL must use the authenticated instance")
        path = parsed.path
        if path.startswith("/"):
            prefix = f"/services/data/{self.api_version}"
            if path != prefix and not path.startswith(prefix + "/"):
                raise ValueError("Resource URL must use the configured API version")
            path = path[len(prefix) :].lstrip("/")
        if ".." in path.split("/") or "\\" in path:
            raise ValueError("Unsupported Salesforce resource path")
        return path + ("?" + parsed.query if parsed.query else "")

    def get(self, url):
        resource = self._resource(url)
        return self._read(lambda: self.sf.restful(resource))

    def post(self, url, request_body):
        # Writes are never retried automatically.
        return self.sf.restful(self._resource(url), method="POST", json=request_body)

    def get_resource(self, resource_name):
        return self.get(resource_name)

    def list_resources(self):
        """Return the resource dictionary (formerly a requests.Response)."""
        return self.get_resource("")

    def list(self, use_tooling_api=False):
        if use_tooling_api:
            return self._read(lambda: self.sf.toolingexecute("sobjects"))
        return self._read(lambda: self.sf.describe())

    def describe(self, object_name, use_tooling_api=False):
        if not object_name:
            return self.list(use_tooling_api)
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", object_name):
            raise ValueError("Invalid Salesforce object API name")
        if use_tooling_api:
            return self._read(
                lambda: self.sf.toolingexecute(f"sobjects/{object_name}/describe")
            )
        return self._read(lambda: getattr(self.sf, object_name).describe())

    def query(self, soql_stmt, use_tooling_api=False):
        """Return complete, validated pages, including child query results."""
        first = (
            self._read(lambda: self.sf.toolingexecute("query", params={"q": soql_stmt}))
            if use_tooling_api
            else self._read(lambda: self.sf.query(soql_stmt))
        )
        count_only = re.match(r"\s*SELECT\s+COUNT\s*\(\s*\)\s+FROM\b", soql_stmt, re.I)
        context = f"Salesforce {self.api_version} {'Tooling' if use_tooling_api else 'REST'} query"
        return self._query_pages(first, use_tooling_api, context, bool(count_only))

    def _query_pages(self, first, use_tooling_api, context, count_only=False):
        pages, seen = [], set()
        page_counts = []
        expected = None
        page = first
        while True:
            QueryResult.model_validate(
                page, context={"query": context, "expected": expected}
            )
            expected = page["totalSize"]
            page_counts.append(len(page["records"]))
            pages.append(page)
            if page["done"]:
                break
            url = page["nextRecordsUrl"]
            prefix = (
                f"/services/data/{self.api_version}/"
                + ("tooling/" if use_tooling_api else "")
                + "query/"
            )
            if not isinstance(url, str) or not url.startswith(prefix) or url in seen:
                raise ValueError(
                    "Missing, repeated, or unexpected Salesforce continuation"
                )
            self._resource(url)
            seen.add(url)
            page = self._read(lambda: self.sf.query_more(url, identifier_is_url=True))

        if count_only:
            if len(pages) != 1 or page_counts != [0]:
                raise ValueError(f"Malformed COUNT() response for {context}")
        elif sum(page_counts) != expected:
            raise IncompleteQueryError(context, expected, page_counts)
        for index, page in enumerate(pages):
            records = None
            for record_index, record in enumerate(page["records"]):
                completed = self._complete_children(record, use_tooling_api, context)
                if completed is not record:
                    if records is None:
                        records = page["records"].copy()
                    records[record_index] = completed
            if records is not None:
                pages[index] = {**page, "records": records}
        return pages

    def _complete_children(self, record, use_tooling_api, context):
        completed = record
        for key, value in record.items():
            if not isinstance(value, dict) or "records" not in value:
                continue
            if "done" not in value and "totalSize" not in value:
                continue
            identity = record.get("QualifiedApiName", record.get("Id", "record"))
            child_pages = self._query_pages(
                value, use_tooling_api, f"{context}.{identity}.{key}"
            )
            if len(child_pages) == 1 and child_pages[0] is value:
                continue
            child = {
                **value,
                "records": [child for page in child_pages for child in page["records"]],
                "done": True,
            }
            child.pop("nextRecordsUrl", None)
            if completed is record:
                completed = record.copy()
            completed[key] = child
        return completed

    def _soap_connection(self):
        """Bind the SDK's bundled WSDL through public Zeep APIs to our session.

        simple-salesforce 1.12.10 creates a default Zeep transport independently
        of its REST session. Do not mutate its private client/transport fields.
        """
        if self._metadata_connection is None:
            wsdl = Path(simple_salesforce.__file__).with_name("metadata.wsdl")
            soap = ZeepClient(
                wsdl.as_uri(),
                settings=Settings(strict=False, xsd_ignore_sequence_order=True),
                transport=Transport(
                    session=self._session, timeout=10, operation_timeout=60
                ),
            )
            service = soap.create_service(
                "{http://soap.sforce.com/2006/04/metadata}MetadataBinding",
                self.instance_url + "/services/Soap/m/" + self.api_version[1:],
            )
            header = soap.get_element("ns0:SessionHeader")(sessionId=self.sf.session_id)
            self._metadata_connection = soap, service, header
        return self._metadata_connection

    def _metadata_list(self, metadata_type):
        if self._uses_supplied_metadata:
            return self.sf.mdapi.list_metadata([
                self.sf.mdapi.ListMetadataQuery(type=metadata_type)
            ])
        soap, service, header = self._soap_connection()
        query = soap.get_type("ns0:ListMetadataQuery")(type=metadata_type)
        return service.listMetadata(
            [query], self.api_version[1:], _soapheaders=[header]
        )

    def _metadata_read(self, metadata_type, names):
        if self._uses_supplied_metadata:
            return getattr(self.sf.mdapi, metadata_type).read(names)
        soap, service, header = self._soap_connection()
        native_type = MetadataType(
            metadata_type, service, soap.get_type("ns0:" + metadata_type), header
        )
        return native_type.read(names)

    def list_metadata_api_contents(self, metadata_type, as_of_version=None):
        if (
            as_of_version
            and str(as_of_version).removeprefix("v") != self.api_version[1:]
        ):
            raise ValueError("Metadata listing must use the configured API version")
        return self._read(
            lambda: serialize_object(
                self._metadata_list(metadata_type), target_cls=dict
            )
        )

    def read_metadata(self, metadata_type, full_names) -> list[dict]:
        """Read one explicit metadata type in batches of at most ten names.

        Null/omitted components remain absent; unexpected or duplicate identities fail.
        No Tooling fallback, filesystem writes, or implicit full discovery.
        """
        if not isinstance(metadata_type, str) or not re.fullmatch(
            r"[A-Za-z][A-Za-z0-9]*", metadata_type
        ):
            raise ValueError("Invalid Metadata API type")
        if isinstance(full_names, str):
            raise ValueError("full_names must be a selection, not a string")
        names = list(full_names)
        if any(
            not isinstance(name, str) or not name or "*" in name for name in names
        ) or len(set(names)) != len(names):
            raise ValueError("Metadata selection requires distinct explicit full names")
        records = []
        for start in range(0, len(names), 10):
            batch = names[start : start + 10]
            payload = self._read(
                lambda: serialize_object(
                    self._metadata_read(metadata_type, batch), target_cls=dict
                )
            )
            values = payload if isinstance(payload, list) else [payload]
            returned = set()
            selected = {}
            for record in values:
                if (
                    record is None
                    or isinstance(record, dict)
                    and record.get("fullName") is None
                ):
                    continue
                if not isinstance(record, dict) or record.get("fullName") not in batch:
                    raise ValueError("Unexpected Metadata API component identity")
                name = record["fullName"]
                if name in returned:
                    raise ValueError("Repeated Metadata API component identity")
                returned.add(name)
                selected[name] = record
            records.extend(selected[name] for name in batch if name in selected)
        return records


def checkpoint_scope(client: SalesforceClient, template: str) -> CheckpointScope:
    resources = client.list_resources()
    identity = resources.get("identity")
    if not isinstance(identity, str):
        raise ValueError("Missing authenticated Salesforce identity")
    parsed = urlsplit(identity)
    match = re.fullmatch(
        r"/id/(00D[A-Za-z0-9]{12}(?:[A-Za-z0-9]{3})?)/"
        r"(005[A-Za-z0-9]{12}(?:[A-Za-z0-9]{3})?)",
        parsed.path,
    )
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.username
        or parsed.password
        or parsed.query
        or parsed.fragment
        or match is None
    ):
        raise ValueError("Invalid authenticated Salesforce identity")
    org_id, user_id = (value[:15] for value in match.groups())
    records = query_records(
        client.query(soql_templates.rest.by_entity.User.context.strip().format(id=user_id)),
        "checkpoint user context",
    )
    returned_id = records[0].get("Id") if len(records) == 1 else None
    if not isinstance(returned_id, str) or returned_id[:15] != user_id:
        raise ValueError("Unexpected authenticated Salesforce user")
    return CheckpointScope(
        instance_url=client.instance_url,
        org_id=org_id,
        user_id=user_id,
        language=records[0].get("LanguageLocaleKey"),
        locale=records[0].get("LocaleSidKey"),
        api_version=client.api_version,
        template_hash=sha256(template.encode("utf-8")).hexdigest(),
    )


if __name__ == "__main__":
    import argparse
    from salesforce.settings import Settings

    parser = argparse.ArgumentParser()
    parser.add_argument("--environment", required=True)
    settings = Settings.load(parser.parse_args().environment)
    cli_credentials(
        settings.org,
        expected_org_id=settings.expected_org_id,
        expected_instance_url=settings.expected_instance_url,
    )
