"""Pydantic type aliases for Salesforce primitive & field types.

Per request: this module purposefully excludes any mapping helper functions
or enums. Instead it exposes Pydantic (v2) Annotated type aliases and light
supporting models carrying commonly useful metadata (patterns, lengths,
descriptions, value constraints) derived from Salesforce documentation.

References:
  * Primitive data types:
    https://developer.salesforce.com/docs/atlas.en-us.object_reference.meta/object_reference/primitive_data_types.htm
  * Field types:
    https://developer.salesforce.com/docs/atlas.en-us.object_reference.meta/object_reference/field_types.htm

These definitions are intentionally conservative: they capture well-known
invariants (e.g. Id length / pattern, latitude range) while avoiding business
rules that vary per-org (e.g. picklist allowed values, precision/scale). Extend
locally as needed (e.g. wrap a picklist alias with a Literal of choices.
"""

from __future__ import annotations

from datetime import date, datetime, time
from decimal import Decimal
from typing import Any, Annotated, List, Optional

from pydantic import BaseModel, Field
from pydantic import EmailStr, AnyUrl

__all__ = [
    # Primitive aliases
    "AnyType",
    "Base64",
    "Boolean",
    "Date",
    "DateTime",
    "Double",
    "Id",
    "Int",
    "Long",
    "String",
    "Time",
    # Field type (specializations / composites)
    "Address",
    "Location",
    "Currency",
    "Percent",
    "Email",
    "EncryptedString",
    "Phone",
    "URL",
    "Picklist",
    "MultiPicklist",
    "ReferenceId",
    "JunctionIdList",
    "TextArea",
    "ComboBox",
    "ComplexValue",
]


# ---------------------------------------------------------------------------
# Primitive type aliases
# ---------------------------------------------------------------------------

AnyType = Annotated[
    Any,
    Field(description="Salesforce anyType (polymorphic / dynamic value)."),
]

Base64 = Annotated[
    bytes, Field(description="Base64-encoded binary content (Attachment, etc.)")
]

Boolean = Annotated[bool, Field(description="Boolean (true/false)")]

Date = Annotated[date, Field(description="Date value (no time component)")]

DateTime = Annotated[
    datetime,
    Field(
        description="DateTime (ISO8601). Salesforce stores in UTC; rendered in user TZ.",
    ),
]

Double = Annotated[
    float,
    Field(description="Double precision floating point (up to 15 digits of precision)."),
]

Id = Annotated[
    str,
    Field(
        description="Salesforce record Id (15- or 18-char case-safe).",
        min_length=15,
        max_length=18,
        pattern=r"^[a-zA-Z0-9]{15}(?:[a-zA-Z0-9]{3})?$",
        examples=["0015g00000ABCDeAAH"],
    ),
]

ReferenceId = Annotated[
    str,
    Field(
        description="Id value used in a reference (same constraints as Id).",
        min_length=15,
        max_length=18,
        pattern=r"^[a-zA-Z0-9]{15}(?:[a-zA-Z0-9]{3})?$",
    ),
]

Int = Annotated[int, Field(description="32-bit integer")]
Long = Annotated[int, Field(description="64-bit integer")]

String = Annotated[str, Field(description="Arbitrary UTF-8 string value")]

Time = Annotated[
    time,
    Field(description="Time-only value (HH:MM:SS.mmm). Represents time of day."),
]


# ---------------------------------------------------------------------------
# Composite / specialized field models
# ---------------------------------------------------------------------------

class Location(BaseModel):
    """Geolocation field value.

    Latitude and longitude are optional in the platform (one may be null).
    Range constraints reflect documented valid ranges.
    """

    latitude: Optional[float] = Field(
        default=None, ge=-90, le=90, description="Latitude in decimal degrees (-90..90)."
    )
    longitude: Optional[float] = Field(
        default=None,
        ge=-180,
        le=180,
        description="Longitude in decimal degrees (-180..180).",
    )


class Address(BaseModel):
    """Compound address representation (read-only composite in most APIs)."""

    street: Optional[str] = Field(default=None, max_length=255)
    city: Optional[str] = Field(default=None, max_length=80)
    state: Optional[str] = Field(default=None, max_length=80, description="State/Province")
    postal_code: Optional[str] = Field(
        default=None, alias="postalCode", max_length=20, description="ZIP/Postal Code"
    )
    country: Optional[str] = Field(default=None, max_length=80)
    latitude: Optional[float] = Field(default=None, ge=-90, le=90)
    longitude: Optional[float] = Field(default=None, ge=-180, le=180)



# Currency and Percent as specialized numeric aliases
Currency = Annotated[
    Decimal,
    Field(
        description="Currency value (precision & scale defined per field metadata).",
        examples=["123.45"],
    ),
]

Percent = Annotated[
    float,
    Field(
        description="Percent value stored as decimal (e.g. 0.15 == 15%). Precision varies.",
    ),
]

Email = Annotated[EmailStr, Field(description="RFC 5322 email address")]

EncryptedString = Annotated[
    str,
    Field(
        description="Encrypted string (returned masked unless user has View Encrypted Data)."
    ),
]

Phone = Annotated[
    str,
    Field(
        description="Phone number (no enforced pattern; normalize externally).",
        max_length=40,
    ),
]

URL = Annotated[AnyUrl, Field(description="URL (HTTP/HTTPS/other schemes allowed)")]

Picklist = Annotated[
    str,
    Field(
        description="Picklist selected value. Allowed choices supplied separately in field metadata.",
    ),
]

MultiPicklist = Annotated[
    List[str],
    Field(
        description="Multi-select picklist values (API often returns semicolon-delimited string).",
    ),
]

JunctionIdList = Annotated[
    List[ReferenceId],
    Field(
        description="List of parent/related record Ids on a junction object (reference ids).",
    ),
]

TextArea = Annotated[
    str,
    Field(
        description="Text area / long text / rich text (rich text contains HTML markup).",
    ),
]

ComboBox = Annotated[
    str,
    Field(
        description="ComboBox value (either picklist choice or arbitrary user-entered string).",
    ),
]

ComplexValue = Annotated[
    dict,
    Field(
        description="Generic complex value container (e.g. sub-structure in describe metadata).",
    ),
]


