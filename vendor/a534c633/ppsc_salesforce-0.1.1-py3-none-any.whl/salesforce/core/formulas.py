"""Extract native reference occurrences without resolving or renaming them.

Offsets are zero-based, end-exclusive positions in the original expression.
This is a lexical scanner, not a formula validator or evaluator.
"""

from dataclasses import dataclass
import re
from typing import Iterator


@dataclass(frozen=True)
class FormulaReferenceOccurrence:
    """One unchanged reference and its zero-based, end-exclusive source span."""

    text: str
    start: int
    end: int


_IDENTIFIER = re.compile(r"[A-Za-z_$][A-Za-z0-9_$]*(?:\.[A-Za-z_$][A-Za-z0-9_$]*)*")
_NUMBER = re.compile(r"(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?")
_PATH_TAIL = re.compile(r"(?:\s*\[[^\]]*\]|\s*\.+\s*[A-Za-z_$][A-Za-z0-9_$]*)+")
_TRIVIA = re.compile(r"(?:\s+|/\*.*?\*/|//[^\r\n]*(?:\r?\n|$))*", re.DOTALL)
_KEYWORDS = {"TRUE", "FALSE", "NULL", "AND", "OR", "NOT"}


def _scan(text):
    references, unparsed = [], []
    position = 0
    while position < len(text):
        start = position
        char = text[position]
        if char.isspace():
            position += 1
        elif text.startswith("//", position):
            end = text.find("\n", position + 2)
            position = len(text) if end < 0 else end
        elif text.startswith("/*", position):
            end = text.find("*/", position + 2)
            position = len(text) if end < 0 else end + 2
            if end < 0:
                unparsed.append(dict(text=text[start:], start=start, end=position))
        elif char in "\"'":
            position += 1
            closed = False
            while position < len(text):
                if text[position] == "\\":
                    position = min(position + 2, len(text))
                elif text[position] == char:
                    position += 1
                    if position < len(text) and text[position] == char:
                        position += 1
                    else:
                        closed = True
                        break
                else:
                    position += 1
            if not closed:
                unparsed.append(dict(text=text[start:], start=start, end=position))
        elif text.startswith("{!", position):
            end = text.find("}", position + 2)
            position = len(text) if end < 0 else end + 1
            value = text[start + 2 : end] if end >= 0 else text[start:]
            if end >= 0 and _IDENTIFIER.fullmatch(value):
                references.append(dict(text=value, start=start + 2, end=end))
            else:
                unparsed.append(
                    dict(text=text[start:position], start=start, end=position)
                )
        elif match := _NUMBER.match(text, position):
            position = match.end()
        elif match := _IDENTIFIER.match(text, position):
            position = match.end()
            # Keep indexed/damaged paths intact instead of extracting guessed parts.
            following = position
            while following < len(text) and text[following].isspace():
                following += 1
            if following < len(text) and text[following] in "[.":
                tail = _PATH_TAIL.match(text, position)
                position = (
                    tail.end()
                    if tail
                    else len(text)
                    if text[following] == "["
                    else following + 1
                )
                unparsed.append(
                    dict(text=text[start:position], start=start, end=position)
                )
                continue
            value = match.group()
            next_token = _TRIVIA.match(text, position).end()
            if value.upper() not in _KEYWORDS and not text.startswith("(", next_token):
                references.append(dict(text=value, start=start, end=position))
        elif char in "()+-*/^&=<>!,:%?":
            position += 1
        else:
            position += 1
            unparsed.append(dict(text=char, start=start, end=position))
    return references, unparsed


def formula_reference_occurrences(text: str) -> Iterator[FormulaReferenceOccurrence]:
    """Yield references without strings, comments, function names or name repair."""
    for occurrence in _scan(text)[0]:
        yield FormulaReferenceOccurrence(**occurrence)


def formula_references(text: str) -> dict:
    """Return compatibility reference rows and explicitly unparsed occurrences."""
    references, unparsed = _scan(text)
    return {
        "references": [
            dict(reference=item["text"], start=item["start"], end=item["end"])
            for item in references
        ],
        "unparsed": unparsed,
    }
