
from typing import Optional,Literal

from pydantic import BaseModel, computed_field

from salesforce.client import QueryResult, InsufficientAccessErrorResponse

class Metadata(BaseModel,use_enum_values=True):
    """ Base class for all metadata types. """

    @computed_field
    @property
    def node_hierarchy(self) -> str:
        node_inheritance = []
        for c in self.__class__.__mro__:
            node_inheritance.append(c.__name__)

        return ".".join(list(reversed(node_inheritance))[2:])
    
    @computed_field
    @property  
    def node_kind(self) -> str:
        return self.__class__.__name__

    def add_node(self, graph,name=None) -> dict:
        """ Add node and then return the added node attached to the graph"""

        if name:
            nodename = name
        elif hasattr(self,"name"):
            nodename = self.name
        else:
            raise ValueError("Cannot add node without a name property in the object or a 'name' attribute passed to add_node()")

        graph.add_node(nodename,attrs=self.model_dump(exclude_none=True))
        return graph.nodes[nodename]
    
    def attach_parent_node(
        self,
        graph,
        parent: str,
        relation: str,
        key_suffix: str | None = None,
    ) -> None:
        """ Add edge from parent to self in the graph. """

        if hasattr(self,"name"):
            child = self.name
        else:
            raise ValueError("Cannot add edge without a name property in the object")

        
        if key_suffix:
            edge_key = f"{child}.{key_suffix}"
        else:
            edge_key = f"{child}.{relation}"
            
        graph.add_edge(parent, child, key=edge_key, relation=relation)
    
# Entity to avoid confusion with Metadata API
Entity = Metadata
