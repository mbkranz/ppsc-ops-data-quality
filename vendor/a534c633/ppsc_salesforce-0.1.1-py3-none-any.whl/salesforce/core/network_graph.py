# Ported from ppsc-pmd-utils at 365422a837716fc17b1ad197369569957ecaeb87.
import networkx as nx

def list_dag_node_order(graph: nx.MultiDiGraph|nx.DiGraph, source: str) -> list[str]:
    return list(nx.dfs_preorder_nodes(graph, source=source))

def list_dag_node_inputs(graph: nx.MultiDiGraph|nx.DiGraph, source: str) -> nx.MultiDiGraph:
    """Annotate the graph traversal order based on the 'run_order' attribute.

    Related that may be good for future
    list(nx.dag.root_to_leaf_paths(graph)) --> gets all paths from root to leaf.


    """
    inputs = {}
    for node in list_dag_node_order(graph, source):
        inputs[node] = list(graph.predecessors(node))
    return inputs
