"""Source evidence on native SQLGlot nodes, with readable SQL comments."""

from __future__ import annotations

import json
from copy import deepcopy
from typing import Any, TypeVar

from pydantic_core import to_jsonable_python
from sqlglot import exp

Expression = TypeVar("Expression", bound=exp.Expression)


def source_metadata(native: Any, *, source: dict | None = None, **facts) -> dict:
    """Copy JSON-safe native evidence without changing false, zero or NULL."""
    payload = {**(source or {}), **facts, "native": native}
    return json.loads(json.dumps(to_jsonable_python(payload), allow_nan=False))


def annotate(expression: Expression, metadata: dict) -> Expression:
    """Attach structured evidence and a safe summary; computation stays native."""
    expression.meta["ppsc"] = deepcopy(metadata)
    summary = str(metadata.get("description") or "Salesforce source evidence")
    for label, key in (("source", "source_entities"), ("pointer", "source_paths")):
        values = metadata.get(key) or []
        if values:
            summary += "; " + label + ": " + ", ".join(map(str, values))
    # Comment text is documentation, never SQL or SQLGlot metadata directives.
    summary = " ".join(summary.split())
    summary = summary.replace("/*", "/ *").replace("*/", "* /")
    summary = summary.replace("sqlglot.meta", "sqlglot_meta")
    summary = "".join(char for char in summary if char.isprintable())
    if summary not in (expression.comments or []):
        expression.add_comments([summary])
    return expression
