"""Salesforce entities: acquisition, models, transforms, and exports by sObject."""
