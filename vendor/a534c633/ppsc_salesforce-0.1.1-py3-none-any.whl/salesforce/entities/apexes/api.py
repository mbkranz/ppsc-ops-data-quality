from salesforce import soql_templates


def apexpage(client):
    return client.query(soql_templates.tooling.by_entity.ApexPage.all, use_tooling_api=True)


def apexclass(client):
    return client.query(soql_templates.rest.by_entity.ApexClass.all, use_tooling_api=False)
