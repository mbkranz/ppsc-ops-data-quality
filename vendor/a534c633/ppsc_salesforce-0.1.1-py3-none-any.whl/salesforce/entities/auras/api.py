from salesforce import soql_templates
from salesforce.client import query_records


def export_aura_definition_metadata_from_tooling_query(salesforce_client):
    # Combined response structure
    aura_def_resource = soql_templates.tooling.by_entity.AuraDefinition.all
    aura_def_response = salesforce_client.query(aura_def_resource, use_tooling_api=True)
    return aura_def_response


def export_aura_bundle_metadata_from_tooling_query(salesforce_client):
    # Combined response structure

    __objectname__ = "AuraDefinitionBundle"

    ids = soql_templates.tooling.by_entity.AuraDefinitionBundle.inventory

    metadata = soql_templates.tooling.by_entity.AuraDefinitionBundle.metadata

    idlist = [rec for rec in salesforce_client.query(ids, use_tooling_api=True)]

    records = []
    for id in query_records(idlist, "component inventory"):
        print(f"Exporting {__objectname__}.{id['DeveloperName']}")
        object_tooling_query_response = salesforce_client.query(
            metadata.format(id=id["Id"]), use_tooling_api=True
        )
        records.extend(object_tooling_query_response)

    return records
