"""Native Salesforce field definitions, lineage, and rollup queries."""

from importlib import import_module


__all__ = ["api", "models", "schemas"]


def __getattr__(name):
    if name in __all__:
        return import_module(f"{__name__}.{name}")
    raise AttributeError(name)
