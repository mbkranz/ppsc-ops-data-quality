import json
from pathlib import Path

import pandas as pd

from salesforce import soql_templates

__all__ = ["field_definition", "entity_particle", "field_definition_metadata"]


field_tooling_query_template = soql_templates.tooling.by_entity.FieldDefinition.by_entity
entity_particle_tooling_query_template = (
    soql_templates.tooling.by_entity.EntityParticle.by_entity
)


def describe_field_definition(salesforce_client):
    """
    Export the field metadata from the tooling API from the describe endpoint.

    This function returns the available fields in the tooling API (NOT fields within the CRM data model)
    """
    field_tooling_describe_url = (
        salesforce_client.resources_url + "/tooling/sobjects/FieldDefinition/describe"
    )
    field_tooling_describe = salesforce_client.get(field_tooling_describe_url)
    return field_tooling_describe


def describe_entity_particle(salesforce_client):
    """
    Export the entity particle metadata from the tooling API from the describe endpoint.

    This function returns the available entity particles in the tooling API (NOT fields within the CRM data model)
    """
    entity_particle_tooling_describe_url = (
        salesforce_client.resources_url + "/tooling/sobjects/EntityParticle/describe"
    )
    entity_particle_tooling_describe = salesforce_client.get(
        entity_particle_tooling_describe_url
    )
    return entity_particle_tooling_describe


def field_definition(
    salesforce_client,
    object_qualified_api_names: list[str],
    output_path: Path | str = None,
):
    sobject_describe = {}
    tooling_field_query_responses = {}
    output_sobject_path = Path(output_path).joinpath("sobjects")
    output_tooling_field_query_path = Path(output_path).joinpath(
        "tooling/query/field_definition"
    )

    output_sobject_path.mkdir(parents=True, exist_ok=True)
    output_tooling_field_query_path.mkdir(parents=True, exist_ok=True)

    for name in object_qualified_api_names:
        try:
            tooling_field_query_response = salesforce_client.query(
                field_tooling_query_template.format(object_name=name),
                use_tooling_api=True,
            )
        except Exception as e:
            print(str(e))
            tooling_field_query_response = None

        try:
            description = salesforce_client.describe(name, use_tooling_api=False)
        except Exception as e:
            print(str(e))
            description = None

        if output_path:
            output_sobject_path.joinpath(name).mkdir(parents=True, exist_ok=True)
            output_sobject_path.joinpath(f"{name}/describe.json").write_text(
                json.dumps(description)
            )
            output_tooling_field_query_path.joinpath(f"{name}.json").write_text(
                json.dumps(tooling_field_query_response)
            )
        sobject_describe[name] = description
        tooling_field_query_responses[name] = tooling_field_query_response
        print("Done exporting object: ", name)
        # TODO: CustomField and CustomObject?
        # for field in field_definition_query["records"]:
        #     field_url = field["attributes"]["url"]
        #     field_metadata = client2.get(field_url)
    return sobject_describe, tooling_field_query_responses


def entity_particle(
    salesforce_client,
    object_qualified_api_names: list[str],
    output_path: Path | str = None,
):

    tooling_entity_particle = {}
    output_tooling_entity_particle_path = Path(output_path).joinpath(
        "tooling/query/entity_particle"
    )
    output_tooling_entity_particle_path.mkdir(parents=True, exist_ok=True)
    entity_particle_properties = describe_entity_particle(salesforce_client)
    entity_particle_property_list = pd.DataFrame(entity_particle_properties["fields"])[
        "name"
    ].tolist()
    entity_particle_property_list += [
        "EntityDefinition.QualifiedApiName",
        "EntityDefinition.KeyPrefix",
        "FieldDefinition.QualifiedApiName",
        "FieldDefinition.DurableId",
    ]
    for name in object_qualified_api_names:
        try:
            query_response = salesforce_client.query(
                entity_particle_tooling_query_template.format(
                    select_properties=",".join(entity_particle_property_list),
                    object_name=name,
                ),
                use_tooling_api=True,
            )
        except Exception as e:
            print(str(e))
            query_response = None

        if output_path:
            output_tooling_entity_particle_path.joinpath(f"{name}.json").write_text(
                json.dumps(query_response)
            )
        tooling_entity_particle[name] = query_response
        print("Done exporting object: ", name)
        # TODO: CustomField and CustomObject?
        # for field in field_definition_query["records"]:
        #     field_url = field["attributes"]["url"]
        #     field_metadata = client2.get(field_url)
    return tooling_entity_particle


def field_definition_metadata(salesforce_client, durableid=None, fullname=None):
    if fullname:
        objectname, fieldname = fullname.split(".", 1)
        custom_fields = (
            soql_templates.tooling.by_entity.FieldDefinition.metadata_by_name.format(
                object_name=objectname, field_name=fieldname
            )
        )

    elif durableid:
        custom_fields = (
            soql_templates.tooling.by_entity.FieldDefinition.metadata_by_id.format(
                id=durableid
            )
        )
    else:
        raise ValueError("Either fullname+fieldname or durableid must be provided")

    response = salesforce_client.query(custom_fields, use_tooling_api=True)
    return response
