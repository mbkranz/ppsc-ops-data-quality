from __future__ import annotations
from typing import Literal
from enum import Enum
import networkx as nx
from pydantic import AliasGenerator, ConfigDict, Field, model_validator, field_validator

from salesforce.core.models import Metadata
from salesforce.entities.field_definitions.lineage import (
    rollup_expression,
    rollup_references,
)

__all__ = ["CustomField", "SummaryCustomField"]


def _sanitize_identifier(value: str | None, default: str) -> str:
    if not value:
        return default
    return value.replace(" ", "_")


def _qualify_field_name(field_name: str, object_name: str | None) -> str:
    if "." in field_name:
        return field_name
    if object_name:
        return f"{object_name}.{field_name}"
    return field_name


class FieldType(str, Enum):
    AUTO_NUMBER = "AutoNumber"
    CHECKBOX = "Checkbox"
    CURRENCY = "Currency"
    DATE = "Date"
    DATE_TIME = "DateTime"
    EMAIL = "Email"
    ENCRYPTED_TEXT = "EncryptedText"
    EXTERNAL_LOOKUP = "ExternalLookup"
    GEOLOCATION = "Location"
    HIERARCHICAL_RELATIONSHIP = "HierarchicalRelationship"
    INDIRECT_LOOKUP = "IndirectLookup"
    LOOKUP = "Lookup"
    MASTER_DETAIL = "MasterDetail"
    METADATA_RELATIONSHIP = "MetadataRelationship"
    MULTIPICKLIST = "MultiselectPicklist"
    NUMBER = "Number"
    PERCENT = "Percent"
    PHONE = "Phone"
    PICKLIST = "Picklist"
    SUMMARY = "Summary"
    TEXT = "Text"
    TEXT_AREA = "TextArea"
    LONG_TEXT_AREA = "LongTextArea"
    RICH_TEXT_AREA = "RichTextArea"
    URL = "Url"
    FORMULA = "Formula"
    TIME = "Time"
    PAGE_LAYOUT = "PageLayout"


class SummaryOperation(str, Enum):
    COUNT = "count"
    SUM = "sum"
    MIN = "min"
    MAX = "max"
    AVG = "avg"


class FilterOperation(str, Enum):
    EQUALS = "equals"
    NOT_EQUAL = "notEqual"
    LESS_THAN = "lessThan"
    GREATER_THAN = "greaterThan"
    LESS_OR_EQUAL = "lessOrEqual"
    GREATER_OR_EQUAL = "greaterOrEqual"
    CONTAINS = "contains"
    NOT_CONTAIN = "notContain"
    STARTS_WITH = "startsWith"
    INCLUDES = "includes"
    EXCLUDES = "excludes"
    WITHIN = "within"


class DeleteConstraint(str, Enum):
    CASCADE = "Cascade"
    RESTRICT = "Restrict"
    SET_NULL = "SetNull"


class FormulaTreatBlanksAs(str, Enum):
    BLANK_AS_ZERO = "BlankAsZero"
    BLANK_AS_BLANK = "BlankAsBlank"


class EncryptedFieldMaskType(str, Enum):
    ALL = "all"
    CREDIT_CARD = "creditCard"
    LAST_FOUR = "lastFour"
    NINE_DIGITS = "nineDigits"
    SIN = "sin"
    SSN = "ssn"


class EncryptedFieldMaskChar(str, Enum):
    ASTERISK = "asterisk"
    X = "X"


class CustomValue(Metadata):
    fullName: str
    default: bool | None = Field(
        default=None, description="Marks the value as the default picklist option."
    )
    description: str | None = None
    isActive: bool | None = Field(
        default=None, description="Indicates whether the picklist value is active."
    )
    label: str | None = None
    color: str | None = Field(
        default=None, description="Hex color code used for the value in UI components."
    )

    def add_to_graph(self, graph: nx.MultiDiGraph, parent_node: str, index: int) -> str:
        # identifier = _sanitize_identifier(self.fullName, f"index{index}")
        # node_name = f"{parent_node}.values[{identifier}]"
        # self.add_node(graph, node_name)
        # self.attach_parent_node(graph, parent_node,"enumerates_value")
        # return node_name
        raise NotImplementedError(
            "CustomValue graph addition is currently defined as a separate node in order to simplify. Only the ValueSet is defined as a node if global."
        )


class ValueSetDefinition(Metadata):
    sorted: bool | None = Field(
        default=None,
        description="Indicates if picklist values are sorted alphabetically.",
    )
    value: list[CustomValue] = Field(
        default_factory=list, description="Picklist values defined inline on the field."
    )

    def add_to_graph(self, graph: nx.MultiDiGraph, parent_node: str) -> str:
        # node_name = f"{parent_node}.definition"
        # self.add_node(graph, node_name)
        # self.attach_parent_node(graph, parent_node, node_name, "defines_value_set")
        # for index, picklist_value in enumerate(self.value):
        #     picklist_value.add_to_graph(graph, node_name, index)
        # return node_name
        raise NotImplementedError(
            "ValueSetDefinition graph addition is currently not defined as a separate node in order to simplify. Only the ValueSet is defined as a node if global."
        )


class ValueSetting(Metadata):
    controllingFieldValue: list[str] = Field(
        default_factory=list,
        description="List of controlling field values that make this dependent value available.",
    )
    valueName: str

    def add_to_graph(self, graph: nx.MultiDiGraph, parent_node: str, index: int) -> str:
        # identifier = _sanitize_identifier(self.valueName, f"index{index}")
        # node_name = f"{parent_node}.settings[{identifier}]"
        # self.add_node(graph, node_name)
        # self.attach_parent_node(graph, parent_node, "defines_dependent_value")
        # return node_name
        raise NotImplementedError("ValueSetting is property of field.")


class ValueSet(Metadata):
    controllingField: str | None = None
    restricted: bool | None = Field(
        default=None,
        description="If true, only defined values can be assigned without validation errors.",
    )
    valueSetDefinition: ValueSetDefinition | None = None
    valueSetName: str | None = Field(
        default=None,
        description="API name of the global value set to reference instead of inline values.",
    )
    valueSettings: list[ValueSetting] = Field(
        default_factory=list,
        description="Dependent picklist value bindings for controlling values.",
    )


class FilterItem(Metadata):
    field: str | None = Field(
        default=None,
        description="Qualified API name of the field referenced in the filter expression.",
    )
    operation: FilterOperation
    value: str | int | float | bool | None = None
    valueField: str | None = Field(
        default=None,
        description="Field reference used as the right-hand operand of the filter.",
    )
    valueSetName: str | None = None
    valueType: str | None = None

    @model_validator(mode="after")
    def ensure_value_source(self) -> "FilterItem":
        if self.value is None and self.valueField is None and self.valueSetName is None:
            raise ValueError(
                "FilterItem requires value, valueField, or valueSetName to be provided."
            )
        return self


class LookupFilter(Metadata):
    """Defines a lookup filter for a lookup field in Salesforce.


    NOTE: It looks to be very similar structure to the RecordLookupFilter within FlowRecordLookup but with slightly different
    naming conventions.

    """

    active: bool | None = Field(
        default=None, description="Controls whether the filter is enforced."
    )
    booleanFilter: str | None = Field(
        default=None,
        description="Boolean logic string that combines filter items (e.g., '1 AND (2 OR 3)').",
    )
    description: str | None = None
    errorMessage: str | None = Field(
        default=None, description="Message shown when the filter blocks a selection."
    )
    filterItems: list[FilterItem] = Field(default_factory=list)
    infoMessage: str | None = Field(
        default=None, description="Informational message displayed to users."
    )
    isOptional: bool | None = Field(
        default=None,
        description="When true, users can ignore the filter warning and proceed.",
    )


# extra="ignore",
# populate_by_name=True,
class CustomField(Metadata):
    name: str = Field(
        None,
        description="API {object}.{field} name of the custom field for used as a node in APMP graph.",
    )
    fullName: str
    label: str | None = None
    type: FieldType
    description: str | None = None
    inlineHelpText: str | None = None
    required: bool | None = None
    unique: bool | None = None
    externalId: bool | None = None
    caseSensitive: bool | None = None
    length: int | None = None
    precision: int | None = None
    scale: int | None = None
    defaultValue: str | bool | int | float | None = None
    defaultValueFormula: str | None = Field(
        default=None, description="Formula used to derive the default value."
    )
    trackHistory: bool | None = None
    trackTrending: bool | None = None
    trackFeedHistory: bool | None = None
    summarizedField: str | None = None
    summaryFilterItems: list[FilterItem] = Field(default_factory=list)
    summaryForeignKey: str | None = None
    summaryOperation: SummaryOperation | None = None
    valueSet: ValueSet | None = None
    lookupFilter: LookupFilter | None = None
    metadataRelationshipControllingField: str | None = None
    populateExistingRows: bool | None = None
    referenceTargetField: str | None = None
    referenceTo: list[str] | None = Field(
        default=None, description="Target sObjects for lookup fields."
    )
    relationshipLabel: str | None = None
    relationshipName: str | None = None
    relationshipOrder: int | None = None
    deleteConstraint: DeleteConstraint | None = None
    reparentableMasterDetail: bool | None = None
    writeRequiresMasterRead: bool | None = None
    displayFormat: str | None = None
    displayLocationInDecimal: bool | None = None
    visibleLines: int | None = None
    formula: str | None = None
    formulaTreatBlanksAs: FormulaTreatBlanksAs | None = None
    maskChar: EncryptedFieldMaskChar | None = None
    maskType: EncryptedFieldMaskType | None = None

    model_config = ConfigDict(
        alias_generator=AliasGenerator(
            validation_alias=lambda v: "FieldDefinition.Metadata." + v
        ),
        extra="ignore",
        use_enum_values=True,
    )

    @field_validator("lookupFilter", mode="before")
    @classmethod
    def lookup_filter_not_implemented(cls, v):
        if v:
            raise NotImplementedError(
                "LookupFilter not implemented. Putting here to not forget."
            )

    def add_to_graph(self, graph: nx.MultiDiGraph) -> str:
        raise NotImplementedError(
            "CustomField graph addition add_to_graph must be implemented in specialized subclasses."
        )


class SummaryCustomField(CustomField):
    type: Literal["Summary"]

    """ Specialized CustomField for Summary Fields. """

    def add_to_graph(self, graph: nx.MultiDiGraph) -> nx.MultiDiGraph:

        node_name = self.name or self.fullName
        self.add_node(graph, node_name)
        object_name = node_name.split(".", 1)[0]
        self.attach_parent_node(graph, object_name, "field_defined_on_sobject")

        for reference, role, path in rollup_references(self.model_dump()):
            if role == "summarizes_field":
                graph.add_edge(
                    node_name,
                    reference,
                    key=f"{node_name}.summarizedField",
                    relation="summarizes_field",
                )
            elif role == "rollup_relationship":
                graph.add_edge(
                    node_name,
                    reference,
                    key=f"{node_name}.summaryForeignKey",
                    relation="summarizes_via_foreign_key",
                )
            else:
                index = path.split("/")[2]
                graph.add_edge(
                    reference,
                    node_name,
                    key=f"{node_name}.summaryFilterItem[{index}]."
                    + path.rsplit("/", 1)[-1],
                    relation="field_referenced_by_filter",
                )

        expression = rollup_expression(self.model_dump(), node_name)
        graph.nodes[node_name]["expression"] = expression
        if expression is None:
            graph.nodes[node_name].update(
                translation_status="unsupported",
                reason="Roll-up operation or native filter operands have no supported display SQL",
            )

        return graph


class CustomPicklistField(CustomField):
    """Specialized CustomField for Picklist Fields."""

    type: Literal["Picklist", "MultiselectPicklist"]
    valueSet: ValueSet

    @model_validator(mode="before")
    def multiple_value_set_definitions(cls, data):
        if data.get("valueSet", {}).get("ValueSetDefinition") and data.get(
            "valueSet", {}
        ).get("valueSetName"):
            raise ValueError(
                "ValueSet cannot have both valueSetDefinition and valueSetName defined."
            )

    @model_validator(mode="before")
    def no_value_set_defined(cls, data):
        if not data.get("valueSet", {}).get("ValueSetDefinition") and not data.get(
            "valueSet", {}
        ).get("valueSetName"):
            raise ValueError(
                "ValueSet must have either valueSetDefinition or valueSetName defined."
            )
        return data

    def add_to_graph(self, graph: nx.MultiDiGraph) -> str:
        node_name = self.name or self.fullName
        object_name = node_name.split(".", 1)[0]
        self.add_node(graph, node_name)
        self.attach_parent_node(graph, object_name, "field_defined_on_sobject")

        if self.valueSetName:
            key = f"{node_name}.globalValueSet[{self.valueSetName}]"
            graph.add_edge(
                node_name,
                self.valueSetName,
                key=key,
                relation="references_global_value_set",
            )
            graph.nodes[node_name]["expression"] = f"{{{self.valueSetName}}}"

        elif self.valueSetDefinition:
            # expression = ",\n".join(f"{value.fullName} = {value.label or value.fullName}" for value in self.valueSet.valueDefinition.value)

            categories = []

            for value in self.valueSet.valueDefinition.value:
                _cat = {"value": value.fullName}

                if value.label:
                    _cat["label"] = value.label

                if value.default:
                    _cat["default"] = True
                categories.append(_cat)
            # TODO: add the category transforms from the ...transforms module
            # TODO: ensure all info is captured
            # TODO: understand what a controlling field is and how to represent that here
            graph.nodes[node_name]["expression"] = categories

        return graph
