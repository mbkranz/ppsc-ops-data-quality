"""Native field metadata to annotated SQLGlot column definitions.

The caller selects saved records and owns file identity. This module performs
no acquisition, physical lake binding, Ibis conversion or policy enforcement.
"""

from __future__ import annotations

import math
import re
from collections.abc import Mapping
from typing import Any

from sqlglot import exp

from salesforce.core.provenance import annotate, source_metadata


class UnsupportedFieldError(ValueError):
    """A selected field cannot be represented from its supplied native evidence."""


def _first(field, *names):
    return next((field[name] for name in names if field.get(name) is not None), None)


def to_sqlglot(
    field: Mapping[str, Any], *, source: Mapping[str, Any] | None = None
) -> exp.ColumnDef:
    """Compile one scalar field; constraints remain evidence on nullable inputs.

    Compound parents require their actual component definitions. Numeric
    precision/scale and string length are used only when explicitly supplied.
    """
    obj = _first(field, "EntityDefinition.QualifiedApiName", "objectName")
    name = _first(
        field,
        "EntityParticle.QualifiedApiName",
        "QualifiedApiName",
        "FieldDefinition.QualifiedApiName",
    )
    if not isinstance(obj, str) or not obj or not isinstance(name, str) or not name:
        raise ValueError(
            "Field compilation requires nonempty object and field identities"
        )
    parent = field.get("FieldDefinition.QualifiedApiName")
    component = _first(field, "EntityParticle.IsComponent", "IsComponent") is True
    component = component or (isinstance(parent, str) and parent != name)
    identity = f"{obj}.{parent}.{name}" if component and parent else f"{obj}.{name}"
    native_type = _first(
        field, "EntityParticle.DataType", "DataType", "FieldDefinition.DataType"
    )
    if not isinstance(native_type, str) or not native_type:
        raise UnsupportedFieldError(f"{identity}: native type evidence unavailable")
    kind = native_type.casefold()
    # FieldDefinition display strings are supported only when unambiguous.
    display = re.fullmatch(r"(number|currency|percent)\((\d+),\s*(\d+)\)", kind)
    precision = _first(
        field, "EntityParticle.Precision", "Precision", "FieldDefinition.Precision"
    )
    scale = _first(field, "EntityParticle.Scale", "Scale", "FieldDefinition.Scale")
    if display:
        kind = display[1]
        declared = (int(display[2]), int(display[3]))
        if (precision is not None and precision != declared[0]) or (
            scale is not None and scale != declared[1]
        ):
            raise UnsupportedFieldError(f"{identity}: conflicting numeric declarations")
        precision, scale = declared
    strings = {
        "string",
        "text",
        "textarea",
        "longtextarea",
        "html",
        "id",
        "reference",
        "picklist",
        "multipicklist",
        "combobox",
        "email",
        "phone",
        "url",
        "encryptedstring",
        "base64",
    }
    if re.fullmatch(r"(?:lookup|master-detail)\([^)]+\)", kind):
        kind = "reference"
    if kind in strings:
        length = _first(
            field, "EntityParticle.Length", "Length", "FieldDefinition.Length"
        )
        if length is not None:
            if (
                isinstance(length, bool)
                or not isinstance(length, (int, float))
                or not math.isfinite(length)
                or int(length) != length
                or length <= 0
            ):
                raise UnsupportedFieldError(f"{identity}: invalid native string length")
            dtype = exp.DataType.build(f"VARCHAR({int(length)})")
        else:
            dtype = exp.DataType.build("TEXT")
    elif kind in {"double", "currency", "percent", "number"}:
        if precision is None or scale is None:
            raise UnsupportedFieldError(
                f"{identity}: numeric precision and scale unavailable"
            )
        if any(
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not math.isfinite(value)
            or int(value) != value
            for value in (precision, scale)
        ):
            raise UnsupportedFieldError(f"{identity}: invalid numeric precision/scale")
        precision, scale = int(precision), int(scale)
        if not 1 <= precision <= 38 or not 0 <= scale <= precision:
            raise UnsupportedFieldError(
                f"{identity}: unsupported numeric precision/scale"
            )
        dtype = exp.DataType.build(f"DECIMAL({precision},{scale})")
    else:
        scalar = {
            "boolean": "BOOLEAN",
            "int": "INT",
            "integer": "INT",
            "long": "BIGINT",
            "date": "DATE",
            "datetime": "TIMESTAMP",
            "time": "TIME",
        }
        if kind not in scalar:
            raise UnsupportedFieldError(
                f"{identity}: unsupported native type {native_type!r}; select scalar components where available"
            )
        dtype = exp.DataType.build(scalar[kind])
    metadata = source_metadata(
        dict(field),
        source=dict(source or {}),
        entity_type="SalesforceField",
        source_entities=["FieldDefinition." + identity],
        target_field=identity,
        native_field_id=_first(
            field, "EntityParticle.DurableId", "DurableId", "FieldDefinition.DurableId"
        ),
        description=_first(
            field,
            "EntityParticle.Description",
            "FieldDefinition.Description",
            "FieldDefinition.Metadata.description",
            "Description",
        )
        or ("Native field " + identity),
        translation_status="supported_representation",
    )
    return annotate(
        exp.ColumnDef(this=exp.to_identifier(name, quoted=True), kind=dtype), metadata
    )
