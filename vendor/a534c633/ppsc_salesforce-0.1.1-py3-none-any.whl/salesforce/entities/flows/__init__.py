"""Flow acquisition and offline lineage; import implementations explicitly."""


def __getattr__(name):
    # Existing public acquisition hooks stay lazy for offline compiler users.
    if name in {
        "discover_flows",
        "fetch_flow_metadata",
        "read_api",
        "export_flow_metadata_from_tooling_query",
    }:
        from . import api

        return getattr(
            api,
            "read_api" if name == "export_flow_metadata_from_tooling_query" else name,
        )
    if name == "export_flows":
        from .export import export_flows

        return export_flows
    raise AttributeError(name)


def to_graphs(filepath):
    from .graph import compile_lineage
    from .snapshot import read_flows
    from .tables import flow_graphs

    return flow_graphs(compile_lineage(read_flows(filepath), org="offline"))


def payload_to_df(filepath):
    from .graph import compile_lineage
    from .snapshot import read_flows
    from .tables import workbook_tables

    return workbook_tables(compile_lineage(read_flows(filepath), org="offline"))


__all__ = [
    "discover_flows",
    "fetch_flow_metadata",
    "export_flows",
    "read_api",
    "export_flow_metadata_from_tooling_query",
    "to_graphs",
    "payload_to_df",
]
