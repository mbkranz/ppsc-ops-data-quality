"""Live Flow-version acquisition, independent of export storage."""

import re

from pydantic import BaseModel, ConfigDict, Field

from salesforce import soql_templates
from salesforce.client import query_records

FLOW_ID_PATTERN = r"^301[A-Za-z0-9]{12}(?:[A-Za-z0-9]{3})?$"
INVENTORY_QUERY = soql_templates.tooling.by_entity.Flow.inventory
METADATA_QUERY = soql_templates.tooling.by_entity.Flow.metadata


class FlowLookupError(LookupError):
    """A successful query did not return the requested Flow version."""


class FlowVersion(BaseModel):
    """Required retrieval fields; retain the original payload for downstream models."""

    model_config = ConfigDict(strict=True, extra="allow", hide_input_in_errors=True)

    Id: str
    FullName: str = Field(min_length=1)
    MasterLabel: str = Field(min_length=1)
    Metadata: dict


def validate_flow_id(flow_id: str) -> str:
    if not isinstance(flow_id, str) or not re.fullmatch(FLOW_ID_PATTERN, flow_id):
        raise ValueError("An exact 15- or 18-character Flow version Id is required")
    return flow_id


def discover_flows(client) -> list[dict]:
    records = query_records(
        client.query(INVENTORY_QUERY, use_tooling_api=True), "Flow inventory"
    )
    seen = set()
    for record in records:
        flow_id = validate_flow_id(record.get("Id"))
        if flow_id[:15] in seen:
            raise ValueError("Repeated Flow version in inventory")
        seen.add(flow_id[:15])
    return records


def validate_flow_pages(pages, flow_id) -> list[dict]:
    validate_flow_id(flow_id)
    records = query_records(pages, "Flow metadata")
    if not records:
        raise FlowLookupError("Requested Flow version was not returned")
    if len(records) != 1:
        raise ValueError("Flow metadata must contain exactly one version")
    record = records[0]
    returned_id = validate_flow_id(record.get("Id"))
    if returned_id[:15] != flow_id[:15]:
        raise ValueError("Flow metadata returned a different version Id")
    if not isinstance(record.get("Metadata"), dict):
        raise ValueError("Flow metadata must contain a Metadata object")
    FlowVersion.model_validate(record)
    return pages


def fetch_flow_metadata(client, flow_id) -> list[dict]:
    validate_flow_id(flow_id)
    pages = client.query(METADATA_QUERY.format(id=flow_id), use_tooling_api=True)
    return validate_flow_pages(pages, flow_id)


def read_api(client):
    """Collect native query envelopes; use export_flows for resumable storage."""
    pages = []
    for record in discover_flows(client):
        pages.extend(fetch_flow_metadata(client, record["Id"]))
    return pages
