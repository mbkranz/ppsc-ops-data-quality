"""Flow-version manifests and validated offline payload access."""

from datetime import UTC, datetime
from pathlib import Path
from typing import Annotated
from uuid import UUID, uuid4

from pydantic import AwareDatetime, BaseModel, Field, model_validator

from salesforce.client import (
    CHECKPOINT_CONFIG,
    CheckpointEntry,
    CheckpointScope,
    atomic_output,
    load_payload,
    save_payload,
)
from .api import FLOW_ID_PATTERN, validate_flow_pages

FlowId = Annotated[str, Field(pattern=FLOW_ID_PATTERN)]


class FlowCheckpoint(BaseModel):
    model_config = CHECKPOINT_CONFIG

    schema_version: int = Field(default=1, ge=1, le=1)
    run_id: UUID = Field(default_factory=uuid4)
    started_at: AwareDatetime = Field(default_factory=lambda: datetime.now(UTC))
    complete: bool = False
    scope: CheckpointScope
    inventory: list[dict]
    selected_ids: list[FlowId]
    entries: dict[FlowId, CheckpointEntry] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_selection(self):
        identities = [value[:15] for value in self.selected_ids]
        if len(set(identities)) != len(identities):
            raise ValueError("Repeated selected Flow version")
        if not set(self.entries).issubset(self.selected_ids):
            raise ValueError("Checkpoint entries must belong to the selected versions")
        inventory_ids = [record.get("Id") for record in self.inventory]
        if inventory_ids != self.selected_ids:
            raise ValueError(
                "Checkpoint inventory does not match selected Flow versions"
            )
        return self


def save_checkpoint(directory: Path, checkpoint: FlowCheckpoint) -> None:
    checkpoint = FlowCheckpoint.model_validate(checkpoint)
    with atomic_output(directory / "manifest.json") as temporary:
        temporary.write_text(checkpoint.model_dump_json(indent=2), encoding="utf-8")


def load_checkpoint(directory: Path, scope: CheckpointScope) -> FlowCheckpoint:
    try:
        checkpoint = FlowCheckpoint.model_validate_json(
            (directory / "manifest.json").read_bytes()
        )
    except (FileNotFoundError, ValueError) as error:
        raise ValueError(
            "Cannot resume Flow checkpoint; start a fresh export"
        ) from error
    if checkpoint.scope != scope:
        raise ValueError("Flow checkpoint scope changed; start a fresh export")
    return checkpoint


def save_flow(
    directory: Path, checkpoint: FlowCheckpoint, flow_id: str, pages: list[dict]
) -> FlowCheckpoint:
    if flow_id not in checkpoint.selected_ids:
        raise ValueError("Flow version is outside the checkpoint selection")
    validate_flow_pages(pages, flow_id)
    entry = save_payload(directory, pages)
    updated = FlowCheckpoint.model_validate(
        checkpoint.model_copy(
            update={
                "entries": {**checkpoint.entries, flow_id: entry},
                "complete": False,
            }
        )
    )
    save_checkpoint(directory, updated)
    return updated


def load_flow(
    directory: Path, entry: CheckpointEntry, *, flow_id: str | None = None
) -> list[dict]:
    """Verify digest, complete pages, and version identity without a live client."""
    pages = load_payload(directory, entry)
    if flow_id is None:
        try:
            flow_id = pages[0]["records"][0]["Id"]
        except (IndexError, KeyError, TypeError):
            raise ValueError("Malformed saved Flow payload") from None
    return validate_flow_pages(pages, flow_id)
