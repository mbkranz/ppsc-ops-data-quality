"""The lineage/v1 table contract and canonical serialization."""

import json
from enum import Enum

import pyarrow as pa
from pydantic_core import to_jsonable_python

CONTRACT_VERSION = "lineage/v1"
ARTIFACT_NAMES = {
    "flows.json",
    "nodes.parquet",
    "edges.parquet",
    "expressions.parquet",
    "manifest.json",
}

NODE_SCHEMA = pa.schema([
    pa.field("node_id", pa.string(), nullable=False),
    pa.field("kind", pa.string(), nullable=False),
    pa.field("name", pa.string(), nullable=False),
    pa.field("flow_name", pa.string()),
    pa.field("flow_version_id", pa.string()),
    pa.field("resolution_status", pa.string(), nullable=False),
    pa.field("attributes_json", pa.string(), nullable=False),
])

EDGE_SCHEMA = pa.schema([
    pa.field("edge_id", pa.string(), nullable=False),
    pa.field("source_id", pa.string(), nullable=False),
    pa.field("target_id", pa.string(), nullable=False),
    pa.field("relation", pa.string(), nullable=False),
    pa.field("flow_name", pa.string()),
    pa.field("flow_version_id", pa.string()),
    pa.field("source_path", pa.string()),
    pa.field("evidence_type", pa.string(), nullable=False),
    pa.field("resolution_status", pa.string(), nullable=False),
    pa.field("attributes_json", pa.string(), nullable=False),
])

EXPRESSION_SCHEMA = pa.schema([
    pa.field("expression_id", pa.string(), nullable=False),
    pa.field("owner_node_id", pa.string(), nullable=False),
    pa.field("source_language", pa.string(), nullable=False),
    pa.field("native_expression", pa.string()),
    pa.field("athena_sql", pa.string()),
    pa.field("translation_status", pa.string(), nullable=False),
    pa.field("source_path", pa.string()),
    pa.field("reason", pa.string()),
])


def canonical_json(value):
    """Preserve native model/date values with stable JSON key ordering."""
    return json.dumps(
        to_jsonable_python(value),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )


class EdgeType(str, Enum):
    """Standardized edge types for control flow and data lineage."""

    # Control flow
    navigates_to = "navigates_to"

    # Data lineage: generalized
    reads_resource = "reads_resource"  # RHS → element
    writes_resource = "writes_resource"  # element → LHS resource
    derives = "derives"  # inputs → derived resource (e.g., formula)

    # Data lineage: Salesforce-specific operations
    queries_object = "queries_object"  # Get Records → SObject
    updates_object = "updates_object"  # Update → SObject
    creates_object = "creates_object"  # Create → SObject
    deletes_object = "deletes_object"  # Delete → SObject

    # Invocation edges
    invokes_action = "invokes_action"
    invokes_apex = "invokes_apex"  # Action/Apex → Apex class or action
    invokes_subflow = "invokes_subflow"  # Subflow element → Flow
    invokes_stage_steps = "invokes_stage_steps"  # Stage element → Flow

    # Mappings
    maps_input = "maps_input"  # parent resource → child flow input
    maps_output = "maps_output"  # child output → parent resource

    # UX/Loop helpers
    uses_screen_component = "uses_screen_component"
    loop_over = "loop_over"  # Loop → collection var


class NodeKind(str, Enum):
    """Node kinds to quickly filter graph nodes by role."""

    Flow = "Flow"
    FlowElement = "FlowElement"
    Resource = "Resource"
    SObject = "Object"
    SObjectField = "Field"
    Parameter = "Parameter"
    Literal = "Literal"
    ApexClass = "ApexClass"

    def to_tagged_name(self, name):
        return f"{self.value}[{name}]"
