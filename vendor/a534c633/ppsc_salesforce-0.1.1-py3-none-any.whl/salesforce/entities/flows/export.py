"""Serial Flow collection with per-version checkpoints and explicit resume."""

import json
import logging
from pathlib import Path

from simple_salesforce.exceptions import SalesforceError

from salesforce.client import (
    READ_RETRY_ERRORS,
    SalesforceClient,
    atomic_output,
    can_defer_read_error,
    checkpoint_scope,
)
from .api import (
    INVENTORY_QUERY,
    METADATA_QUERY,
    discover_flows,
    fetch_flow_metadata,
    validate_flow_id,
)
from .checkpoint import (
    FlowCheckpoint,
    load_checkpoint,
    load_flow,
    save_checkpoint,
    save_flow,
)

logger = logging.getLogger(__name__)


def _read_failure(error, inventory_record):
    """Retain structured server details without the exception's request URL."""
    content = getattr(error, "content", None)
    details = (
        [
            {
                key: item[key]
                for key in ("errorCode", "message")
                if isinstance(item.get(key), str)
            }
            for item in content
            if isinstance(item, dict)
        ]
        if isinstance(content, list)
        else []
    )
    definition = inventory_record.get("Definition")
    return {
        "developer_name": definition.get("DeveloperName")
        if isinstance(definition, dict)
        else None,
        "error_type": type(error).__name__,
        "status": getattr(error, "status", None),
        "details": details,
    }


def _is_inaccessible(error):
    if not isinstance(error, SalesforceError) or error.status not in (400, 403):
        return False
    details = error.content
    return (
        isinstance(details, list)
        and bool(details)
        and all(
            isinstance(item, dict)
            and item.get("errorCode")
            in {"INSUFFICIENT_ACCESS", "INSUFFICIENT_ACCESS_OR_READONLY"}
            for item in details
        )
    )


def export_flows(
    client: SalesforceClient,
    export_dir: Path,
    *,
    flow_ids=None,
    resume=False,
    max_requests=None,
    max_elapsed_seconds=None,
    allow_inaccessible=False,
) -> FlowCheckpoint:
    """Publish saved versions, requiring complete coverage unless explicitly relaxed.

    None discovers all current versions; [] selects no versions. Resume restores
    the original inventory and accepts only an identical explicit selection.
    allow_inaccessible omits versions denied read access and reports each failure;
    an incomplete checkpoint remains resumable. Other failures still propagate.
    """
    budget = client.run_budget(
        max_requests=max_requests, max_elapsed_seconds=max_elapsed_seconds
    )
    with budget as allowance:
        return _export_flows(
            client,
            Path(export_dir),
            flow_ids=flow_ids,
            resume=resume,
            budget=allowance,
            allow_inaccessible=allow_inaccessible,
        )


def _export_flows(
    client, export_dir: Path, *, flow_ids, resume, budget, allow_inaccessible=False
) -> FlowCheckpoint:
    directory = export_dir / "_cache/flows"
    selected = (
        None if flow_ids is None else [validate_flow_id(value) for value in flow_ids]
    )
    if selected is not None and len({value[:15] for value in selected}) != len(
        selected
    ):
        raise ValueError("Flow selection requires distinct version IDs")
    scope = checkpoint_scope(client, INVENTORY_QUERY + METADATA_QUERY)
    if resume:
        checkpoint = load_checkpoint(directory, scope)
        if selected is not None and selected != checkpoint.selected_ids:
            raise ValueError(
                "Explicit Flow selection conflicts with the saved selection"
            )
    else:
        inventory = (
            discover_flows(client)
            if selected is None
            else [{"Id": value} for value in selected]
        )
        checkpoint = FlowCheckpoint(
            scope=scope,
            inventory=inventory,
            selected_ids=[record["Id"] for record in inventory],
        )
    checkpoint = checkpoint.model_copy(update={"complete": False})
    save_checkpoint(directory, checkpoint)
    restored = set()
    for flow_id, entry in checkpoint.entries.items():
        try:
            load_flow(directory, entry, flow_id=flow_id)
        except (FileNotFoundError, ValueError, LookupError):
            logger.warning("Requerying an invalid saved Flow version")
        else:
            restored.add(flow_id)
    pending = [
        flow_id for flow_id in checkpoint.selected_ids if flow_id not in restored
    ]
    completed = set(restored)
    deferred = []
    fetched = 0
    failures = []
    failed_reads = {}
    outputs_published = False

    def report():
        payload = {
            "run_id": str(checkpoint.run_id),
            "selected": len(checkpoint.selected_ids),
            "completed": len(completed),
            "restored": len(restored),
            "fetched": fetched,
            "pending": [
                value for value in checkpoint.selected_ids if value not in completed
            ],
            "failed": failed_reads,
            "outputs_published": outputs_published,
            "coverage_complete": len(completed) == len(checkpoint.selected_ids),
        }
        with atomic_output(export_dir / "flow-report.json") as temporary:
            temporary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    try:
        for recovery in (False, True):
            for flow_id in deferred if recovery else pending:
                try:
                    pages = fetch_flow_metadata(client, flow_id)
                except READ_RETRY_ERRORS as error:
                    inventory_record = next(
                        record
                        for record in checkpoint.inventory
                        if record["Id"] == flow_id
                    )
                    failed_reads[flow_id] = _read_failure(error, inventory_record)
                    if allow_inaccessible and _is_inaccessible(error):
                        logger.warning(
                            "Flow version omitted after access denial: %s; see flow-report.json",
                            flow_id,
                        )
                        continue
                    if not can_defer_read_error(error):
                        logger.error(
                            "Flow metadata read stopped: version=%s error=%s; see flow-report.json",
                            flow_id,
                            type(error).__name__,
                        )
                        raise
                    if recovery:
                        failures.append(error)
                    else:
                        deferred.append(flow_id)
                    logger.warning(
                        "Flow read %s (%s)",
                        "recovery failed" if recovery else "deferred",
                        type(error).__name__,
                    )
                    continue
                checkpoint = save_flow(directory, checkpoint, flow_id, pages)
                fetched += 1
                completed.add(flow_id)
                failed_reads.pop(flow_id, None)
                if fetched % 100 == 0:
                    logger.info(
                        "Flow metadata: completed=%d/%d denied=%d",
                        len(completed),
                        len(checkpoint.selected_ids),
                        len(failed_reads),
                    )
        if len(failures) == 1:
            raise failures[0]
        if failures:
            raise ExceptionGroup("Flow recovery failed", failures)
        if budget is not None:
            budget.check()
        # Read one version at a time; retain the legacy list of full query envelopes.
        with atomic_output(export_dir / "Flow.json") as temporary:
            with temporary.open("w", encoding="utf-8") as output:
                output.write("[")
                first = True
                for flow_id in checkpoint.selected_ids:
                    if flow_id not in completed:
                        continue
                    pages = load_flow(
                        directory, checkpoint.entries[flow_id], flow_id=flow_id
                    )
                    for page in pages:
                        if not first:
                            output.write(",")
                        json.dump(page, output)
                        first = False
                output.write("]")
        outputs_published = True
        checkpoint = checkpoint.model_copy(
            update={"complete": len(completed) == len(checkpoint.selected_ids)}
        )
        save_checkpoint(directory, checkpoint)
    except BaseException:
        try:
            report()
        except Exception:
            logger.error(
                "Could not write flow-report.json while handling export failure"
            )
        raise
    else:
        report()
        return checkpoint
    finally:
        logger.info(
            "Flow export: restored=%d fetched=%d failed=%d pending=%d selected=%d published=%s",
            len(restored),
            fetched,
            len(failed_reads),
            len(checkpoint.selected_ids) - len(completed),
            len(checkpoint.selected_ids),
            outputs_published,
        )
