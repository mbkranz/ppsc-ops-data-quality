"""Pure Flow graph compilation with scoped IDs and native source evidence."""

import re
from contextlib import contextmanager
from dataclasses import dataclass
from urllib.parse import quote

import networkx as nx

from .contract import CONTRACT_VERSION, canonical_json
from .expressions import SqlContext, native_expressions
from .lineage import record_types, reference_occurrences, resolve_field
from .snapshot import FlowSnapshot


class MetadataGraph(nx.MultiDiGraph):
    """Emit model graphs with one relation convention and owning-element evidence."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._source_path = None

    @contextmanager
    def at_source(self, path):
        previous, self._source_path = self._source_path, path
        try:
            yield
        finally:
            self._source_path = previous

    def add_node(self, node_for_adding, **attrs):
        if self._source_path is not None:
            attrs.setdefault("source_path", self._source_path)
        return super().add_node(node_for_adding, **attrs)

    def add_edge(self, u_for_edge, v_for_edge, key=None, **attrs):
        attrs.setdefault("source_reference", u_for_edge)
        attrs.setdefault("target_reference", v_for_edge)
        attrs["relation"] = (
            attrs.get("relation")
            or attrs.get("edge_type")
            or attrs.get("type")
            or "unclassified"
        )
        if self._source_path is not None:
            attrs.setdefault("source_path", self._source_path)
        return super().add_edge(u_for_edge, v_for_edge, key=key, **attrs)


@dataclass(frozen=True)
class CompiledLineage:
    graph: nx.MultiDiGraph
    expressions: list[dict]
    manifest: dict


def _node_status(kind, attrs, source_path, objects, fields, relationships):
    if attrs.get("synthetic_terminal"):
        return "resolved"
    if attrs.get("reference_status") == "unmapped":
        return "unresolved"
    if kind == "Literal":
        return "not_applicable"
    if kind == "Object":
        return "resolved" if attrs.get("object") in objects else "unresolved"
    if kind == "Field":
        identity = (attrs.get("object"), attrs.get("field"))
        return (
            "resolved"
            if resolve_field(*identity, fields, relationships)
            else "unresolved"
        )
    return "resolved" if source_path else "unresolved"


def _add_flow(
    graph,
    expressions,
    record,
    raw,
    source_path,
    objects,
    fields,
    relationships,
    *,
    catalog_verified=False,
    source_file="Flow.json",
):
    """Project the existing model graph with scoped IDs and retained native evidence."""
    flow_name = record.Metadata.fullName or record.FullName
    root_id = f"{quote(graph.graph['org'], safe='')}/flow/{quote(record.Id, safe='')}"
    metadata_path = f"{source_path}/Metadata"

    graph.add_node(
        root_id,
        kind="Flow",
        name=flow_name,
        flow_name=flow_name,
        flow_version_id=record.Id,
        resolution_status="resolved",
        source_path=source_path,
        source_file=source_file,
        source_record=raw,
    )
    model_graph = record.to_graph()
    occurrences = list(reference_occurrences(raw["Metadata"]))
    node_ids = {
        name: f"{root_id}/node/{quote(str(name), safe='')}" for name in model_graph
    }
    owners = {}
    for name, data in sorted(
        model_graph.nodes(data=True), key=lambda item: str(item[0])
    ):
        local_name = str(name).removeprefix(flow_name + ".")
        relative_path = data.get("source_path")
        path = metadata_path + relative_path if relative_path is not None else None
        attrs = data.get("attrs", {})
        model_kind = attrs.get("node_kind", "Resource")
        kind = "FlowElement" if model_kind.startswith("Flow") else model_kind
        status = _node_status(kind, attrs, path, objects, fields, relationships)
        graph.add_node(
            node_ids[name],
            **(
                data
                | dict(
                    kind=kind,
                    name=str(name),
                    flow_name=flow_name,
                    flow_version_id=record.Id,
                    resolution_status=status,
                    source_path=path,
                    source_file=source_file,
                )
            ),
        )
        if path:
            owners[local_name] = node_ids[name]

    for source, target, key, data in sorted(
        model_graph.edges(keys=True, data=True),
        key=lambda item: tuple(str(part) for part in item[:3]),
    ):
        edge_id = (
            root_id
            + "/edge/"
            + "/".join(
                quote(part, safe="")
                for part in (str(source), str(target), canonical_json(key))
            )
        )
        relative_path = data.get("source_path")
        path = metadata_path + relative_path if relative_path is not None else None
        endpoints = {"source": source, "target": target}
        endpoint_references = {
            side: data.get(side + "_reference", endpoint)
            for side, endpoint in endpoints.items()
        }
        reference_path = data.get("reference_path")
        matches = [
            occurrence
            for occurrence in occurrences
            if occurrence["owner_path"] == relative_path
            and (
                occurrence["source_path"] == (relative_path or "") + reference_path
                if reference_path is not None
                else occurrence["reference"] in endpoint_references.values()
            )
        ]
        # An exact token shared by several occurrences cannot identify this edge.
        evidence = []
        for occurrence in matches:
            if (
                sum(other["reference"] == occurrence["reference"] for other in matches)
                == 1
            ):
                side = data.get("reference_endpoint")
                matched_nodes = (
                    {node_ids[endpoints[side]]}
                    if reference_path is not None and side in endpoints
                    else {
                        node_ids[endpoints[side]]
                        for side, reference in endpoint_references.items()
                        if reference == occurrence["reference"]
                    }
                )
                evidence.append(
                    {
                        key: value
                        for key, value in occurrence.items()
                        if key != "owner_path"
                    }
                    | {
                        "source_file": source_file,
                        "source_path": metadata_path + occurrence["source_path"],
                        **(
                            {"node_id": next(iter(matched_nodes))}
                            if len(matched_nodes) == 1
                            else {}
                        ),
                    }
                )
        graph.add_edge(
            node_ids[source],
            node_ids[target],
            key=edge_id,
            **(
                data
                | dict(
                    edge_id=edge_id,
                    original_key=key,
                    flow_name=flow_name,
                    flow_version_id=record.Id,
                    source_path=path,
                    source_file=source_file,
                    reference_occurrences=evidence,
                    relation=data["relation"],
                    evidence_type="inferred",
                    resolution_status="unresolved",
                )
            ),
        )

    bindings, _ = record_types(record.Metadata)
    context = SqlContext(
        record_types=bindings,
        relationships=relationships,
        source={
            "source_org": graph.graph["org"],
            "source_file": source_file,
            "source_paths": [metadata_path],
            "flow_version_id": record.Id,
            "flow_name": flow_name,
        },
        scalar_names=frozenset(
            variable.name
            for variable in record.Metadata.variables or []
            if variable.dataType != "SObject"
        ),
        fields=fields if catalog_verified else None,
        object=getattr(record.Metadata.start, "object", None),
    )
    expressions.extend(
        dict(row, source_file=source_file)
        for row in native_expressions(
            raw["Metadata"],
            root_id=root_id,
            base_path=metadata_path,
            owners=owners,
            context=context,
        )
    )


def compile_lineage(
    snapshot: FlowSnapshot, *, org: str, source_file: str = "Flow.json"
) -> CompiledLineage:
    """Compile a saved snapshot without filesystem or network operations."""
    if not re.fullmatch(r"[A-Za-z0-9_-]+", org):
        raise ValueError(
            "Org must be a nonempty alias containing letters, digits, _ or -"
        )
    graph = nx.MultiDiGraph(contract_version=CONTRACT_VERSION, org=org)
    expressions = []
    for source in snapshot.selected:
        _add_flow(
            graph,
            expressions,
            source.model,
            source.raw,
            source.source_path,
            snapshot.objects,
            snapshot.fields,
            snapshot.relationships,
            catalog_verified=bool(snapshot.coverage),
            source_file=source_file,
        )
    expressions.sort(key=lambda row: row["expression_id"])
    inventory = [
        dict(
            flow_version_id=raw["Id"],
            flow_name=raw.get("FullName"),
            status=raw["Metadata"].get("status"),
            source_path=path,
            selected=raw["Metadata"].get("status") == "Active",
        )
        for path, raw in sorted(snapshot.records, key=lambda item: item[1]["Id"])
    ]
    manifest = dict(
        contract_version=CONTRACT_VERSION,
        org=org,
        sources=snapshot.sources,
        active_version_selection="Metadata.status == Active; duplicate IDs/names rejected",
        flow_versions=inventory,
        coverage=snapshot.coverage,
        coverage_warnings=snapshot.warnings,
        coverage_complete=bool(snapshot.coverage)
        and all(report["coverage_complete"] for report in snapshot.coverage.values()),
        api_versions=sorted({
            str(record.Metadata.apiVersion)
            for record in (source.model for source in snapshot.selected)
            if record.Metadata.apiVersion is not None
        }),
        row_counts=dict(
            nodes=graph.number_of_nodes(),
            edges=graph.number_of_edges(),
            expressions=len(expressions),
        ),
        limitations=[
            "Only active versions with readable metadata are graphed",
            "Edges retain inferred semantics; audit checks artifact and graph integrity without execution equivalence",
            "Field resolution uses exact catalog fields and unambiguous saved relationship names",
            "Unknown metadata is retained; parser coverage is checked by regression tests, not flow-audit",
            "SQLGlot output is illustrative; physical binding and executable equivalence are unverified",
            "Git release identity is attached during publication; DVC owns artifact content identity",
        ],
    )
    return CompiledLineage(graph, expressions, manifest)
