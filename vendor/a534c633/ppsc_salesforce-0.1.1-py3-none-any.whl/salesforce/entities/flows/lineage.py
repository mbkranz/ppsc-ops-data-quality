"""Label implicit lineage nodes using the Flow's declared record context."""

from salesforce.core.formulas import formula_reference_occurrences


def reference_occurrences(metadata):
    """Yield native reference evidence with relative JSON Pointers and owner paths.

    These occurrences do not resolve names or create graph relationships.
    """
    reference_keys = {
        "actionName", "flowName", "apexClass", "extensionName",
        "sourceTemplateApiName", "object", "field", "sortField", "recordField",
        "displayField", "valueField", "picklistField",
    }
    expression_keys = {
        "expression", "formula", "filterFormula", "formulaExpression",
    }

    def walk(value, path, owner_path):
        if isinstance(value, dict):
            for key, child in value.items():
                escaped = key.replace("~", "~0").replace("/", "~1")
                child_path = f"{path}/{escaped}"
                if isinstance(child, str):
                    if key.endswith("Reference") or key in reference_keys:
                        yield dict(
                            reference=child,
                            source_path=child_path,
                            owner_path=owner_path,
                        )
                    elif key in expression_keys:
                        for occurrence in formula_reference_occurrences(child):
                            yield dict(
                                reference=occurrence.text,
                                source_path=child_path,
                                owner_path=owner_path,
                                start=occurrence.start,
                                end=occurrence.end,
                            )
                elif key == "queriedFields" and isinstance(child, list):
                    for index, reference in enumerate(child):
                        if isinstance(reference, str):
                            yield dict(
                                reference=reference,
                                source_path=f"{child_path}/{index}",
                                owner_path=owner_path,
                            )
                yield from walk(child, child_path, owner_path)
        elif isinstance(value, list):
            for index, child in enumerate(value):
                yield from walk(child, f"{path}/{index}", owner_path)

    for key, value in metadata.items():
        path = "/" + key.replace("~", "~0").replace("/", "~1")
        if isinstance(value, list):
            for index, child in enumerate(value):
                owner_path = f"{path}/{index}"
                yield from walk(child, owner_path, owner_path)
        else:
            yield from walk(value, path, path)


def record_types(flow):
    objects = set()
    records = {}
    for variable in flow.variables or []:
        if variable.objectType:
            records[variable.name] = variable.objectType
    for name in (
        "start",
        "recordLookups",
        "recordCreates",
        "recordUpdates",
        "recordDeletes",
        "dynamicChoiceSets",
    ):
        value = getattr(flow, name, None)
        for element in value if isinstance(value, list) else [value]:
            obj = getattr(element, "object", None)
            if not obj:
                continue
            objects.add(obj)
            if name == "start":
                records.update({"$Record": obj, "$Record__Prior": obj})
            if name == "recordLookups":
                records[element.name] = obj
                if element.outputReference:
                    records[element.outputReference] = obj
    # Loop items retain the collection's object type, including nested loops.
    pending = list(flow.loops or [])
    while pending:
        resolved = [loop for loop in pending if loop.collectionReference in records]
        if not resolved:
            break
        for loop in resolved:
            records[loop.name] = records[loop.collectionReference]
            pending.remove(loop)
    records.update({
        "$User": "User",
        "$UserRole": "UserRole",
        "$Organization": "Organization",
        "$Profile": "Profile",
    })
    objects.update(records.values())
    return records, objects


def label_references(flow, graph):
    records, objects = record_types(flow)
    for node, data in graph.nodes(data=True):
        attrs = data.setdefault("attrs", {})
        # All nodes belong to this process, including upstream schema sources.
        data.update(
            process_name=flow.fullName,
            process_kind=flow.node_kind,
            process_type=flow.processType,
            process_label=flow.label,
        )
        if not attrs.get("node_kind") and data.get("node_kind"):
            attrs["node_kind"] = {
                "apexClass": "ApexClass",
                "parameter": "Resource",
                "Parameter": "Resource",
            }.get(data["node_kind"], data["node_kind"])
        if attrs.get("node_kind"):
            continue
        root, dot, field = str(node).partition(".")
        obj = records.get(root, root if root in objects else None)
        if dot and root == "$Setup":
            obj, _, field = field.partition(".")
        if dot and obj and field:
            attrs.update(
                node_kind="Field",
                node_hierarchy="Entity.Field",
                object=obj,
                field=field,
            )
        elif node in objects:
            attrs.update(
                node_kind="Object", node_hierarchy="Entity.Object", object=node
            )
        elif str(node).startswith("Literal["):
            attrs.update(node_kind="Literal", node_hierarchy="Resource.Literal")
        else:
            attrs["reference_status"] = "unmapped"


def resolve_field(object_name, field_path, fields, relationships):
    """Resolve exact fields and unambiguous saved relationship names only."""
    if (object_name, field_path) in fields:
        return object_name, field_path
    if not isinstance(field_path, str):
        return None
    parts = field_path.split(".")
    for relationship in parts[:-1]:
        targets = relationships.get((object_name, relationship), ())
        if len(targets) != 1:
            return None
        object_name = targets[0]
    return (object_name, parts[-1]) if (object_name, parts[-1]) in fields else None
