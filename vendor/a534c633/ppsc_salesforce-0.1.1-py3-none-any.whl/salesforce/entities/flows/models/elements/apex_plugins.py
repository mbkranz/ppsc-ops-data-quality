from pydantic import ConfigDict

from .base import (
    FlowBaseElement,
    FlowConnector,
    FlowInputParameter,
    FlowNode,
    add_connector_edges,
    add_input_param_nodes_and_edges,
    add_output_param_nodes_and_edges,
)


__all__ = [
    "FlowApexPluginCallInputParameter",
    "FlowApexPluginCallOutputParameter",
    "FlowApexPluginCall",
]


class FlowApexPluginCallInputParameter(FlowInputParameter):
    pass


class FlowApexPluginCallOutputParameter(FlowBaseElement):
    assignToReference: str
    name: str


class FlowApexPluginCall(FlowNode):
    """Action (Apex Plugin Call subset): Invoke reusable functionality (Apex, email alert, quick action, platform action, HTTP callout, etc.)."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Action",
            "description": "Invoke reusable functionality (Apex, email alert, quick action, platform action, HTTP callout, etc.).",
        }
    )
    apexClass: str
    connector: FlowConnector
    faultConnector: FlowConnector | None = None
    inputParameters: list[FlowApexPluginCallInputParameter]
    outputParameters: list[FlowApexPluginCallOutputParameter]

    def add_to_graph(self, graph):
        self.add_node(graph)

        if self.inputParameters:
            add_input_param_nodes_and_edges(self, graph)
        # apex class → invokes_apex
        if self.apexClass:
            graph.add_node(self.apexClass, node_kind="apexClass")
            graph.add_edge(
                self.name,
                self.apexClass,
                key=self.name + ".apexClass",
                relation="invokes_apex",
            )

        if self.outputParameters:
            add_output_param_nodes_and_edges(self, graph)

        # connectors → navigates_to
        connectors = dict([
            ("connector", self.connector),
            ("faultConnector", self.faultConnector),
        ])
        add_connector_edges(self, graph, **connectors)

        return graph
