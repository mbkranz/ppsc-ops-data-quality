from pydantic import ConfigDict, field_validator
from pydantic.alias_generators import to_snake

from .base import FlowBaseElement, FlowElementReferenceOrValue,FlowConnector,FlowNode, add_connector_edges
from ..types.enums import FlowAssignmentOperator


__all__ = [
    "FlowAssignment","FlowAssignmentItem"
]
class FlowAssignmentItem(FlowBaseElement):
    assignToReference: str
    operator: FlowAssignmentOperator
    value: FlowElementReferenceOrValue | None = None

    @field_validator("value",mode="after")
    def placeholder(cls,value):
        # Implement your validation logic here
        if value is None:
            return FlowElementReferenceOrValue()
        return value


class FlowAssignment(FlowNode):
    """Assignment: Set, clear, or increment variable and collection values."""
    model_config = ConfigDict(json_schema_extra={
        "title": "Assignment",
        "description": "Set, clear, or increment variable and collection values.",
    })
    connector: FlowConnector | None = None
    assignmentItems: list[FlowAssignmentItem] | None = None

    def add_to_graph(self,graph):
        self.add_node(graph)
        assignments = []
        if self.assignmentItems:
            # for each assignment item, create property node of assignmentItems and connect each reference/value to the item and then the item to the specified reference to be assigned to.
            for i,item in enumerate(self.assignmentItems):
                formatted_values = item.value.format_values()
                assignment = f"{item.operator}({formatted_values['value']}) AS {item.assignToReference}"
                assignments.append(assignment)

                graph.add_edge(
                    formatted_values["name"],
                    self.name,
                    key = f"{self.name}.assignmentItems[{i}].value",
                    relation="read_resource_for_assignment",
                    expression=formatted_values["value"],
                    reference_path=(
                        f"/assignmentItems/{i}/value/"
                        + formatted_values["reference_type"] + "Reference"
                        if formatted_values["kind"] == "reference"
                        else None
                    ),
                    reference_endpoint="source",
                )
                # read in the value/reference of the item
                graph.add_edge(
                    self.name,
                    item.assignToReference,
                    key = f"{self.name}.assignmentItems[{i}].assignToReference",
                    relation=to_snake(item.operator),
                    expression=formatted_values["value"],
                    reference_path=f"/assignmentItems/{i}/assignToReference",
                    reference_endpoint="target",
                )
        # after assignments complete: connectors → navigates_to
        graph.nodes[self.name]["expression"] = ";\n".join(assignments)
        add_connector_edges(self, graph, connector=self.connector)
                
        return graph
