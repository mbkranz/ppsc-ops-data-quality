from __future__ import annotations

import json
import networkx as nx
from datetime import datetime, date
from typing import Literal, Self
from pydantic import Field, RootModel, field_validator, model_validator
from pydantic_core import PydanticCustomError
from ...expressions import display_conditions
from ..types.enums import FlowComparisonOperator, FlowWaitConditionType
from salesforce.core.models import Metadata


__all__ = [
    "FlowBaseElement",
    "FlowElement",
    "FlowConnector",
    "FlowStopConnector",
    "FlowNode",
    "FlowElementReferenceOrValue",
    "FlowInputParameter",
    "FlowCustomProperty",
    "FlowDataTypeMapping",
    "FlowRecordFilter",
    "FlowCondition",
    "add_filter_edges",
    "add_connector_edge",
    "add_connector_edges",
    "add_input_param_nodes_and_edges",
    "add_output_param_nodes_and_edges",
    "format_composite_condition",
    "FlowElementList",
]


class FlowMetadataValue(Metadata):
    name: str
    value: str


class FlowBaseElement(Metadata):
    processMetadataValues: list[FlowMetadataValue] = Field(
        description="list of process metadata values."
    )


class FlowElement(FlowBaseElement):
    name: str | None = None
    description: str | None = None


class FlowConnector(FlowBaseElement):
    """A connector determines the path that a flow takes at run time."""

    isGoTo: bool | None = Field(default=None, description="")
    targetReference: str = Field(
        description="Which node to execute after current node (required)"
    )


class FlowStopConnector(FlowConnector):
    """

    A custom (non salesforce) class to represent a STOP connector.
    A stop connector determines the end of a flow path.

    """

    targetReference: str = Field("STOP", pattern=r"\.STOP$")
    not_salesforce_class: Literal[True] = Field(
        True,
        description="Indicates this is a custom class, not part of Salesforce metadata.",
    )
    processMetadataValues: list[None] = Field(default_factory=list)


class FlowNode(FlowElement):
    """
    A node is a type of element that’s visible in the flow diagram.
    It extends FlowElement and inherits all its fields.

    NOTE: in the docs, all inherited fields are not explicitly listed.
    """

    name: str
    label: str | None = None
    locationX: int | None = None
    locationY: int | None = None


def add_connector_edge(
    flowelement: FlowElement | tuple[FlowElement] | list[FlowElement],
    G: nx.MultiDiGraph,
    conn: FlowConnector | None,
    connname: str | None = None,
    label: str | None = None,
    relation: str = "navigates_to",
    **kwargs,
):

    if not isinstance(conn, FlowConnector):
        conn = FlowStopConnector()
    if isinstance(conn, FlowStopConnector):
        G.add_node(
            conn.targetReference,
            attrs=dict(conn.model_dump(exclude_none=True), synthetic_terminal=True),
        )

    if isinstance(flowelement, FlowElement):
        name = flowelement.name
    elif isinstance(flowelement, (tuple, list)):
        name = ".".join(x.name for x in flowelement)
    # for k,v in kwargs.items():
    # if k in __
    # G.nodes[flowelement.name][connname or "connector"] = conn.model_dump(exclude_none=True)
    G.add_edge(
        name,
        conn.targetReference,
        key=name + "." + (connname or "connector"),
        relation=relation,
        **kwargs,
    )


def add_connector_edges(
    flowelement: FlowElement,
    G: nx.MultiDiGraph,
    **conns: dict[str, FlowConnector | None],
):
    for label, conn in conns.items():
        add_connector_edge(flowelement, G, conn, connname=label, label=label)


def add_input_param_nodes_and_edges(flowelement: FlowElement, G: nx.MultiDiGraph):

    def _add(propname, params):

        # G.nodes[flowelement.name].setdefault(propname,{}) # NOTE: do not need: graph captures params as edges
        for index, p in enumerate(params):
            pfmt = p.value.format_values()
            pname = pfmt["name"]

            # NOTE: Do not need: graph captures params as edges
            # G.nodes[flowelement.name][propname][p.name] = p.model_dump(exclude_none=True)
            G.add_edge(
                pname,
                flowelement.name,
                key=flowelement.name + "." + propname + "." + p.name,
                relation="read_input_resource_into",
                attrs=pfmt,
                reference_path=(
                    f"/{propname}/{index}/value/{pfmt['reference_type']}Reference"
                    if pfmt["kind"] == "reference"
                    else None
                ),
                reference_endpoint="source",
            )

    input_params = getattr(flowelement, "inputParameters", None)
    input_assignments = getattr(flowelement, "inputAssignments", None)

    if input_params:
        _add("inputParameters", input_params)
    if input_assignments:
        _add("inputAssignments", input_assignments)


def add_output_param_nodes_and_edges(
    flowelement: FlowElement, G: nx.MultiDiGraph, storeOutputAutomatically=False
):

    def _add(propname, params):
        # G.nodes[flowelement.name].setdefault(propname,{})
        for index, p in enumerate(params):
            if storeOutputAutomatically:
                notes = [
                    "available for reference in other flow elements (storeOutputAutomatically=true)"
                ]
            else:
                notes = []

            # G.nodes[flowelement.name][propname][p.name] = p.model_dump(exclude_none=True)

            if p.assignToReference:
                G.add_edge(
                    flowelement.name,
                    p.assignToReference,
                    key=flowelement.name + "." + propname + "." + p.name,
                    relation="assign_output_resource_to",
                    notes=notes,
                    reference_path=f"/{propname}/{index}/assignToReference",
                    reference_endpoint="target",
                )
            elif storeOutputAutomatically:
                G.add_edge(
                    flowelement.name,
                    f"{flowelement.name}.{p.name}",
                    key=flowelement.name + "." + propname + "." + p.name,
                    relation="assign_output_resource_to",
                    notes=[
                        "available for reference in other flow elements (storeOutputAutomatically=true)"
                    ],
                )
            else:
                raise ValueError(
                    f"OutputParameter {p.name} must have either assignToReference or storeOutputAutomatically=true to create an edge"
                )

    output_params = getattr(flowelement, "outputParameters", None)
    output_assignments = getattr(flowelement, "outputAssignments", None)

    if output_params:
        _add("outputParameters", output_params)
    if output_assignments:
        _add("outputAssignments", output_assignments)


def format_composite_condition(conditions, conditionLogic=None):
    return display_conditions(conditions, conditionLogic)


class FlowCondition(FlowBaseElement):
    aggregationOperator: Literal["Count"] | None = None
    # keep string to allow advanced logic like "1 AND (2 OR 3)"
    conditionLogic: str | None = None
    conditionType: FlowWaitConditionType | None = None
    conditions: list["FlowCondition"] = Field(default_factory=list)
    leftValueReference: str | None = None
    operator: FlowComparisonOperator
    rightValue: FlowElementReferenceOrValue | None = None

    @model_validator(mode="after")
    def check_conditions_or_value(self) -> Self:
        if not self.conditions and self.leftValueReference is None:
            raise PydanticCustomError(
                "flow_condition_requires_operand",
                "FlowCondition must have either conditions or leftValueReference specified",
            )
        return self

    @field_validator("rightValue", mode="before")
    def if_right_value_none(cls, value):
        if value is None:
            return FlowElementReferenceOrValue()
        return value

    def format_condition(self):
        return display_conditions([self])


class FlowElementReferenceOrValue(Metadata):
    # Apex-defined (structured) value
    apexValue: dict | None = Field(
        default=None,
        description="Structured value for an Apex-defined type (key -> primitive/reference).",
    )
    complexValue: str | None = Field(default=None)
    transformReference: str | None = Field(
        default=None,
        description="API name of a Transform resource whose output supplies the value.",
    )
    # Literal values
    booleanValue: bool | None = Field(
        default=None, description="Boolean literal value."
    )

    complexValueType: (
        Literal["JoinDefinition", "FieldReference", "ComplexObjectFieldDetails"] | None
    ) = None

    elementReference: str | None = Field(
        default=None,
        description="API name of another Flow element reference. NOTE: if specifying a value reference, do not use",
    )
    dateTimeValue: datetime | None = Field(
        default=None, description="Date/time literal value (UTC)."
    )
    dateValue: date | None = Field(default=None, description="Date literal value.")
    numberValue: float | None = Field(
        default=None, description="Numeric literal value."
    )
    stringValue: str | None = Field(default=None, description="String literal value.")

    @model_validator(mode="after")
    def only_one_value_or_reference(self) -> Self:
        non_none_count = sum(
            value is not None
            for name, value in self.__dict__.items()
            if name != "complexValueType"
        )
        if non_none_count > 1:
            raise ValueError(
                f"{self.__class__.__name__} can only have one value or reference specified"
            )
        return self

    def format_values(self):
        formatted_values = {}
        for propname, prop in self.model_dump(exclude_none=True).items():
            if propname.endswith("Type"):
                formatted_values[propname.replace("Type", "_type")] = prop
            elif propname.endswith("Value"):
                value_type = propname.replace("Value", "")
                value = prop
                formatted_values.update({
                    "kind": "literal",
                    "literal_type": value_type.lower(),
                    "value": value,
                })
            elif propname.endswith("Reference"):
                value_type = propname.replace("Reference", "")
                value = prop
                formatted_values.update({
                    "kind": "reference",
                    "reference_type": value_type.lower(),
                    "value": value,
                })

        if not formatted_values:
            formatted_values.update({
                "kind": "literal",
                "literal_type": "null",
                "value": None,
            })

        if formatted_values["kind"] == "literal":
            if formatted_values["literal_type"] == "string":
                name = "Literal[{}]".format(json.dumps(formatted_values["value"]))
            elif formatted_values["literal_type"] in [
                "number",
                "datetime",
                "date",
                "boolean",
                "null",
            ]:
                name = "Literal[{}]".format(formatted_values["value"])
            elif formatted_values["literal_type"] == "apex":
                # TODO: think about making this more standard syntax
                name = "ApexClass[{properties}]".format(
                    properties=",".join(list(formatted_values["value"].keys()))
                )
            elif formatted_values["literal_type"] == "complex":
                name = "{type}({value})".format(
                    type=formatted_values.get("complexValue_type", "complex"),
                    value=formatted_values["value"],
                )
            else:
                raise ValueError(
                    f"Unknown literal type: {formatted_values['literal_type']}"
                )
        else:
            name = formatted_values["value"]
        formatted_values = {"name": name, **formatted_values}
        return formatted_values


class FlowInputParameter(FlowBaseElement):
    """
    While not part of the Flow metadata model, many of the flow elements have the same pattern
    (action calls, screen, etc.) so
    this provides a convenient way to define input parameters
    """

    name: str
    value: FlowElementReferenceOrValue

    @field_validator("value", mode="before")
    def if_value_none(cls, value):
        if value is None:
            return FlowElementReferenceOrValue()
        return value


class FlowCustomProperty(Metadata):
    """
    Simple name/value pair used for Flow-level customProperties.
    """

    name: str
    value: FlowElementReferenceOrValue | None = None


class FlowDataTypeMapping(Metadata):
    genericType: str | None = None
    mappedObjectType: str | None = None


class FlowRecordFilter(FlowBaseElement):
    field: str
    operator: FlowComparisonOperator
    value: FlowElementReferenceOrValue

    @field_validator("value", mode="before")
    def if_value_none(cls, value):
        if value is None:
            return FlowElementReferenceOrValue()
        return value

    def to_expression(self):
        return display_conditions([self])


def add_filter_edges(node, graph):
    """Retain native read relationships independently of SQL translation."""
    object_of_fields = getattr(node, "object", None) or getattr(
        node, "inputReference", None
    )
    for index, condition in enumerate(node.filters or []):
        value = condition.value.format_values()
        graph.add_edge(
            value["name"],
            node.name,
            key=f"{node.name}.filters[{index}].value",
            relation="read_resource_into",
            attrs=value,
            reference_path=(
                f"/filters/{index}/value/{value['reference_type']}Reference"
                if value["kind"] == "reference"
                else None
            ),
            reference_endpoint="source",
            note=["`attrs` is a formatted FlowElementReferenceOrValue instance"],
        )
        name = (
            f"{object_of_fields}.{condition.field}"
            if condition.field
            else object_of_fields
        )
        graph.add_edge(
            name,
            node.name,
            key=f"{node.name}.filters[{index}]",
            relation="read_resource_into",
            source_reference=condition.field,
            reference_path=f"/filters/{index}/field",
            reference_endpoint="source",
        )


FlowElementList = RootModel[list[FlowNode | FlowElement]]


def add_condition_edges(node, graph, conditions, prefix="conditions"):
    """Record each condition input without asserting execution equivalence."""
    for index, condition in enumerate(conditions or []):
        path = f"{prefix}[{index}]"
        if condition.leftValueReference:
            graph.add_edge(
                condition.leftValueReference,
                node.name,
                key=f"{node.name}.{path}.leftValueReference",
                relation="read_condition_resource",
            )
        if condition.rightValue is not None:
            value = condition.rightValue.format_values()
            graph.add_edge(
                value["name"],
                node.name,
                key=f"{node.name}.{path}.rightValue",
                relation="read_condition_resource",
                attrs=value,
            )
        add_condition_edges(node, graph, condition.conditions, path + ".conditions")
