import re
from ...expressions import display_record
from pydantic import Field, ConfigDict
from pydantic.alias_generators import to_snake

from .base import (
    Metadata,
    FlowElementReferenceOrValue,
    FlowConnector,
    FlowNode,
    FlowCondition,
    add_connector_edges,
)
from ..types.enums import FlowAssignmentOperator, FlowCollectionProcessorType, SortOrder


__all__ = [
    "FlowCollectionProcessor",
    "FlowCollectionMapItem",
    "FlowCollectionSortOption",
]


class FlowCollectionSortOption(Metadata):
    """API v51.0+"""

    doesPutEmptyStringAndNullFirst: bool = False
    sortField: str | None = None
    sortOrder: SortOrder


class FlowCollectionMapItem(Metadata):
    assignToFieldReference: str
    operator: FlowAssignmentOperator
    value: FlowElementReferenceOrValue | None = None


class FlowCollectionProcessor(FlowNode):
    """Collection Filter / Collection Sort: Filter or reorder items in a collection."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Collection Processor",
            "description": "Filter or sort a collection (Collection Filter / Collection Sort).",
        }
    )
    connector: FlowConnector | None = None
    faultConnector: FlowConnector | None = None
    assignNextValueToReference: str | None = None
    collectionProcessorType: FlowCollectionProcessorType
    collectionReference: str
    conditionLogic: str | None = None
    conditions: list[FlowCondition]
    formula: str | None = None
    limit: int | None = None
    mapItems: list[FlowCollectionMapItem] = Field(
        default=None, description="Map items to transform collection elements."
    )
    outputSObjectType: str | None = None
    sortOptions: list[FlowCollectionSortOption] = Field(default_factory=list)

    def add_to_graph(self, graph):
        self.add_node(graph)
        graph.add_edge(
            self.collectionReference,
            self.name,
            key=self.name + ".collectionReference",
            relation="read_resource_into",
        )

        def condition_edges(conditions, prefix=""):
            for index, condition in enumerate(conditions or []):
                path = f"{prefix}[{index}]"
                condition_edges(condition.conditions, path)
                if condition.leftValueReference:
                    graph.add_edge(
                        condition.leftValueReference,
                        self.name,
                        key=f"{self.name}.conditions{path}.leftValueReference",
                        relation="read_resource_into",
                    )
                if condition.rightValue:
                    value = condition.rightValue.format_values()
                    graph.add_edge(
                        value["name"],
                        self.name,
                        key=f"{self.name}.conditions{path}.rightValue",
                        relation="read_resource_into",
                        attrs=value,
                    )

        condition_edges(self.conditions)
        if self.formula:
            for ref in re.findall(r"{![^}]+}", self.formula):
                name = ref.strip().replace(" ", "").replace("{!", "").replace("}", "")
                graph.add_edge(
                    name,
                    self.name,
                    key=self.name + ".formula." + name,
                    relation="read_resource_into",
                )
        for index, option in enumerate(self.sortOptions or []):
            if option.sortField:
                graph.add_edge(
                    f"{self.collectionReference}.{option.sortField}",
                    self.name,
                    key=f"{self.name}.sortOptions[{index}]",
                    relation="orders_by",
                )
        for index, item in enumerate(self.mapItems or []):
            value = item.value.format_values()
            graph.add_edge(
                value["name"],
                self.name,
                key=f"{self.name}.mapItems[{index}].value",
                relation="read_resource_for_mapping",
            )
            graph.add_edge(
                self.name,
                item.assignToFieldReference,
                key=f"{self.name}.mapItems[{index}].assignToReference",
                relation=to_snake(item.operator),
            )
        if self.assignNextValueToReference:
            graph.add_edge(
                self.name,
                self.assignNextValueToReference,
                key=self.name + ".assignNextValueToReference",
                relation="assign_next_value_to_reference",
            )
        graph.nodes[self.name]["expression"] = display_record(self)
        add_connector_edges(
            self, graph, connector=self.connector, fault_connector=self.faultConnector
        )
        return graph
