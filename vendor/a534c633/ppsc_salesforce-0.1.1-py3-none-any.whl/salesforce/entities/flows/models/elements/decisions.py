from pydantic import ConfigDict, Field


from .base import (
    FlowElement,
    FlowCondition,
    FlowConnector,
    FlowNode,
    add_connector_edge,
    add_condition_edges,
    format_composite_condition,
)

__all__ = ["FlowDecision", "FlowRule"]


class FlowRule(FlowElement):
    name: str
    label: str | None = None
    connector: FlowConnector | None = None
    conditionLogic: str | None = None
    conditions: list[FlowCondition] = None
    doesRequireRecordChangedToMeetCriteria: bool | None = None

    def format_conditions(self):
        if self.conditions:
            return format_composite_condition(self.conditions, self.conditionLogic)
        return None


class FlowDecision(FlowNode):
    """Decision: Branch logic by evaluating one or more condition sets."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Decision",
            "description": "Branch logic by evaluating one or more condition sets.",
        }
    )
    defaultConnector: FlowConnector | None = None
    defaultConnectorLabel: str | None = None
    rules: list[FlowRule] = Field(
        description="An array of rules for the decision. The rules are evaluated in the order that they're listed, and the connector of the first true rule is used. If no rules are true, then the default connector is used. In Flow Builder, rules are referred to as decision outcomes."
    )

    def add_to_graph(self, graph):
        # self.add_node(graph)
        # default connector as control-flow
        case_when_ = []
        self.add_node(graph)
        for i, rule in enumerate(self.rules or []):
            rule_cond = rule.format_conditions()
            rule = rule.model_copy(update={"name": self.name + "." + rule.name})
            rule.add_node(graph)
            add_condition_edges(rule, graph, rule.conditions)
            graph.add_edge(
                self.name,
                rule.name,
                key=f"{self.name}.rules[{i}]",
                relation="decision_rule_of",
            )

            if i == 0:
                if_ = f"IF {rule_cond}"
            else:
                if_ = f"ELSE IF {rule_cond}"
            if rule.connector:
                if_ += " THEN " + "({!" + rule.connector.targetReference + "})"
                add_connector_edge(
                    rule,
                    graph,
                    rule.connector,
                    connname="connector",
                    relation="navigates_if_true",
                )
            else:
                if_ += " THEN NULL"
                add_connector_edge(
                    rule,
                    graph,
                    None,
                    connname="connector",
                    relation="stop_navigation_if_true",
                    label="No Connector",
                )

            case_when_.append(if_)

            graph.nodes[rule.name]["expression"] = if_

        if self.defaultConnector:
            else_ = "ELSE " + "({!" + self.defaultConnector.targetReference + "})"
            case_when_.append(else_)
            add_connector_edge(
                self,
                graph,
                self.defaultConnector,
                connname="defaultConnector",
                relation="navigates_if_all_false",
                label=self.defaultConnectorLabel,
            )

        graph.nodes[self.name]["expression"] = "\n\t".join(case_when_)
        return graph
