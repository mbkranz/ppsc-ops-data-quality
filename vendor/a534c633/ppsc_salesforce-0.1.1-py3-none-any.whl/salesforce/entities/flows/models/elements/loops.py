import networkx as nx
from typing import Literal

from pydantic import Field,ConfigDict

from .base import FlowNode,FlowConnector, add_connector_edge


__all__ = [
    "FlowLoop"
]


class FlowLoop(FlowNode):
    """Loop: Iterate over each item in a collection variable."""
    model_config = ConfigDict(json_schema_extra={
        "title": "Loop",
        "description": "Iterate over each item in a collection variable.",
    })
    assignNextValueToReference: str | None = Field(
        default=None,
        description=(
            "The variable assigned the current value in the collection before navigating to nextValueConnector."
        ),
    )
    collectionReference: str
    iterationOrder: Literal["Asc", "Desc"]
    nextValueConnector: FlowConnector
    noMoreValuesConnector: FlowConnector

    def add_to_graph(self, graph):
        # 1) Register the loop node itself
        self.add_node(graph)

        # 2) Data lineage — the loop *reads* from the collection
        if self.collectionReference:
            graph.add_edge(
                self.collectionReference,
                self.name,
                key=self.name+".collectionReference",
                relation="reads_collection"
            )

        if self.assignNextValueToReference:
            graph.add_edge(
                self.name,
                self.assignNextValueToReference,
                key=self.name+".assignNextValueToReference",
                relation="assigns_collection_next_value_to_reference"
            )

        # 3) Control-flow connectors
        # These should always point to the targetReference of the connector
        if isinstance(self.nextValueConnector, FlowConnector):
            add_connector_edge(
                self,
                graph,
                self.nextValueConnector,
                connname="nextValueConnector",
                relation="navigates_to_collection_next_value"
            )
        if isinstance(self.noMoreValuesConnector, FlowConnector):
            add_connector_edge(
                self,
                graph,
                self.noMoreValuesConnector,
                connname="noMoreValuesConnector",
                relation="navigates_to_if_no_more_values"
            )

        return graph
