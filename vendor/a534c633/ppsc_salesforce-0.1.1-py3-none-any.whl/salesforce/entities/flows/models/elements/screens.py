from __future__ import annotations
import re

import networkx as nx
from typing import Any, Literal
from pydantic import ConfigDict,Field
from pydantic.alias_generators import to_snake


from .base import Metadata,FlowCondition,FlowElement,FlowConnector, FlowInputParameter,FlowNode,FlowElementReferenceOrValue, add_connector_edge, add_input_param_nodes_and_edges, add_output_param_nodes_and_edges
from ..types.enums import FlowDataType, FlowRegionContainerType, FlowScreenFieldInputsRevisited,FlowScreenFieldType


__all__ = [
    "FlowInputValidationRule",
    "FlowScreenActionInputParameter",
    "FlowScreenAction",
    "FlowScreenFieldInputParameter",
    "FlowScreenFieldOutputParameter",
    "FlowScreenFieldStyleProperties",
    "FlowScreenTriggerHandler",
    "FlowScreenTrigger",
    "FlowVisibilityRule",
    "FlowScreenField",
    "FlowScreen"
]


class FlowInputValidationRule(Metadata):
    """ Used to validate the user input of a screen field. """
    errorMessage: str
    formulaExpression: str

class FlowScreenActionInputParameter(FlowInputParameter):
    pass

class FlowScreenAction(Metadata):
    actionName: str
    actionType: list[None]  # InvocableActionType (placeholder per current code)
    inputParameters: list[FlowScreenActionInputParameter]
    label: str
    nameSegment: str | None = None
    versionSegment: int | None = None
    versionString: str | None = None  # v63.0+

class FlowScreenFieldInputParameter(Metadata):
    name: str
    value: FlowElementReferenceOrValue | None = None

class FlowScreenFieldOutputParameter(Metadata):
    assignToReference: str
    name: str

class FlowScreenFieldStyleProperties(Metadata):
    width: FlowElementReferenceOrValue | None = None  # 1..12
    verticalAlignment: FlowElementReferenceOrValue | None = None  # top|middle|bottom

class FlowScreenTriggerHandler(Metadata):
    conditions: list[FlowCondition]   # v63.0+
    conditionLogic: str | None = None
    initBehavior: Literal["runOnLoad", "runOnRevisit"] | None = None  # v64.0+
    screenActionName: str

class FlowScreenTrigger(Metadata):
    eventName: str
    eventSource: str
    handlers: list[FlowScreenTriggerHandler]

# Visibility rule

# Visibility rule
class FlowVisibilityRule(Metadata):
    conditionLogic: str = Field(description="Logical expression: and/or or advanced (e.g. 1 AND (2 OR 3))")
    conditions: list[FlowCondition]

    
class FlowScreenField(FlowElement):
    choiceReferences: list[str] | None = None
    dataType: FlowDataType | None = None
    dataTypeMappings: list[dict] | None = None
    defaultSelectedChoiceReference: str | None = None
    defaultValue: FlowElementReferenceOrValue | None = None
    extensionName: str | None = None
    fields: list["FlowScreenField"] | None = None # sections/columns
    fieldText: str | None = None
    fieldType: FlowScreenFieldType
    helpText: str | None = None
    inputParameters: list[FlowScreenFieldInputParameter]
    inputsOnNextNavToAssocScrn: FlowScreenFieldInputsRevisited | None = None  # noqa: F821
    isRequired: bool | None = None
    isVisible: bool | None = None
    objectFieldReference: str | None = None
    outputParameters: list[FlowScreenFieldOutputParameter]
    regionContainerType: FlowRegionContainerType | None = None
    scale: int | None = None
    sourceTemplateApiName: str | None = None     # v62.0+
    sourceTemplateProviderType: str | None = None  # v62.0+
    storeOutputAutomatically: bool | None = None
    styleProperties: FlowScreenFieldStyleProperties | None = None  # v64.0+
    validationRule: FlowInputValidationRule | None = None           # FlowInputValidationRule – model elsewhere if you have it
    visibilityRule: FlowVisibilityRule | None = None           # FlowVisibilityRule – model elsewhere if you have it
   #TODO: each screen field is a flow element which should be given flow element
        # defaultValue (if present)
    def add_to_graph(self, graph, parent_node_path):
        parent_node_name = parent_node_path.strip(".")[-1]
        fld = self
        
        if fld.name is None:

            node_name = parent_node_path + "." + fld.fieldType
            
        else:
            node_name = fld.name
        
        self.add_node(graph, name=node_name)
        graph.add_edge(parent_node_path,node_name,key=parent_node_path + "." + node_name,relation="field_contained_within")
            # Debugging prints for specific properties
        if fld.sourceTemplateApiName:

            # TODO: check if anything else needed for source template
            graph.add_edge(fld.sourceTemplateApiName,fld.name,
                           key=parent_node_path + "." + node_name+".sourceTemplateApiName",
                           relation=":get_source_template",notes=["TODO: need to map to source template"])
        
        if fld.validationRule:
                expr = fld.validationRule.formulaExpression
                refs = re.findall(r"{![^}]+}",expr)  # -> ['ListVar[2].Child[Idx].Name', 'Account.Id', ...']
                for ref in refs:
                    ref_name = ref.strip().replace(" ","").replace("{!","").replace("}","")
                    graph.add_edge(ref_name, self.name,
                                key=parent_node_path + "." + node_name+".validationRule.{ref}".format(ref=ref_name),
                                relation="get_references",
                                    
                    )
                graph.nodes[node_name]["expression"] = {to_snake(propname):value for propname,value in fld.validationRule.model_dump(exclude_none=True).items()}

        if fld.extensionName:

            graph.add_edge(
                fld.extensionName,
                node_name,
                key=parent_node_path + "." + node_name+".extensionName",
                relation="invokes_user_interface_component")
            graph.nodes[fld.extensionName]["notes"] = ["TODO: need to map to lightning component"]

        if fld.objectFieldReference:
            graph.add_edge(fld.objectFieldReference,node_name,
                           key=parent_node_path + "." + node_name+".objectFieldReference",
                           relation="get_object_field_reference",
                           notes=["TODO: need to map to object field reference"])
            # print(f"objectFieldReference: {fld.objectFieldReference}")

        if fld.defaultValue is not None:
            fv = fld.defaultValue.format_values()
            graph.add_edge(
                fv["name"],
                node_name,
                key=parent_node_path + "." + node_name+".defaultValue",
                relation="map_default_value",
                attrs=fv,
            )

        if fld.defaultSelectedChoiceReference is not None:
            graph.add_edge(
                fld.defaultSelectedChoiceReference,
                node_name,
                key=parent_node_path + "." + node_name+".defaultSelectedChoiceReference",
                relation="map_default_reference",
            )
        if fld.inputParameters:
            add_input_param_nodes_and_edges(fld, graph)

        if fld.objectFieldReference:
            graph.add_edge(
                fld.objectFieldReference,
                node_name,
                key=parent_node_path + "." + node_name+".objectFieldReference",
                relation="get_object_field_reference",
                notes=["TODO: need to map to object field reference"])

        if fld.outputParameters:
            add_output_param_nodes_and_edges(fld, graph, storeOutputAutomatically=fld.storeOutputAutomatically)

        if fld.fields:
            for subfld in fld.fields:
                subfld.add_to_graph(graph,parent_node_path=parent_node_path+"."+node_name)
            # print(f"fields: {fld.fields}")


class FlowScreen(FlowNode):
    """Screen: Display info and collect user input (only in screen flows)."""
    model_config = ConfigDict(json_schema_extra={
        "title": "Screen",
        "description": "Display info and collect user input (only in screen flows).",
    })
    actions: list[FlowScreenAction]
    allowBack: bool = True
    allowFinish: bool = True
    allowPause: bool = True
    backButtonLabel: str | None = None
    connector: FlowConnector | None = None
    fields: list[FlowScreenField] | None = None
    helpText: str | None = None
    nextOrFinishButtonLabel: str | None = None
    pauseButtonLabel: str | None = None
    pausedText: str | None = None
    rules: list[None] = None # reserved for future use
    showFooter: bool = True
    showHeader: bool = True
    #stageReference: FlowElementReferenceOrValue | None = None
    stageReference: Literal[None] = None # not in data but in docs
    triggers: list[None] = None  # in docs and defined here as FlowScreenTrigger but set to None as not in any current flows
    elementSubType: Literal[None] = None # not in docs but was in data
    def add_to_graph(self, graph):
        # --- Screen (flow element instance) ------------------------------------
        self.add_node(graph)

        for i, action in enumerate(self.actions or []):
            raise NotImplementedError("Action handling not implemented as none of the current flows have screen actions.")
        
        for fld in (self.fields or []):
            fld.add_to_graph(graph, parent_node_path=self.name)

        if self.connector:
            add_connector_edge(self, graph, self.connector,connname="connector")

        return graph
