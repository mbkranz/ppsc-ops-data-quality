
from pydantic import Field


from .base import Metadata,FlowCondition,FlowElement,FlowElementReferenceOrValue, FlowInputParameter, add_input_param_nodes_and_edges, add_output_param_nodes_and_edges
from ..types.enums import FlowStageStepAssigneeType,InvocableActionType


__all__ = [
    "FlowStageStepAssignee",
    "FlowStageStepEntryActionInputParameter",
    "FlowStageStepEntryActionOutputParameter",
    "FlowStageStepExitActionInputParameter",
    "FlowStageStepExitActionOutputParameter",
    "FlowStageStepInputParameter",
    "FlowStageStepOutputParameter",
    "FlowStageStep",
    "FlowStage"
]


class FlowStageStepAssignee(Metadata):
    assignee: FlowElementReferenceOrValue | None = None
    assigneeType: FlowStageStepAssigneeType

class FlowStageStepEntryActionInputParameter(FlowInputParameter):
    pass

class FlowStageStepEntryActionOutputParameter(Metadata):
    assignToReference: str | None = None  # reserved
    name: str  # e.g., "isOrchestrationConditionMet"

class FlowStageStepExitActionInputParameter(FlowInputParameter):
    pass

class FlowStageStepExitActionOutputParameter(Metadata):
    assignToReference: str | None = None  # reserved
    name: str  # "isOrchestrationConditionMet"

class FlowStageStepInputParameter(FlowInputParameter):
    pass

class FlowStageStepOutputParameter(Metadata):
    assignToReference: str | None = None  # reserved
    name: str

class FlowStageStep(Metadata):
    actionName: str
    actionType: InvocableActionType
    assignees: list[FlowStageStepAssignee] = Field(default_factory=list)
    entryActionInputParameters: list[FlowStageStepEntryActionInputParameter] = Field(default_factory=list)
    entryActionName: str | None = None
    entryActionOutputParameters: list[FlowStageStepEntryActionOutputParameter] = Field(default_factory=list)
    entryActionType: InvocableActionType | None = None  # "EvaluationFlow" or "exploreConversation"
    entryConditionLogic: str | None = None
    entryConditions: list[FlowCondition] = Field(default_factory=list)
    exitActionInputParameters: list[FlowStageStepExitActionInputParameter] = Field(default_factory=list)
    exitActionName: str | None = None
    exitActionOutputParameters: list[FlowStageStepExitActionOutputParameter] = Field(default_factory=list)
    exitActionType: InvocableActionType | None = None   # "EvaluationFlow" or "exploreConversation"
    exitConditionLogic: str | None = None
    exitConditions: list[FlowCondition] = Field(default_factory=list)
    inputParameters: list[FlowStageStepInputParameter] = Field(default_factory=list)
    label: str
    # outputConfigParams: list[FlowStageStepOutputConfigParam] = Field(default_factory=list)
    outputParameters: list[FlowStageStepOutputParameter] = Field(default_factory=list)
    requiresAsyncProcessing: bool | None = None
    shouldLock: bool | None = None
    stepSubtype: str | None = None  # reserved/internal


class FlowStage(FlowElement):
    isActive: bool | None = None
    label: str | None = None
    stageOrder: int | None = None
    steps: list[FlowStageStep] | None = None

    def add_to_graph(self,graph):

        self.add_node(graph)

         # steps
        if self.steps:
            graph.add_node(f"{self.name}.steps")
            graph.add_edge(self.name,f"{self.name}.steps", relation=self.__class__.__name__+".steps:propertyOf:"+self.__class__.__name__)
            for i, step in enumerate(self.steps):
                step.add_node(graph,name=f"{self.name}.steps[{i}]")
                if i == 0:
                    graph.add_edge(
                        f"{self.name}.steps", f"{self.name}.steps[{i}]",
                        relation=step.__class__.__name__+":start_iteration")

                for param in self.inputParameters:
                    add_input_param_nodes_and_edges(step, graph)

                for param in self.outputParameters:
                    add_output_param_nodes_and_edges(step, graph)


        return graph


