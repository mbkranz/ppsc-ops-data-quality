from pydantic import Field, ConfigDict


from .base import (
    FlowBaseElement,
    FlowConnector,
    FlowInputParameter,
    FlowNode,
    add_output_param_nodes_and_edges,
    add_input_param_nodes_and_edges,
    add_connector_edge,
)


__all__ = ["FlowSubFlowInputAssignment", "FlowSubFlowOutputAssignment", "FlowSubFlow"]


class FlowSubFlowInputAssignment(FlowInputParameter):
    """
    Assigns an element or value from the parent flow to a variable in the referenced flow. Input assignments occur when the subflow calls the referenced flow. It extends FlowBaseElement and inherits all its fields. It’s available in API version 25.0 and later.
    """

    pass


class FlowSubFlowOutputAssignment(FlowBaseElement):
    name: str = Field(description="Name of output variable within this subflow")
    assignToReference: str | None = Field(
        default=None,
        description="Unique API name to reference in the outer/parent flow in which the subflow is a part of so one can reference in overall parent Flow.",
    )


class FlowSubFlow(FlowNode):
    """Subflow: Call another autolaunched/screen flow and leverage its inputs/outputs."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Subflow",
            "description": "Call another autolaunched/screen flow and leverage its inputs/outputs.",
        }
    )
    connector: FlowConnector | None = None
    faultConnector: FlowConnector | None = None
    flowName: str = Field(description="Flow API Name to reference and call at run time")
    inputAssignments: list[FlowSubFlowInputAssignment]
    outputAssignments: list[FlowSubFlowOutputAssignment]
    storeOutputAutomatically: bool | None = None

    def add_to_graph(self, graph):

        name = self.name
        self.add_node(graph)
        graph.add_edge(
            name, self.flowName, key=name + ".flowName", relation="invokes_subflow"
        )

        # input assignments → reads_resource using formatted_values()
        if self.inputAssignments:
            add_input_param_nodes_and_edges(self, graph)

        # output assignments with two-edge pattern
        if self.outputAssignments:
            add_output_param_nodes_and_edges(self, graph)

        # connectors
        if self.connector:
            add_connector_edge(self, graph, self.connector, connname="connector")
        if self.faultConnector:
            add_connector_edge(
                self, graph, self.faultConnector, connname="faultConnector"
            )

        return graph
