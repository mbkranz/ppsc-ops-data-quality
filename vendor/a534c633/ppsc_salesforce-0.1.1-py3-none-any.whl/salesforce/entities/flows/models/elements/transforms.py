from typing import Literal

from pydantic import ConfigDict, Field

from .base import (
    Metadata,
    FlowElement,
    FlowElementReferenceOrValue,
    FlowInputParameter,
    FlowNode,
    FlowConnector,
)
from ...contract import EdgeType, NodeKind
from ..types.enums import (
    InvocableActionType,
    FlowTransformValueActionType,
    FlowTransformDataType,
)


__all__ = [
    "FlowTransformValueActionInputParameter",
    "FlowTransformValueAction",
    "FlowTransformValue",
    "FlowTransform",
]


class FlowTransformValueActionInputParameter(FlowInputParameter):
    name: Literal["aggregationField", "aggregationValues"]


class FlowTransformValueAction(Metadata):
    actionName: str | None = Field(default=None, description="Reserved for future use.")
    actionType: InvocableActionType | None = Field(
        default=None, description="Reserved for future use."
    )
    actionVersionString: str | None = Field(
        default=None, description="Reserved for future use."
    )
    assignToReference: str | None = Field(
        default=None, description="Reserved for future use."
    )
    inputParameters: list[FlowTransformValueActionInputParameter]
    outputFieldApiName: str | None = Field(
        default=None, description="Target data field"
    )
    transformType: FlowTransformValueActionType
    value: FlowElementReferenceOrValue | None = None


class FlowTransformValue(FlowElement):
    transformValueActions: list[FlowTransformValueAction]
    transformValueName: str | None = Field(
        default=None, description="Reserved for future use."
    )
    transformValueLabel: str | None = Field(
        default=None, description="Reserved for future use."
    )
    transformValueDescription: str | None = Field(
        default=None, description="Reserved for future use."
    )


class FlowTransform(FlowNode):
    """Transform: Collection/data shaping element (Count, Map, Join, Sum, etc.)."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Transform",
            "description": "Collection/data shaping element (Count, Map, Join, Sum, etc.).",
        }
    )
    apexClass: str | None = None
    connector: FlowConnector
    dataType: FlowTransformDataType
    isCollection: bool = False
    objectType: str | None = None
    scale: int | None = Field(default=None, ge=0, le=17)
    storeOutputAutomatically: bool = False
    transformValues: list[FlowTransformValue]

    def add_to_graph(self, graph):

        transform_name = self.name
        graph.add_node(transform_name)

        # --- inputs & outputs from transformValues
        transform_values = self.transformValues or []
        for transform_value in transform_values:
            transform_value_name = transform_value.transformValueName

            actions = transform_value.transformValueActions or []
            for action in actions:
                transform_type = action.transformType
                output_field_name = action.outputFieldApiName

                # 1) primary source: action.value (formatted_values)
                if action.value:
                    fv = action.value.format_values()
                    graph.add_edge(
                        fv.pop("name"),
                        transform_name,
                        edge_type=EdgeType.reads_resource.value,
                        path="transformValueAction.value",
                        outputField=output_field_name,
                        transformType=transform_type,
                        transformValueName=transform_value_name,
                        **fv,
                    )

                # 2) inputParameters sources with two-edge pattern
                for input_parameter in action.inputParameters or []:
                    input_parameter_name = input_parameter.name
                    if input_parameter.value:
                        param_name = NodeKind.Parameter.to_tagged_name(
                            f"{self.name}.{input_parameter_name}"
                        )
                        fv = input_parameter.value.format_values()
                        src = fv.pop("name")

                        # Edge 1: value/reference -> parameter (reads_resource)
                        graph.add_edge(
                            src,
                            param_name,
                            edge_type=EdgeType.reads_resource.value,
                            param_name=input_parameter_name,
                            **fv,
                        )

                        # Parameter node
                        graph.add_node(
                            param_name,
                            node_kind=NodeKind.Parameter.value,
                            parameter_kind="input",
                            name=input_parameter_name,
                        )

                        # Edge 2: parameter -> node (maps_input)
                        graph.add_edge(
                            param_name,
                            transform_name,
                            edge_type=EdgeType.maps_input.value,
                            param_name=input_parameter_name,
                            outputField=output_field_name,
                            transformType=transform_type,
                            transformValueName=transform_value_name,
                        )

                # 3) output: FlowTransform → synthetic per-field node
                if output_field_name:
                    output_node_name = f"{transform_name}.{output_field_name}"
                    graph.add_edge(
                        transform_name,
                        output_node_name,
                        type="outputField",
                        transformType=transform_type,
                        transformValueName=transform_value_name,
                    )

        # --- connector (execution)
        if self.connector and self.connector.targetReference:
            graph.add_edge(
                transform_name, self.connector.targetReference, type="connector"
            )

        # attach remaining, truthy attributes to the transform node
        graph.add_node(
            transform_name,
            **self.model_dump(
                exclude=["transformValues", "connector"], exclude_none=True
            ),
        )

        return graph
