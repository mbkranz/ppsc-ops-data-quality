import json
import re

from pydantic import Field, ConfigDict, field_validator

from .base import FlowElement, FlowElementReferenceOrValue
from ..types.enums import FlowDataType, SortOrder

__all__ = [
    "FlowChoice",
    "FlowConstant",
    "FlowFormula",
    "FlowVariable",
    "FlowTextTemplate",
    "FlowDynamicChoiceSet",
]


class FlowDynamicChoiceSet(FlowElement):
    """
    Covers Record Choice Sets, Picklist Choice Sets, and collection-based choice sets.
    The object fields here are kept flexible across API versions.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Dynamic Choice Set",
            "description": "Record / Picklist / Collection Choice Set generating runtime choices.",
        }
    )
    label: str | None = None
    dataType: FlowDataType | None = None
    object: str | None = None
    displayField: str | None = None
    valueField: str | None = None
    picklistObject: str | None = None
    picklistField: str | None = None
    collectionReference: str | None = None
    sortField: str | None = None
    sortOrder: SortOrder | None = None
    filterLogic: str | None = None
    filters: list[dict] | None = None
    limit: int | None = None

    def add_to_graph(self, graph):
        self.add_node(graph)

        return graph


class FlowTextTemplate(FlowElement):
    """Text Template: Reusable chunk of text (can include merge fields) for screens, emails, logs."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Text Template",
            "description": "Reusable chunk of text (can include merge fields) for screens, emails, logs.",
        }
    )
    isViewedAsPlainText: bool = Field(default=False)
    text: str = Field(description="The text content of the template.")

    def add_to_graph(self, graph):
        self.add_node(graph)

        return graph


# Variable
class FlowVariable(FlowElement):
    """Variable / Record / Collection Variable: Stores a single value or collection (primitive or sObject)."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Variable",
            "description": "Stores a single value (text, number, date, boolean, record, Apex-defined, etc.) or collection thereof.",
        }
    )
    apexClass: str | None = None
    dataType: FlowDataType | None = None
    isCollection: bool = False
    isInput: bool = Field(
        default=False,
        description="""
        Indicates whether the variable can be set at the start of the flow using URL parameters, Visualforce controllers, or subflow inputs. This field is available in API version 25.0 and later.


        Default value:

        False for a variable created in API version 25.0 and later or in the Flow Builder in Summer ’12 and later.
        True for a variable created in API version 24.0 or in Flow Builder in Spring ’12 and earlier.
        Disabling input or output access for an existing variable can break the functionality of applications and pages that call the flow and access the variable. For example, you can access variables from URL parameters, processes, and other flows.
    """,
    )
    isOutput: bool = Field(
        default=False,
        description="""
        Indicates whether the variable’s value can be accessed from Visualforce controllers and other flows. This field is available in API version 25.0 and later.

                                
        Default value:

        False for a variable created in API version 25.0 and later or in the Flow Builder in Summer ’12 and later.
        True for a variable created in API version 24.0 or in Flow Builder in Spring ’12 and earlier.
        Disabling input or output access for an existing variable can break the functionality of applications and pages that call the flow and access the variable. For example, you can access variables from URL parameters, processes, and other flows.

    """,
    )
    objectType: str | None = None
    scale: int | None = None
    value: FlowElementReferenceOrValue | None = Field(default=None)

    @field_validator("value", mode="after")
    def add_none(cls, value):
        if value is None:
            return FlowElementReferenceOrValue()
        return value

    def add_to_graph(self, graph):
        self.add_node(graph)

        if self.apexClass:
            graph.add_edge(
                self.name,
                self.apexClass,
                key=self.name + ".apexClass",
                relation="assign_callable_as",
            )

        value = self.value.format_values()
        graph.add_edge(
            value["name"],
            self.name,
            key=self.name + ".value",
            relation="define_variable_as",
        )

        graph.nodes[self.name]["expression"] = (
            f"{self.name} {self.dataType} := {value['value']}"
        )
        return graph


# Constant
class FlowConstant(FlowElement):
    """Constant: Immutable value defined once and reused."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Constant",
            "description": "Immutable value defined once and reused.",
        }
    )
    dataType: FlowDataType
    value: FlowElementReferenceOrValue

    @field_validator("value", mode="after")
    def add_none(cls, value):
        if value is None:
            return FlowElementReferenceOrValue()

        return value

    def add_to_graph(self, graph):
        self.add_node(graph)
        value = self.value.format_values()
        graph.add_edge(
            value["name"],
            self.name,
            key=self.name + ".value",
            relation="define_constant_as",
            attrs=value,
        )

        graph.nodes[self.name]["expression"] = (
            f"{self.name} CONSTANT {self.dataType} := {value['value']}"
        )
        return graph


# Formula
class FlowFormula(FlowElement):
    """Formula: Real-time calculated value based on an expression referencing other resources and globals."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Formula",
            "description": "Real-time calculated value from an expression.",
        }
    )
    dataType: FlowDataType
    expression: str = Field(description="Formula expression text")

    def add_to_graph(self, graph):
        self.add_node(graph)
        refs = re.findall(
            r"{![^}]+}", self.expression
        )  # -> ['ListVar[2].Child[Idx].Name', 'Account.Id', ...]
        ref_names = []
        for ref in refs:
            ref_name = ref.strip().replace(" ", "").replace("{!", "").replace("}", "")

            ref_names.append(ref_name)
            graph.add_edge(
                ref_name,
                self.name,
                key=self.name + ".formula.{ref}".format(ref=ref_name),
                relation="get_formula_references",
                note="Edges remove the $ designating current context",
            )

        graph.nodes[self.name]["expression"] = self.expression

        return graph


# ---------- Choice/Dynamic Choice/Custom Property ----------
class FlowChoice(FlowElement):
    """
    Generic Choice model usable for Screen choice sets.
    Keeps flexible to accommodate both simple and extended choice metadata.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Choice",
            "description": "Manually defined selectable option for Screen components.",
        }
    )
    choiceText: str  # label presented to user
    value: FlowElementReferenceOrValue | None = None  # stored value
    dataType: FlowDataType | None = None
    description: str | None = None
    isVisible: bool | None = None

    @field_validator("value", mode="after")
    def add_none(cls, value):
        if value is None:
            return FlowElementReferenceOrValue()

        return value

    def add_to_graph(self, graph):
        self.add_node(graph)
        fmt_values = self.value.format_values()
        fmt_values["label"] = self.choiceText
        fmt_values["description"] = self.description
        graph.add_edge(
            fmt_values["name"],
            self.name,
            key=self.name + ".value",
            relation="define_choice_as",
            attrs=fmt_values,
        )
        graph.nodes[self.name]["expression"] = json.dumps(fmt_values)
        return graph
