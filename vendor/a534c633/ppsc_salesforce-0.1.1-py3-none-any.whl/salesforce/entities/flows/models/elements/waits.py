from datetime import time
from typing import Literal
from pydantic import ConfigDict


from .base import (
    Metadata,
    FlowInputParameter,
    FlowRecordFilter,
    FlowCondition,
    FlowElement,
    FlowConnector,
    FlowNode,
)
from ...contract import EdgeType, NodeKind
from ..types.enums import (
    FlowWaitInteractionType,
    InvocableActionType,
    FlowScheduledPathOffsetUnit,
    RecordTriggerType,
)


__all__ = [
    "FlowWait",
    "FlowWaitEvent",
    "FlowWaitEventInputParameter",
    "FlowWaitEventOutputParameter",
]


class FlowWaitEventInputParameter(FlowInputParameter):
    pass


class FlowWaitEventOutputParameter(Metadata):
    assignToReference: str
    name: str


class FlowWaitEvent(FlowElement):
    """Wait Event: Component of a Wait; resumes flow based on time or event criteria."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Wait Event",
            "description": "Component of a Wait; resumes flow based on time or event criteria.",
        }
    )
    conditionLogic: str | None = None
    associatedElement: str | None = None
    conditions: list[FlowCondition]
    automationEventName: str | None = None
    automationEventType: InvocableActionType | None = None
    connector: FlowConnector | None = None
    eventType: Literal["AlarmEvent", "DateRefAlarmEvent"]
    extendUntil: time | None = None
    filters: list[FlowRecordFilter]
    filterLogic: str | None = None
    inputParameters: list[FlowWaitEventInputParameter]
    interactionType: FlowWaitInteractionType | None = None
    label: str
    object: str | None = None
    offset: int | None = None
    offsetUnit: FlowScheduledPathOffsetUnit | None = None
    outputParameters: list[FlowWaitEventOutputParameter]
    recordTriggerType: RecordTriggerType | None = None


class FlowWait(FlowNode):
    """Wait: Resume when time-based or event criteria are met (declarative wait point)."""

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Wait",
            "description": "Resume when time-based or event criteria are met (declarative wait point).",
        }
    )
    defaultConnector: FlowConnector
    defaultConnectorLabel: str
    faultConnector: FlowConnector | None = None
    timeZoneId: str | None = None
    waitEvents: list[FlowWaitEvent]

    def add_to_graph(self, graph):

        name = self.name
        graph.add_node(name)

        # connectors
        if self.defaultConnector:
            graph.add_edge(
                name,
                self.defaultConnector.targetReference,
                edge_type=EdgeType.navigates_to.value,
                path="defaultConnector",
            )

        if self.faultConnector:
            graph.add_edge(
                name,
                self.faultConnector.targetReference,
                edge_type=EdgeType.navigates_to.value,
                path="faultConnector",
            )

        # wait events
        wait_events = self.waitEvents or []
        if wait_events:
            for event in wait_events:
                # lineage for event inputs with two-edge pattern
                for inp in event.inputParameters or []:
                    param_name = NodeKind.Parameter.to_tagged_name(
                        f"{self.name}.{inp.name}"
                    )
                    fv = (
                        inp.value.format_values()
                        if inp.value
                        else {"name": "Literal[null]", "value": None, "type": None}
                    )
                    src = fv.pop("name")

                    # Edge 1: value/reference -> parameter (reads_resource)
                    graph.add_edge(
                        src,
                        param_name,
                        edge_type=EdgeType.reads_resource.value,
                        param_name=inp.name,
                        **fv,
                    )

                    # Parameter node
                    graph.add_node(
                        param_name,
                        node_kind=NodeKind.Parameter.value,
                        parameter_kind="input",
                        name=inp.name,
                    )

                    # Edge 2: parameter -> node (maps_input)
                    graph.add_edge(
                        param_name,
                        name,
                        edge_type=EdgeType.maps_input.value,
                        param_name=inp.name,
                    )

                # outputs with two-edge pattern
                for outp in event.outputParameters or []:
                    if outp.assignToReference:
                        param_name = NodeKind.Parameter.to_tagged_name(
                            f"{self.name}.{outp.name}"
                        )

                        # Parameter node
                        graph.add_node(
                            param_name,
                            node_kind=NodeKind.Parameter.value,
                            parameter_kind="output",
                            name=outp.name,
                        )

                        # Edge 1: node -> parameter (maps_output)
                        graph.add_edge(
                            name,
                            param_name,
                            edge_type=EdgeType.maps_output.value,
                            param_name=outp.name,
                        )

                        # Edge 2: parameter -> assignToReference (writes_resource)
                        graph.add_edge(
                            param_name,
                            outp.assignToReference,
                            edge_type=EdgeType.writes_resource.value,
                            param_name=outp.name,
                        )

                # connector
                if event.connector:
                    graph.add_edge(
                        name,
                        event.connector.targetReference,
                        edge_type=EdgeType.navigates_to.value,
                        path="waitEvents",
                    )

        graph.add_node(
            name,
            **self.model_dump(
                exclude=["defaultConnector", "faultConnector", "waitEvents"],
                exclude_none=True,
            ),
        )

        return graph
