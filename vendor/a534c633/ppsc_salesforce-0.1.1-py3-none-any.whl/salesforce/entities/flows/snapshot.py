"""Saved Flow inputs, active-version selection, and acquisition coverage."""

from dataclasses import dataclass, field
import hashlib
import json
from pathlib import Path
from typing import TYPE_CHECKING

import pyarrow.parquet as pq
from salesforce.client import query_records
from .api import validate_flow_id

if TYPE_CHECKING:
    from .models import FlowRecord


@dataclass(frozen=True)
class SelectedFlow:
    source_path: str
    raw: dict
    model: "FlowRecord"


@dataclass(frozen=True)
class FlowSnapshot:
    records: list[tuple[str, dict]]
    selected: list[SelectedFlow]
    sources: dict = field(default_factory=dict)
    coverage: dict = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    objects: set[str] = field(default_factory=set)
    fields: set[tuple[str, str]] = field(default_factory=set)
    relationships: dict[tuple[str, str], tuple[str, ...]] = field(default_factory=dict)


SOURCE_NAMES = (
    "Flow.json",
    "objects.parquet",
    "fields.parquet",
    "flow-report.json",
    "datamodel-report.json",
)
ACCESS_ERRORS = {"INSUFFICIENT_ACCESS", "INSUFFICIENT_ACCESS_OR_READONLY"}


def source_descriptors(export_dir):
    descriptors = {}
    for name in SOURCE_NAMES:
        path = export_dir / name
        with path.open("rb") as stream:
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
        descriptors[name] = {"sha256": digest, "size": path.stat().st_size}
    return descriptors


def validate_coverage(export_dir, records):
    """Validate published sources while retaining supported acquisition omissions."""
    reports = {}
    warnings = []
    for name in ("flow", "datamodel"):
        report = json.loads((export_dir / f"{name}-report.json").read_text())
        if report.get("outputs_published") is not True:
            raise ValueError(f"{name} report does not describe published outputs")
        if not isinstance(report.get("coverage_complete"), bool):
            raise ValueError(f"{name} report requires a coverage_complete boolean")
        reports[name] = report
        if not report["coverage_complete"]:
            warnings.append(
                f"{name}: source coverage is incomplete; see coverage report"
            )
    flow = reports["flow"]
    pending = flow.get("pending", [])
    failures = flow.get("failed", {})
    ids = {raw["Id"] for _, raw in records}
    if (
        type(flow.get("completed")) is not int
        or type(flow.get("selected")) is not int
        or flow.get("completed") != len(records)
        or flow.get("selected") != len(records) + len(pending)
        or len(set(pending)) != len(pending)
        or ids.intersection(pending)
        or set(pending) != set(failures)
        or flow["coverage_complete"] != (not pending)
    ):
        raise ValueError("Flow coverage report does not match the exported versions")
    for flow_id, failure in sorted(failures.items()):
        details = failure.get("details", [])
        if (
            failure.get("status") not in (400, 403)
            or not details
            or any(item.get("errorCode") not in ACCESS_ERRORS for item in details)
        ):
            raise ValueError(f"Unexplained Flow acquisition failure: {flow_id}")
    model = reports["datamodel"]
    omissions = any(
        model.get(key) for key in ("unresolved", "unavailable_field_properties")
    )
    if model.get("failed") or model.get("pending"):
        raise ValueError("Data-model acquisition has unfinished operational failures")
    if model["coverage_complete"] == omissions:
        raise ValueError("Data-model coverage flag conflicts with reported omissions")
    if type(model.get("completed")) is not int:
        raise ValueError("Data-model completed count must be an integer")
    return reports, warnings


def read_catalogs(export_dir):
    objects = pq.read_table(
        export_dir / "objects.parquet", columns=["QualifiedApiName"]
    )
    names = pq.read_schema(export_dir / "fields.parquet").names
    columns = ["EntityDefinition.QualifiedApiName", "FieldDefinition.QualifiedApiName"]
    columns.extend(
        name
        for name in ("FieldDefinition.RelationshipName", "FieldDefinition.ReferenceTo")
        if name in names
    )
    fields = pq.read_table(export_dir / "fields.parquet", columns=columns)
    object_names = set(objects.column(0).to_pylist())
    field_names = {
        (
            row["EntityDefinition.QualifiedApiName"],
            row["FieldDefinition.QualifiedApiName"],
        )
        for row in fields.to_pylist()
    }
    if any(not isinstance(name, str) or not name for name in object_names) or any(
        not isinstance(name, str) or not name
        for identity in field_names
        for name in identity
    ):
        raise ValueError("Catalog names must be nonempty API names")
    relationships = {}
    for row in fields.to_pylist():
        name = row.get("FieldDefinition.RelationshipName")
        targets = row.get("FieldDefinition.ReferenceTo") or {}
        if name and isinstance(targets, dict):
            target_names = targets.get("referenceTo") or []
            if not isinstance(target_names, list) or any(
                not isinstance(target, str) for target in target_names
            ):
                raise ValueError("Relationship targets must be API name lists")
            key = (row["EntityDefinition.QualifiedApiName"], name)
            relationships[key] = tuple(
                sorted(set(relationships.get(key, ())) | set(target_names))
            )
    return object_names, field_names, relationships


def read_flow_records(filepath):
    """Read saved query pages, retaining each record's JSON Pointer for evidence."""
    payload = json.loads(Path(filepath).read_text(encoding="utf-8"))
    if not isinstance(payload, list):
        raise ValueError("Flow export must be a list of query pages")
    records = []
    identifiers = set()
    for page_index, page in enumerate(payload):
        for record_index, raw in enumerate(query_records([page], "Flow graph input")):
            flow_id = raw.get("Id")
            validate_flow_id(flow_id)
            if flow_id[:15] in identifiers:
                raise ValueError(f"Duplicate Flow version Id: {flow_id}")
            identifiers.add(flow_id[:15])
            if not isinstance(raw.get("Metadata"), dict):
                raise ValueError(f"Flow version {flow_id} has missing Metadata")
            records.append((f"/{page_index}/records/{record_index}", raw))
    return records


def select_active_flows(records):
    """Validate active versions and reject ambiguous names before building graphs."""
    from .models import FlowRecord

    selected = []
    names = set()
    for source_path, raw in records:
        if raw["Metadata"].get("status") != "Active":
            continue
        record = FlowRecord.model_validate(raw)
        name = record.Metadata.fullName or record.FullName
        if name in names:
            raise ValueError(f"Multiple active Flow versions have full name {name!r}")
        names.add(name)
        selected.append((source_path, record))
    return selected


def read_flows(filepath: Path) -> FlowSnapshot:
    """Load saved versions without assuming acquisition reports/catalogs exist."""
    records = read_flow_records(filepath)
    by_id = {raw["Id"]: raw for _, raw in records}
    selected = [
        SelectedFlow(path, by_id[model.Id], model)
        for path, model in select_active_flows(records)
    ]
    return FlowSnapshot(records=records, selected=selected)


def load_snapshot(export_dir: Path) -> FlowSnapshot:
    """Load and verify the complete declared input bundle for a persisted build."""
    export_dir = Path(export_dir)
    sources = source_descriptors(export_dir)
    flows = read_flows(export_dir / "Flow.json")
    reports, warnings = validate_coverage(export_dir, flows.records)
    objects, fields, relationships = read_catalogs(export_dir)
    if reports["datamodel"]["completed"] != len(objects):
        raise ValueError("Data-model report does not match the object catalog")
    return FlowSnapshot(
        flows.records,
        flows.selected,
        sources,
        reports,
        warnings,
        objects,
        fields,
        relationships,
    )
