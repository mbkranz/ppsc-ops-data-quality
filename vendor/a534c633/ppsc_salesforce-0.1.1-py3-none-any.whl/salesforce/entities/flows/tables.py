"""Explicit projections of compiled lineage for Parquet and workbook consumers."""

import networkx as nx
import pandas as pd
import pyarrow as pa
from salesforce.core import network_graph as nx_helpers
from .contract import NODE_SCHEMA, EDGE_SCHEMA, EXPRESSION_SCHEMA, canonical_json


def lineage_tables(lineage):
    graph = lineage.graph
    nodes = [
        dict(
            node_id=node,
            **{
                key: data[key]
                for key in (
                    "kind",
                    "name",
                    "flow_name",
                    "flow_version_id",
                    "resolution_status",
                )
            },
            attributes_json=canonical_json(data),
        )
        for node, data in sorted(graph.nodes(data=True))
    ]
    edges = [
        dict(
            source_id=source,
            target_id=target,
            **{
                key: data[key]
                for key in (
                    "edge_id",
                    "relation",
                    "flow_name",
                    "flow_version_id",
                    "source_path",
                    "evidence_type",
                    "resolution_status",
                )
            },
            attributes_json=canonical_json(data),
        )
        for source, target, _, data in sorted(graph.edges(keys=True, data=True))
    ]
    return {
        "nodes": pa.Table.from_pylist(nodes, schema=NODE_SCHEMA),
        "edges": pa.Table.from_pylist(edges, schema=EDGE_SCHEMA),
        "expressions": pa.Table.from_pylist(
            lineage.expressions, schema=EXPRESSION_SCHEMA
        ),
    }


def _nodedf_from_graph(G: nx.MultiDiGraph) -> pd.DataFrame:
    source = (
        G.graph["fullName"] + "." + (G.graph.get("startElementReference") or "start")
    )
    order = (
        list(nx_helpers.list_dag_node_inputs(G, source=source)) if source in G else []
    )
    # Directed traversal misses upstream data sources and isolated resources.
    positions = {node: position for position, node in enumerate(order)}
    nodes = order + [node for node in G if node not in positions]
    rows = []
    for node in nodes:
        data = G.nodes[node]
        attrs = data.get("attrs", {})
        rows.append({
            **data,
            "node": node,
            "input_nodes": list(G.predecessors(node)),
            "node_kind": attrs.get("node_kind", data.get("node_kind")),
            "node_hierarchy": attrs.get("node_hierarchy", data.get("node_hierarchy")),
            "run_order": positions.get(node, pd.NA),
        })
    return pd.DataFrame(rows).reindex(
        columns=[
            "node",
            "input_nodes",
            "run_order",
            "node_kind",
            "node_hierarchy",
            "expression",
            "attrs",
            "process_name",
            "process_label",
            "process_type",
            "process_kind",
        ]
    )


def _edgedf_from_graph(G: nx.MultiDiGraph, nodes: pd.DataFrame) -> pd.DataFrame:
    nodes = nodes.set_index("node")
    edges = nx.to_pandas_edgelist(
        G, source="source_node", target="target_node", edge_key="link_name"
    ).reindex(columns=["source_node", "target_node", "link_name", "relation"])
    for side in ("source", "target"):
        edges[side + "_node_kind"] = edges[side + "_node"].map(nodes["node_kind"])
    edges["target_expression"] = edges["target_node"].map(nodes["expression"])
    return edges


def flow_graphs(lineage):
    """Project version-scoped graphs to the established workbook node names."""
    graphs = {}
    roots = [
        (node, data)
        for node, data in lineage.graph.nodes(data=True)
        if data["kind"] == "Flow"
    ]
    for root, data in roots:
        version = data["flow_version_id"]
        nodes = [
            node
            for node, attrs in lineage.graph.nodes(data=True)
            if node != root and attrs["flow_version_id"] == version
        ]
        selected = lineage.graph.subgraph(nodes)
        graph = nx.MultiDiGraph()
        graph.add_nodes_from(
            (attrs["name"], attrs.copy()) for _, attrs in selected.nodes(data=True)
        )
        for source, target, attrs in selected.edges(data=True):
            graph.add_edge(
                selected.nodes[source]["name"],
                selected.nodes[target]["name"],
                key=attrs["original_key"],
                **attrs,
            )
        graph.graph.update(data["source_record"]["Metadata"])
        graph.graph["fullName"] = data["flow_name"]
        graphs[data["flow_name"]] = graph
    return graphs


def graph_tables(graph):
    """Project one graph using the established workbook columns."""
    nodes = _nodedf_from_graph(graph)
    edges = _edgedf_from_graph(graph, nodes)
    edges = edges.merge(
        nodes[["node", "input_nodes"]].rename(
            columns={"node": "target_node", "input_nodes": "target_node_inputs"}
        ),
        on="target_node",
        how="left",
    )
    return nodes, edges


def workbook_tables(lineage):
    graphs = flow_graphs(lineage)
    nodesdfs, edgesdfs = [], []
    for name, graph in graphs.items():
        nodes, edges = graph_tables(graph)
        nodesdfs.append(nodes.assign(process_name=name))
        edgesdfs.append(edges.assign(process_name=name))
    if not nodesdfs:
        graph = nx.MultiDiGraph(fullName="")
        nodes = _nodedf_from_graph(graph)
        return nodes, _edgedf_from_graph(graph, nodes)
    return pd.concat(nodesdfs), pd.concat(edgesdfs)
