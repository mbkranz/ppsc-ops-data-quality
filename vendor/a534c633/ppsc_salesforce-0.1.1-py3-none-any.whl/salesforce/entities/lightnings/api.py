from salesforce import soql_templates
from salesforce.client import query_records

__all__ = ["flexipage", "lightning_component_bundle", "lightning_component_resource"]


def flexipage(salesforce_client):
    # Combined response structure
    ids = soql_templates.tooling.by_entity.FlexiPage.inventory
    metadata = soql_templates.tooling.by_entity.FlexiPage.metadata

    idlist = [rec for rec in salesforce_client.query(ids, use_tooling_api=True)]

    records = []
    for id in query_records(idlist, "component inventory"):
        print(f"Exporting FlexiPage.{id['DeveloperName']}")
        object_tooling_query_response = salesforce_client.query(
            metadata.format(id=id["Id"]), use_tooling_api=True
        )
        records.extend(object_tooling_query_response)

    return records


def lightning_component_bundle(salesforce_client):
    # Combined response structure

    __objectname__ = "LightningComponentBundle"

    ids = soql_templates.tooling.by_entity.LightningComponentBundle.inventory

    metadata = soql_templates.tooling.by_entity.LightningComponentBundle.metadata

    idlist = [rec for rec in salesforce_client.query(ids, use_tooling_api=True)]

    records = []
    for id in query_records(idlist, "component inventory"):
        print(f"Exporting {__objectname__}.{id['DeveloperName']}")
        object_tooling_query_response = salesforce_client.query(
            metadata.format(id=id["Id"]), use_tooling_api=True
        )
        records.extend(object_tooling_query_response)

    return records


def lightning_component_resource(salesforce_client):
    lwc_resource = soql_templates.tooling.by_entity.LightningComponentResource.all
    lwc_resource_response = salesforce_client.query(lwc_resource, use_tooling_api=True)
    return lwc_resource_response
