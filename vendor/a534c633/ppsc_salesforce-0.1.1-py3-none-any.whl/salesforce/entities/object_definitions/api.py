"""Live entity discovery and selected definition acquisition; no filesystem writes."""

import re
from dataclasses import dataclass
from typing import Annotated
from urllib.parse import urlencode

from pydantic import BaseModel, ConfigDict, Field
from simple_salesforce.exceptions import SalesforceError
from sqlglot import exp

from salesforce import soql_templates
from salesforce.client import IncompleteQueryError, SalesforceClient
from salesforce.client import query_records as _query_records
from salesforce.soql import prepare_query, render_soql, selected_properties
from salesforce.utils import chunk_sequence

__all__ = [
    "describe_entity_definition",
    "entity_definition",
    "tooling_object_property_list",
    "discover_entities",
    "fetch_entity_definitions",
    "EntityFetchResult",
    "sobjects",
    "sobjects_record_counts",
]


# Compatibility projection; the authored query remains the source of truth.
tooling_object_property_list = ",".join(
    selected_properties(
        prepare_query(
            soql_templates.tooling.by_entity.EntityDefinition.legacy,
            where_isin=["Account"],
        )
    )
)


def describe_entity_definition(salesforce_client):
    """

    [DEPRECATED] Now read in all tooling object describes needed for entity definition in describe_tooling_objects.py
    Export the object metadata from the tooling API from the describe endpoint.

    This function returns the available entities (objects) in the tooling API (NOT objects within the CRM data model)
    """
    object_tooling_describe_url = (
        salesforce_client.resources_url + "/tooling/sobjects/EntityDefinition/describe"
    )
    object_tooling_describe = salesforce_client.get(object_tooling_describe_url)
    return object_tooling_describe


def sobjects(salesforce_client):
    """
    Export the object metadata from the standard REST API from the describe endpoint.

    This function returns the available entities (objects) in the standard REST API (NOT objects within the CRM data model)
    """
    object_describe_url = salesforce_client.resources_url + "/sobjects"
    object_describe = salesforce_client.get(object_describe_url)
    return object_describe


def sobjects_record_counts(salesforce_client):
    return salesforce_client.get_resource("limits/recordCount")


def entity_definition(
    salesforce_client, object_qualified_api_names: list[str] = None, n: int = 2
):
    # Combined response structure

    if object_qualified_api_names is None:
        object_qualified_api_names = list(discover_entities(salesforce_client))

    # Object metadata from EntityDefinition in tooling API
    object_tooling_query_template = (
        soql_templates.tooling.by_entity.EntityDefinition.legacy
    )

    records = []
    for chunk in chunk_sequence(list(dict.fromkeys(object_qualified_api_names)), n):
        object_tooling_query = render_soql(
            prepare_query(object_tooling_query_template, where_isin=chunk)
        )
        object_tooling_query_response = salesforce_client.query(
            object_tooling_query, use_tooling_api=True
        )
        records.extend(object_tooling_query_response)

    return records


MAX_QUERY_URL_BYTES = 14_000
ENTITY_NAME_CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"
MAX_DISCOVERY_PREFIX_LENGTH = 255
UNAVAILABLE_PROPERTIES = "export:unavailableProperties"

# Unlisted failures propagate; timeouts and request quotas are not size errors.
SPLIT_HTTP_STATUSES = {414}
RESULT_SIZE_ERROR_MESSAGES = {
    "EXCEEDED_ID_LIMIT": ("too many ids", "does not support querymore()")
}


class Definition(BaseModel):
    model_config = ConfigDict(extra="allow", strict=True, hide_input_in_errors=True)

    QualifiedApiName: Annotated[str, Field(min_length=1)]


class EntityDefinition(Definition):
    Fields: dict | None


class FieldDefinition(Definition):
    Particles: dict | None


class EntityParticle(Definition):
    DurableId: Annotated[str, Field(min_length=1)]


def _complete_records(result: dict | None, context: str) -> list[dict]:
    if result is None:
        return []
    return _query_records([result], context)


def _is_locator_size_error(error: SalesforceError) -> bool:
    errors = error.content if isinstance(error.content, list) else []
    for detail in errors:
        if not isinstance(detail, dict):
            continue
        extended = detail.get("extendedErrorDetails")
        if (
            detail.get("errorCode") == "INVALID_QUERY_LOCATOR"
            and isinstance(extended, list)
            and any(
                isinstance(item, dict)
                and item.get("extendedErrorCode") == "LOCATOR_LOCATION_EXCEEDS_SIZE"
                for item in extended
            )
        ):
            return True
    return False


def _is_result_size_error(error: SalesforceError) -> bool:
    if error.status in SPLIT_HTTP_STATUSES:
        return False
    errors = error.content if isinstance(error.content, list) else []
    for detail in errors:
        if not isinstance(detail, dict):
            continue
        message = str(detail.get("message", "")).lower()
        patterns = RESULT_SIZE_ERROR_MESSAGES.get(detail.get("errorCode"), ())
        if any(pattern in message for pattern in patterns):
            return True
    return _is_locator_size_error(error)


def _discover_entities(
    client: SalesforceClient, *, durable_ids: dict[str, str] | None = None
) -> list[str]:
    names: set[str] = set()
    pending_prefixes = [""]
    columns = (
        "QualifiedApiName, DurableId" if durable_ids is not None else "QualifiedApiName"
    )

    def collect(records: list[dict], prefix: str, *, exact: bool = False) -> None:
        for record in records:
            name = record.get("QualifiedApiName")
            if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9_]+", name):
                raise ValueError(f"Invalid entity name in discovery: {name!r}")
            matches = (
                name.casefold() == prefix.casefold()
                if exact
                else name.casefold().startswith(prefix.casefold())
            )
            if not matches or name in names:
                raise ValueError(f"Unexpected or repeated entity in discovery: {name}")
            if durable_ids is not None:
                durable_id = record.get("DurableId")
                if not isinstance(durable_id, str) or not durable_id:
                    raise ValueError(
                        f"Missing or invalid discovery DurableId for {name}"
                    )
                durable_ids[name] = durable_id
            names.add(name)

    while pending_prefixes:
        prefix = pending_prefixes.pop()
        if prefix:
            pattern = prefix.replace("_", "\\_") + "%"
            query = soql_templates.tooling.by_entity.EntityDefinition.by_prefix.strip().format(
                columns=columns, pattern=pattern
            )
        else:
            query = soql_templates.tooling.by_entity.EntityDefinition.inventory.strip().format(
                columns=columns
            )
        try:
            records = _query_records(
                client.query(query, use_tooling_api=True), f"entity prefix {prefix!r}"
            )
        except (SalesforceError, IncompleteQueryError) as error:
            error.add_note(f"Discovering entity definitions with prefix {prefix!r}")
            if (
                not (
                    isinstance(error, IncompleteQueryError)
                    or _is_result_size_error(error)
                )
                or len(prefix) >= MAX_DISCOVERY_PREFIX_LENGTH
            ):
                raise
            print(
                f"Narrowing entity discovery prefix {prefix!r}: {type(error).__name__}"
            )
            if prefix:
                # A name equal to the prefix is not covered by its longer prefixes.
                exact_query = soql_templates.tooling.by_entity.EntityDefinition.by_name.strip().format(
                    columns=columns, name=prefix
                )
                collect(
                    _query_records(
                        client.query(exact_query, use_tooling_api=True),
                        f"entity name {prefix!r}",
                    ),
                    prefix,
                    exact=True,
                )
            pending_prefixes.extend(prefix + char for char in ENTITY_NAME_CHARACTERS)
        else:
            collect(records, prefix)
    return sorted(names)


def _validate_entity_batch(records: list[dict], requested_names: list[str]) -> None:
    entities = [EntityDefinition.model_validate(record) for record in records]
    returned_names = [record.QualifiedApiName for record in entities]
    if len(set(returned_names)) != len(returned_names) or not set(
        requested_names
    ).issubset(returned_names):
        raise ValueError(
            f"Entity batch mismatch: requested {requested_names}, returned {returned_names}"
        )
    for record in entities:
        name = record.QualifiedApiName
        field_names = set()
        for field_record in _complete_records(record.Fields, f"{name}.Fields"):
            field = FieldDefinition.model_validate(field_record)
            field_name = field.QualifiedApiName
            if field_name in field_names:
                raise ValueError(
                    f"Invalid or repeated field in {name}.Fields: {field_name!r}"
                )
            field_names.add(field_name)
            context = f"{name}.{field_name}.Particles"
            particle_keys = set()
            for particle_record in _complete_records(field.Particles, context):
                particle = EntityParticle.model_validate(particle_record)
                particle_key = (particle.DurableId, particle.QualifiedApiName)
                if particle_key in particle_keys:
                    raise ValueError(
                        f"Invalid or repeated particle in {context}: {particle_key!r}"
                    )
                particle_keys.add(particle_key)


def _partition_flat_query(client, expression, context):
    """Complete catalog reads that cannot paginate, retaining the original filter."""
    pending = list(ENTITY_NAME_CHARACTERS)
    records = []
    seen = set()

    def collect(selected, prefix, exact=False):
        for record in selected:
            name = record.get("QualifiedApiName")
            if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9_]+", name):
                raise ValueError(f"Invalid catalog name in {context}")
            matches = (
                name.casefold() == prefix.casefold()
                if exact
                else name.casefold().startswith(prefix.casefold())
            )
            identity = (record.get("DurableId"), name)
            if not matches or identity in seen:
                raise ValueError(
                    f"Unexpected or repeated catalog record in {context}: {name}"
                )
            seen.add(identity)
            records.append(record)

    def query(predicate):
        return _query_records(
            client.query(
                render_soql(expression.where(predicate)), use_tooling_api=True
            ),
            context,
        )

    while pending:
        prefix = pending.pop()
        pattern = prefix.replace("_", "\\_") + "%"
        try:
            selected = query(
                exp.Like(
                    this=exp.column("QualifiedApiName"),
                    expression=exp.Literal.string(pattern),
                )
            )
        except (SalesforceError, IncompleteQueryError) as error:
            if len(prefix) >= MAX_DISCOVERY_PREFIX_LENGTH or not (
                isinstance(error, IncompleteQueryError) or _is_result_size_error(error)
            ):
                raise
            collect(
                query(
                    exp.EQ(
                        this=exp.column("QualifiedApiName"),
                        expression=exp.Literal.string(prefix),
                    )
                ),
                prefix,
                exact=True,
            )
            pending.extend(prefix + char for char in ENTITY_NAME_CHARACTERS)
        else:
            collect(selected, prefix)
    return records


def _flat_entity_records(client, expression, unavailable_field_properties=None):
    """Recover broken nested locators using the same projection at each level."""
    fields_query = next(
        item.this
        for item in expression.expressions
        if isinstance(item, exp.Subquery)
        and item.this.args["from_"].this.name == "Fields"
    )
    particles_query = next(
        item.this
        for item in fields_query.expressions
        if isinstance(item, exp.Subquery)
        and item.this.args["from_"].this.name == "Particles"
    )

    permitted = unavailable_field_properties or {}

    def read(query, source, predicate=None, unavailable=()):
        query = query.copy()
        excluded = {
            item.name
            for item in query.expressions
            if isinstance(item, exp.Column) and item.name in unavailable
        }
        query.set(
            "expressions",
            [
                item
                for item in query.expressions
                if isinstance(item, exp.Column) and item.name not in excluded
            ],
        )
        query.set("from_", exp.From(this=exp.Table(this=exp.to_identifier(source))))
        if predicate is not None:
            query = query.where(predicate)
        try:
            selected = _query_records(
                client.query(render_soql(query), use_tooling_api=True), source
            )
        except (SalesforceError, IncompleteQueryError) as error:
            if source == "EntityDefinition" or not (
                isinstance(error, IncompleteQueryError) or _is_result_size_error(error)
            ):
                raise
            print(f"Partitioning flat {source} query by API name")
            selected = _partition_flat_query(client, query, source)
        for record in selected:
            if excluded:
                record.update({name: None for name in excluded})
                record[UNAVAILABLE_PROPERTIES] = {
                    name: "Explicitly permitted unavailable property after Salesforce HTTP 500"
                    for name in sorted(excluded)
                }
        return selected

    def complete(records):
        return {"records": records, "done": True, "totalSize": len(records)}

    records = read(expression, "EntityDefinition")
    for record in records:
        entity_predicate = exp.EQ(
            this=exp.column("QualifiedApiName", table="EntityDefinition"),
            expression=exp.Literal.string(record["QualifiedApiName"]),
        )
        if any(name.startswith(record["QualifiedApiName"] + ".") for name in permitted):
            inventory_query = fields_query.copy()
            inventory_query.set(
                "expressions", [exp.column("DurableId"), exp.column("QualifiedApiName")]
            )
            inventory = read(inventory_query, "FieldDefinition", entity_predicate)
            fields = []
            for identity in inventory:
                full_name = (
                    record["QualifiedApiName"] + "." + identity["QualifiedApiName"]
                )
                fields.extend(
                    read(
                        fields_query,
                        "FieldDefinition",
                        exp.EQ(
                            this=exp.column("DurableId"),
                            expression=exp.Literal.string(identity["DurableId"]),
                        ),
                        permitted.get(full_name, ()),
                    )
                )
        else:
            fields = read(fields_query, "FieldDefinition", entity_predicate)
        for field in fields:
            full_name = record["QualifiedApiName"] + "." + field["QualifiedApiName"]
            particles = read(
                particles_query,
                "EntityParticle",
                exp.EQ(
                    this=exp.column("DurableId", table="FieldDefinition"),
                    expression=exp.Literal.string(field["DurableId"]),
                ),
                permitted.get(full_name, ()),
            )
            field["Particles"] = complete(particles)
        record["Fields"] = complete(fields)
    return records


def _iter_query_entity_batches(
    client: SalesforceClient,
    template: str,
    names: list[str],
    *,
    by_durable_id=False,
    unavailable_field_properties=None,
):
    """Fetch complete records with bounded result-size splitting."""
    expression = prepare_query(template, sobjectlist=names)
    if by_durable_id:
        source = expression.args["from_"].this
        where = expression.args.get("where")
        predicate = where.this if where else None
        if (
            source.name.lower() != "entitydefinition"
            or not isinstance(predicate, exp.In)
            or not isinstance(predicate.this, exp.Column)
            or len(predicate.this.parts) != 1
            or predicate.this.name.lower() != "qualifiedapiname"
            or not predicate.expressions
            or any(
                not isinstance(item, exp.Literal) or not item.is_string
                for item in predicate.expressions
            )
        ):
            raise ValueError("Entity query must have a root QualifiedApiName IN filter")
        expression = expression.copy()
        expression.args["where"].this.set("this", exp.column("DurableId"))
    query = render_soql(expression)
    url = client.resources_url + "/tooling/query?" + urlencode({"q": query})
    if len(url.encode("utf-8")) > MAX_QUERY_URL_BYTES:
        if len(names) == 1:
            raise ValueError(f"Query URL exceeds the size budget for entity {names[0]}")
        print(f"Splitting entity batch {names}: encoded query URL exceeds size budget")
    else:
        print(f"Querying definitions for entities: {names}")
        try:
            records = _query_records(
                client.query(query, use_tooling_api=True), f"entities {names}"
            )
        except (SalesforceError, IncompleteQueryError) as error:
            error.add_note(f"Querying entity definitions for {names}")
            size_error = isinstance(error, IncompleteQueryError) or (
                error.status in SPLIT_HTTP_STATUSES or _is_result_size_error(error)
            )
            if (
                len(names) == 1
                and isinstance(error, SalesforceError)
                and (
                    _is_locator_size_error(error)
                    or (
                        error.status == 500
                        and not by_durable_id
                        and any(
                            name.startswith(names[0] + ".")
                            for name in (unavailable_field_properties or {})
                        )
                        and isinstance(error.content, list)
                        and any(
                            isinstance(detail, dict)
                            and detail.get("errorCode") == "UNKNOWN_EXCEPTION"
                            for detail in error.content
                        )
                    )
                )
            ):
                print(f"Recovering entity metadata with flat queries: {names[0]}")
                yield (
                    names,
                    _flat_entity_records(
                        client, expression, unavailable_field_properties
                    ),
                )
                return
            if len(names) == 1 or not size_error:
                raise
            print(
                f"Splitting entity batch {names}: {str(error) if isinstance(error, IncompleteQueryError) else type(error).__name__}"
            )
        else:
            yield names, records
            return
    midpoint = len(names) // 2
    yield from _iter_query_entity_batches(
        client,
        template,
        names[:midpoint],
        by_durable_id=by_durable_id,
        unavailable_field_properties=unavailable_field_properties,
    )
    yield from _iter_query_entity_batches(
        client,
        template,
        names[midpoint:],
        by_durable_id=by_durable_id,
        unavailable_field_properties=unavailable_field_properties,
    )


def _query_entity_batch_records(client, template, names, *, by_durable_id=False):
    return [
        record
        for _, records in _iter_query_entity_batches(
            client, template, names, by_durable_id=by_durable_id
        )
        for record in records
    ]


def query_entity_batch(
    client: SalesforceClient,
    template: str,
    names: list[str],
    *,
    durable_ids: dict[str, str] | None = None,
    missing_entities: dict[str, str] | None = None,
) -> list[dict]:
    """Query a name batch, optionally recovering and reporting missing entities."""
    records = _query_entity_batch_records(client, template, names)
    if durable_ids is None:
        _validate_entity_batch(records, names)
        return records
    result = _resolve_entity_records(client, template, names, records, durable_ids)
    if missing_entities is not None:
        missing_entities.update(result.unresolved)
    elif result.unresolved:
        for name in result.unresolved:
            if not isinstance(durable_ids.get(name), str) or not durable_ids[name]:
                raise ValueError(f"Missing or invalid discovery DurableId for {name}")
        _validate_entity_batch(result.records, names)
    return result.records


def _resolve_entity_records(
    client, template, names, records, durable_ids
) -> "EntityFetchResult":
    unresolved = {}
    _validate_entity_batch(records, [])
    returned = {record["QualifiedApiName"] for record in records}
    missing = [name for name in names if name not in returned]
    if not missing:
        return EntityFetchResult(records, unresolved)

    retry_ids = []
    for name in missing:
        durable_id = durable_ids.get(name)
        if not isinstance(durable_id, str) or not durable_id:
            unresolved[name] = (
                "Not returned by QualifiedApiName; no DurableId available"
            )
            continue
        retry_ids.append(durable_id)
    if not retry_ids:
        return EntityFetchResult(records, unresolved)
    print(f"Retrying missing entities by discovered DurableId: {missing}")
    retry_records = _query_entity_batch_records(
        client, template, retry_ids, by_durable_id=True
    )
    _validate_entity_batch(retry_records, [])
    for record in retry_records:
        name = record["QualifiedApiName"]
        if name not in missing or record.get("DurableId") != durable_ids[name]:
            raise ValueError(f"Unexpected entity identity in DurableId retry: {name}")
    records.extend(retry_records)
    recovered = {record["QualifiedApiName"] for record in retry_records}
    for name in missing:
        if name not in recovered and name not in unresolved:
            unresolved[name] = (
                "Not returned by QualifiedApiName or discovered DurableId"
            )
    return EntityFetchResult(records, unresolved)


@dataclass
class EntityFetchResult:
    """Completed reads and identities unresolved by successful lookups."""

    records: list[dict]
    unresolved: dict[str, str]


def discover_entities(client: SalesforceClient) -> dict[str, str]:
    durable_ids: dict[str, str] = {}
    _discover_entities(client, durable_ids=durable_ids)
    return dict(sorted(durable_ids.items()))


def fetch_entity_definitions(
    client, names, *, template: str, durable_ids=None, unavailable_field_properties=None
) -> EntityFetchResult:
    records = []
    unresolved = {}
    for result in iter_entity_definitions(
        client,
        names,
        template=template,
        durable_ids=durable_ids,
        unavailable_field_properties=unavailable_field_properties,
    ):
        records.extend(result.records)
        unresolved.update(result.unresolved)
    return EntityFetchResult(records, unresolved)


def iter_entity_definitions(
    client, names, *, template: str, durable_ids=None, unavailable_field_properties=None
):
    """Yield independently complete split groups for immediate export checkpointing.

    A yielded value is fully validated; a later failed group cannot invalidate it.
    """
    if isinstance(names, str):
        raise ValueError("Entity selection must be a collection of API names")
    names = list(names)
    if not names:
        return
    if any(
        not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9_]+", name)
        for name in names
    ) or len(set(names)) != len(names):
        raise ValueError("Entity selection must contain distinct API names")
    for batch, records in _iter_query_entity_batches(
        client,
        template,
        names,
        unavailable_field_properties=unavailable_field_properties,
    ):
        yield _resolve_entity_records(
            client, template, batch, records, durable_ids or {}
        )
