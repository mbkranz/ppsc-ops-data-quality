"""Validated v1 data-model manifests; persistence performs no network reads."""

from datetime import UTC, datetime
from pathlib import Path
from uuid import UUID, uuid4

from pydantic import AwareDatetime, BaseModel, Field
from salesforce.client import (
    CHECKPOINT_CONFIG,
    CheckpointEntry,
    CheckpointScope,
    EntityName,
    NonEmptyString,
    atomic_output,
    load_payload,
    save_payload,
)
from salesforce.client import checkpoint_scope as checkpoint_scope


class DatamodelCheckpoint(BaseModel):
    model_config = CHECKPOINT_CONFIG

    schema_version: int = Field(default=1, ge=1, le=1)
    run_id: UUID = Field(default_factory=uuid4)
    started_at: AwareDatetime = Field(default_factory=lambda: datetime.now(UTC))
    complete: bool = False
    scope: CheckpointScope
    inventory: dict[EntityName, NonEmptyString]
    entries: dict[EntityName, CheckpointEntry] = Field(default_factory=dict)


def save_checkpoint(directory: Path, checkpoint: DatamodelCheckpoint) -> None:
    checkpoint = DatamodelCheckpoint.model_validate(checkpoint)
    with atomic_output(directory / "manifest.json") as temporary:
        temporary.write_text(checkpoint.model_dump_json(indent=2), encoding="utf-8")


def load_checkpoint(directory: Path, scope: CheckpointScope) -> DatamodelCheckpoint:
    try:
        checkpoint = DatamodelCheckpoint.model_validate_json(
            (directory / "manifest.json").read_bytes()
        )
    except (FileNotFoundError, ValueError) as error:
        raise ValueError(
            "Cannot resume this checkpoint; start a fresh run without --resume"
        ) from error
    if checkpoint.scope != CheckpointScope.model_validate(scope):
        raise ValueError("Checkpoint scope changed; start a fresh run without --resume")
    return checkpoint


def save_entities(
    directory: Path,
    checkpoint: DatamodelCheckpoint,
    records: list[dict],
    *,
    replace_names: set[str] | None = None,
) -> DatamodelCheckpoint:
    entries = dict(checkpoint.entries)
    replacing = set(replace_names or ())
    for record in records:
        name = record["QualifiedApiName"]
        if name in entries and name not in replacing:
            raise ValueError(f"Repeated entity in checkpoint: {name}")
        replacing.discard(name)
        entries[name] = save_payload(directory, record)
    updated = DatamodelCheckpoint.model_validate(
        checkpoint.model_copy(update={"entries": entries, "complete": False})
    )
    save_checkpoint(directory, updated)
    return updated


def load_entity(directory: Path, entry: CheckpointEntry) -> dict:
    record = load_payload(directory, entry)
    if not isinstance(record, dict):
        raise ValueError("Checkpoint entity must be an object")
    return record
