"""Explicit, resumable data-model export; acquisition lives in api."""

import json
import logging
from datetime import UTC, datetime
from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

from salesforce.client import (
    READ_RETRY_ERRORS,
    SalesforceClient,
    can_defer_read_error,
    checkpoint_scope,
)
from salesforce.entities.object_definitions.checkpoint import (
    DatamodelCheckpoint,
    atomic_output,
    load_checkpoint,
    load_entity,
    save_checkpoint,
    save_entities,
)
from salesforce.entities.object_definitions.api import (
    discover_entities,
    iter_entity_definitions,
    _validate_entity_batch,
    UNAVAILABLE_PROPERTIES,
)
from salesforce.utils import timed

from . import api

ENTITY_BATCH_SIZE = 10


def _build_export_tables(
    definitions: list[dict], record_counts: dict[str, int]
) -> tuple[pa.Table, pa.Table]:
    object_rows: dict[str, dict] = {}
    particle_rows: dict[str, dict] = {}
    for record in definitions:
        entity_name = record["QualifiedApiName"]
        if entity_name in object_rows:
            raise ValueError(f"Repeated entity in export: {entity_name}")
        entity_properties = {
            key: value for key, value in record.items() if key != "Fields"
        }
        entity_columns = {
            f"EntityDefinition.{key}": value for key, value in entity_properties.items()
        }
        fields_result = record["Fields"]
        fields_records = fields_result["records"] if fields_result is not None else []
        for field_record in fields_records:
            field_id = field_record.get("DurableId")
            field_full_name = entity_name + "." + field_record["QualifiedApiName"]
            field_columns = {
                f"FieldDefinition.{key}": value
                for key, value in field_record.items()
                if key != "Particles"
            }
            particles_result = field_record["Particles"]
            particle_records = (
                particles_result["records"] if particles_result is not None else []
            )
            for particle_record in particle_records:
                particle_id = particle_record["DurableId"]
                if (
                    field_id == particle_id
                    and field_record["QualifiedApiName"]
                    == particle_record["QualifiedApiName"]
                ):
                    particle_full_name = field_full_name
                else:
                    particle_full_name = (
                        field_full_name + "." + particle_record["QualifiedApiName"]
                    )

                if particle_full_name in particle_rows:
                    raise ValueError(
                        f"Repeated particle in export: {particle_full_name}"
                    )
                particle_rows[particle_full_name] = {
                    **entity_columns,
                    **field_columns,
                    **particle_record,
                }

        object_rows[entity_name] = {
            **entity_properties,
            "limit:count": record_counts.get(entity_name),
        }

    objects_df = (
        pd.DataFrame.from_dict(object_rows, orient="index")
        .rename_axis(index="Object")
        .astype(object)
    )

    fields_df = (
        pd.DataFrame.from_dict(particle_rows, orient="index")
        .rename_axis(index="Field")
        .astype(object)
    )

    return pa.Table.from_pandas(objects_df), pa.Table.from_pandas(fields_df)


def _unavailable_properties(definitions):
    unavailable = {}
    for record in definitions:
        for field in (record.get("Fields") or {}).get("records", []):
            details = dict(field.get(UNAVAILABLE_PROPERTIES, {}))
            for particle in (field.get("Particles") or {}).get("records", []):
                details.update(particle.get(UNAVAILABLE_PROPERTIES, {}))
            if details:
                unavailable[
                    record["QualifiedApiName"] + "." + field["QualifiedApiName"]
                ] = details
    return unavailable


def _restore_entities(
    directory: Path, checkpoint: DatamodelCheckpoint, unavailable_field_properties=None
):
    definitions = []
    invalid = set()
    for name, entry in checkpoint.entries.items():
        try:
            record = load_entity(directory, entry)
            _validate_entity_batch([record], [name])
            for full_name, properties in _unavailable_properties([record]).items():
                if not set(properties).issubset(
                    (unavailable_field_properties or {}).get(full_name, ())
                ):
                    raise ValueError(
                        "Cached entity contains unapproved unavailable properties"
                    )
            expected_id = checkpoint.inventory.get(name)
            if (
                expected_id is not None
                and record.get("DurableId") is not None
                and record["DurableId"] != expected_id
            ):
                raise ValueError("Cached entity DurableId does not match discovery")
        except (FileNotFoundError, ValueError) as error:
            print(
                f"WARNING: Requerying invalid checkpoint entity {name}: {type(error).__name__}"
            )
            invalid.add(name)
        else:
            definitions.append(record)
    checkpoint = checkpoint.model_copy(update={"complete": False})
    save_checkpoint(directory, checkpoint)
    return checkpoint, definitions, invalid


def export_datamodel(
    client: SalesforceClient,
    export_dir: Path,
    *,
    template: str,
    resume: bool = False,
    max_requests=None,
    max_elapsed_seconds=None,
    unavailable_field_properties=None,
) -> None:
    budget = client.run_budget(
        max_requests=max_requests, max_elapsed_seconds=max_elapsed_seconds
    )
    with budget as allowance:
        _export_datamodel(
            client,
            Path(export_dir),
            template=template,
            resume=resume,
            budget=allowance,
            unavailable_field_properties=unavailable_field_properties,
        )


def _export_datamodel(
    client, export_dir, *, template, resume, budget, unavailable_field_properties=None
):
    export_dir.mkdir(parents=True, exist_ok=True)
    definition_template = template
    directory = export_dir / "_cache/datamodel"
    scope = checkpoint_scope(client, definition_template)
    if resume:
        checkpoint = load_checkpoint(directory, scope)
        print(
            f"Resuming data-model export {checkpoint.run_id} started {checkpoint.started_at}. "
            f"Age: {datetime.now(UTC) - checkpoint.started_at}. "
            "Reusing saved metadata; omit --resume for a fresh snapshot."
        )
        checkpoint, definitions, invalid = _restore_entities(
            directory, checkpoint, unavailable_field_properties
        )
        durable_ids = dict(checkpoint.inventory)
    else:
        with timed("discover entities"):
            durable_ids = discover_entities(client)
        checkpoint = DatamodelCheckpoint(scope=scope, inventory=durable_ids)
        save_checkpoint(directory, checkpoint)
        definitions = []
        invalid = set()
    entity_names = sorted(durable_ids)
    restored = {record["QualifiedApiName"] for record in definitions}
    pending = sorted((set(entity_names) | set(invalid)) - restored)
    missing_report = export_dir / "missing_entities.txt"
    with atomic_output(missing_report) as temporary:
        temporary.write_text("", encoding="utf-8")
    missing_entities: dict[str, str] = {}
    deferred = []
    failures = {}
    restored_count = len(restored & set(entity_names))

    def report(outputs_published):
        unavailable = _unavailable_properties(definitions)
        payload = {
            "run_id": str(checkpoint.run_id),
            "requested": len(entity_names),
            "completed": len(restored & set(entity_names)),
            "restored": restored_count,
            "fetched": len(restored & set(entity_names)) - restored_count,
            "additional": sorted(restored - set(entity_names)),
            "unresolved": dict(sorted(missing_entities.items())),
            "failed": sorted(failures),
            "pending": sorted(set(entity_names) - restored - set(missing_entities)),
            "outputs_published": outputs_published,
            "coverage_complete": set(entity_names).issubset(restored)
            and not unavailable,
            "unavailable_field_properties": unavailable,
        }
        with atomic_output(export_dir / "datamodel-report.json") as temporary:
            temporary.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        logging.getLogger(__name__).info(
            "Data-model export: requested=%d completed=%d unresolved=%d pending=%d published=%s",
            len(entity_names),
            len(restored),
            len(missing_entities),
            len(payload["pending"]),
            outputs_published,
        )

    def write_missing_report():
        with atomic_output(missing_report) as temporary:
            temporary.write_text(
                "".join(
                    f"{name}\t{durable_ids[name]}\t{reason}\n"
                    for name, reason in sorted(missing_entities.items())
                ),
                encoding="utf-8",
            )

    report(False)
    try:
        with timed("query entity definitions"):
            for recovery in (False, True):
                batches = (
                    [[name] for name in deferred]
                    if recovery
                    else [
                        pending[start : start + ENTITY_BATCH_SIZE]
                        for start in range(0, len(pending), ENTITY_BATCH_SIZE)
                    ]
                )
                for batch in batches:
                    batch = [name for name in batch if name not in restored]
                    if not batch:
                        continue
                    try:
                        for fetched in iter_entity_definitions(
                            client,
                            batch,
                            template=definition_template,
                            durable_ids=durable_ids,
                            unavailable_field_properties=unavailable_field_properties,
                        ):
                            missing_entities.update(fetched.unresolved)
                            records = fetched.records
                            checkpoint = save_entities(
                                directory, checkpoint, records, replace_names=invalid
                            )
                            completed = {
                                record["QualifiedApiName"] for record in records
                            }
                            invalid.difference_update(completed)
                            restored.update(completed)
                            for name in completed:
                                missing_entities.pop(name, None)
                                failures.pop(name, None)
                            definitions.extend(records)
                    except READ_RETRY_ERRORS as error:
                        if not can_defer_read_error(error):
                            raise
                        if recovery:
                            error.add_note(
                                f"Individual entity recovery failed for {batch[0]}"
                            )
                            failures[batch[0]] = error
                        else:
                            deferred.extend(
                                name
                                for name in batch
                                if name not in restored and name not in missing_entities
                            )
                        print(
                            f"WARNING: {'Recovery failed' if recovery else 'Deferring batch'} "
                            f"{batch}: {type(error).__name__}"
                        )
                        continue
            if failures:
                if len(failures) == 1:
                    raise next(iter(failures.values()))
                raise ExceptionGroup(
                    "Individual entity recovery failed", list(failures.values())
                )
    except BaseException:
        try:
            report(False)
            write_missing_report()
        except Exception:
            logging.getLogger(__name__).warning(
                "Could not write data-model failure report"
            )
        raise
    write_missing_report()
    report(False)

    with timed("read sobject record counts"):
        counts_payload = api.sobjects_record_counts(client)
    record_counts = {
        record["name"]: record["count"] for record in counts_payload["sObjects"]
    }
    if budget is not None:
        budget.check()
    with timed("build export tables"):
        definitions.sort(key=lambda record: record["QualifiedApiName"])
        objects_table, fields_table = _build_export_tables(definitions, record_counts)
    if budget is not None:
        budget.check()
    with timed("write parquet files"):
        with atomic_output(export_dir / "objects.parquet") as temporary:
            pq.write_table(objects_table, temporary)
        with atomic_output(export_dir / "fields.parquet") as temporary:
            pq.write_table(fields_table, temporary)
    save_checkpoint(directory, checkpoint.model_copy(update={"complete": True}))
    report(True)
    unavailable = _unavailable_properties(definitions)
    if unavailable:
        print(
            f"WARNING: {len(unavailable)} fields have explicitly permitted unavailable properties; see datamodel-report.json"
        )
    if missing_entities:
        print(
            f"WARNING: Partial data-model export: {len(missing_entities)} of "
            f"{len(entity_names)} requested entities could not be found; see {missing_report}"
        )
