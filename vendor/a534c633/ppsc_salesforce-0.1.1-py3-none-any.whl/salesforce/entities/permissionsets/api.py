from salesforce import soql_templates


def field_permissions(salesforce_client):
    return salesforce_client.query(
        soql_templates.rest.by_entity.FieldPermissions.all, use_tooling_api=False
    )


def object_permissions(salesforce_client):
    return salesforce_client.query(
        soql_templates.rest.by_entity.ObjectPermissions.all, use_tooling_api=False
    )
