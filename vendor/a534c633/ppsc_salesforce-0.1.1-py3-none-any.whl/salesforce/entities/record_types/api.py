from salesforce import soql_templates


def export_record_types(salesforce_client):
    return salesforce_client.query(
        soql_templates.rest.by_entity.RecordType.all, use_tooling_api=False
    )


record_types = export_record_types
