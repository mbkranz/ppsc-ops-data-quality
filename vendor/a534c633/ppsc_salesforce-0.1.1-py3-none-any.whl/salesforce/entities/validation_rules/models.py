from __future__ import annotations

from typing import Optional, Any, Dict

from pydantic import Field, RootModel
from salesforce.core.models import Entity, QueryResult
from salesforce.core import datatypes
from salesforce.core.formulas import formula_references


__all__ = [
    "ValidationRuleAttributes",
    "ValidationRuleRecord",
    "ValidationRuleQueryResult",
    "ValidationRuleQueryResults",
    "ValidationRule",
]


class ValidationRuleAttributes(Entity):
    type: str
    url: str


class ValidationRule(Entity):
    description: Optional[str] = None
    errorConditionFormula: Optional[str] = None
    errorDisplayField: Optional[str] = None
    errorMessage: Optional[str] = None
    shouldEvaluateOnClient: Optional[Any] = None
    urls: Optional[Dict[str, Any]] = None
    active: Optional[bool] = None


class ValidationRuleRecord(Entity):
    Id: datatypes.Id | datatypes.String = None
    ValidationName: Optional[str] = None
    Active: bool
    Description: Optional[str] = None
    NamespacePrefix: Optional[str] = None
    ManageableState: Optional[str] = None
    CreatedById: Optional[datatypes.Id] = None
    CreatedDate: Optional[datatypes.DateTime] = None
    LastModifiedById: Optional[datatypes.Id] = None
    LastModifiedDate: Optional[datatypes.DateTime] = None
    FullName: Optional[str] = None
    EntityDefinitionId: Optional[datatypes.Id | datatypes.String] = None
    EntityDefinition: Optional[dict] = None
    ErrorDisplayField: Optional[str] = None
    ErrorMessage: Optional[str] = None

    attributes: Optional[ValidationRuleAttributes] = None
    Metadata: Optional[ValidationRule] = None

    def add_to_graph(self, graph):
        if not self.Metadata or not self.FullName:
            raise ValueError("ValidationRule requires FullName and Metadata")
        graphnode = self.Metadata.add_node(graph, self.FullName)
        graphnode.update(
            self.model_dump(
                include=["LastModifiedDate", "CreatedDate", "Id", "NamespacePrefix"],
                exclude_none=True,
            )
        )

        if self.EntityDefinition:
            object_ = self.EntityDefinition.get("QualifiedApiName")
        else:
            object_ = self.FullName.split(".")[0]

        graphnode["attrs"].update(
            object=object_, name=self.ValidationName or self.FullName.split(".")[-1]
        )
        for key, value in (
            ("active", self.Active),
            ("description", self.Description),
            ("errorDisplayField", self.ErrorDisplayField),
            ("errorMessage", self.ErrorMessage),
        ):
            if graphnode["attrs"].get(key) is None:
                graphnode["attrs"][key] = value

        for occurrence in formula_references(
            self.Metadata.errorConditionFormula or ""
        )["references"]:
            reference = occurrence["reference"]
            fieldname = reference if "." in reference else f"{object_}.{reference}"
            if fieldname in graph:
                graph.add_edge(
                    fieldname,
                    self.FullName,
                    key=f"{self.FullName}.field.{occurrence['start']}",
                    relation="reads_field",
                    reference=reference,
                    start=occurrence["start"],
                    end=occurrence["end"],
                )

        if self.ErrorDisplayField:
            fieldname = self.ErrorDisplayField
            if "." not in fieldname:
                fieldname = f"{object_}.{fieldname}"
            if fieldname in graph:
                graph.add_edge(
                    fieldname,
                    self.FullName,
                    key=f"{self.FullName}.ErrorDisplayField",
                    relation="reads_field_for_error_display",
                )

        graph.add_edge(
            object_,
            self.FullName,
            key=f"{self.FullName}.object",
            relation="reads_object",
        )

        return graph


class ValidationRuleQueryResult(QueryResult):
    records: list[ValidationRuleRecord] = Field(default_factory=list)


ValidationRuleQueryResults = RootModel[list[ValidationRuleQueryResult]]
