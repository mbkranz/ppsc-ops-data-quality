from salesforce import soql_templates
from salesforce.client import query_records

"""

    Value sets are named sets like picklists that can be shared across multiple fields.
AI - generated summary of ValueSets in the CustomField metadata API:

---

### 1. Metadata API (retrieved CustomField)

When a `CustomField` uses a **Global Value Set**, the retrieved metadata will include a `<valueSet>` element that references the global set by name rather than embedding the picklist values. Example:

```xml
<valueSet>
    <valueSetName>My_Global_Value_Set_Name</valueSetName>
    <valueSetDefinition/>
</valueSet>
```

This means:

* `valueSetName` will appear.
* The actual values are not embedded in the field’s metadata.
* The corresponding `GlobalValueSet` metadata component defines the values separately.

---

### 2. Tooling API (via `SELECT Metadata FROM CustomField`)

When you query the Tooling API, the `Metadata.valueSet` will include the global value set reference if applicable, for example:

```json
"valueSet": {
  "valueSetName": "My_Global_Value_Set_Name",
  "restricted": true
}
```

So, the `valueSetName` appears directly in the Tooling API response when the field uses a global value set.

---

### 3. Local (non-global) value sets

For fields that use their own picklist definitions (not global), the Tooling API returns the full `valueSetDefinition` inline, for example:

```json
"valueSet": {
  "valueSetDefinition": {
    "sorted": false,
    "value": [
      { "fullName": "Option_A", "default": false, "label": "Option A" },
      { "fullName": "Option_B", "default": true, "label": "Option B" }
    ]
  }
}
```

The absence of `valueSetName` and the presence of `valueSetDefinition` indicates a local picklist.

---

### 4. Summary Table

| Field Type              | `valueSetName` Present | Values Embedded | Source of Values                   |
| ----------------------- | ---------------------- | --------------- | ---------------------------------- |
| Global Value Set        | Yes                    | No              | Separate `GlobalValueSet` metadata |
| Local Value Set         | No                     | Yes             | Inline under `valueSetDefinition`  |
| Standard Picklist Field | No                     | Usually No      | Managed by Salesforce              |

"""

__all__ = ["global_value_set"]


def global_value_set(salesforce_client):
    # Combined response structure

    __objectname__ = "GlobalValueSet"

    ids = soql_templates.tooling.by_entity.GlobalValueSet.inventory

    metadata = soql_templates.tooling.by_entity.GlobalValueSet.metadata

    idlist = [rec for rec in salesforce_client.query(ids, use_tooling_api=True)]

    records = []
    for id in query_records(idlist, "component inventory"):
        print(f"Exporting {__objectname__}.{id['DeveloperName']}")
        object_tooling_query_response = salesforce_client.query(
            metadata.format(id=id["Id"]), use_tooling_api=True
        )
        records.extend(object_tooling_query_response)

    return records
