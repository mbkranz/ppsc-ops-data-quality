"""Salesforce record operations; import api explicitly."""

from importlib import import_module


__all__ = ["api"]


def __getattr__(name):
    if name in __all__:
        return import_module(f"{__name__}.{name}")
    raise AttributeError(name)
