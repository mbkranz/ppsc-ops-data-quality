from salesforce import soql_templates
from salesforce.soql import prepare_query, render_soql, selected_properties


def export_surveys(salesforce_client):
    return salesforce_client.query(
        soql_templates.rest.by_entity.Survey__c.all, use_tooling_api=False
    )


def export_journey_items(salesforce_client, *, unavailable_fields=()):
    query = soql_templates.rest.by_entity.Participant_Journey_Item__c.all
    if unavailable_fields:
        expression = prepare_query(query)
        omitted = set(unavailable_fields)
        if not omitted.issubset(selected_properties(expression)):
            raise ValueError(
                "Unavailable fields must be in the journey-item projection"
            )
        expression.set(
            "expressions",
            [item for item in expression.expressions if item.sql() not in omitted],
        )
        query = render_soql(expression)
    return salesforce_client.query(query, use_tooling_api=False)


surveys = export_surveys
journey_items = export_journey_items
