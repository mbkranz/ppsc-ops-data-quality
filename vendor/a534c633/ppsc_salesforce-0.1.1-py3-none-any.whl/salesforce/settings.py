"""Validated repository parameters, loaded explicitly without environment overrides."""

from pathlib import Path
from typing import Annotated, Literal, Self

from pydantic import BaseModel, Field
import yaml

from salesforce.client import SalesforceClient


class Paths(BaseModel):
    exports: Path
    build: Path


class Settings(BaseModel):
    org: Annotated[str, Field(min_length=1)]
    api_version: Annotated[str, Field(pattern=r"^v\d+\.\d+$")]
    auth_method: Literal["cli", "refresh_token"]
    expected_org_id: str
    expected_instance_url: str
    paths: Paths
    migration_mappings: Path

    @classmethod
    def load(cls, environment: str, params_file: Path = Path("params.yaml")) -> Self:
        params = yaml.safe_load(params_file.read_text(encoding="utf-8"))
        environments = params["environments"]
        if environment not in environments:
            raise ValueError(
                f"Unknown environment '{environment}'; "
                f"{params_file} defines {', '.join(sorted(environments))}"
            )
        return cls.model_validate({
            **environments[environment],
            "migration_mappings": params["all"]["migration_mappings"],
        })

    @property
    def setup_dir(self) -> Path:
        return self.paths.exports / "setup"

    def get_client(self) -> SalesforceClient:
        return SalesforceClient(
            org=self.org,
            api_version=self.api_version,
            auth_method=self.auth_method,
            expected_org_id=self.expected_org_id,
            expected_instance_url=self.expected_instance_url,
        )
