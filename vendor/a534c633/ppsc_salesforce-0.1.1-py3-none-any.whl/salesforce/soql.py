"""Build and inspect the SELECT subset used by our Salesforce exports.

Runtime templates are populated by simple-salesforce *before* SQLGlot parses
them. This is not a complete SOQL dialect or a substitute for org validation.
"""

import re
from datetime import datetime
from string import Formatter

import sqlglot
from simple_salesforce.format import format_soql
from sqlglot import exp
from sqlglot.dialects.dialect import Dialect
from sqlglot.errors import ErrorLevel, SqlglotError
from sqlglot.generator import Generator
from sqlglot.parser import Parser
from sqlglot.tokens import Token, Tokenizer, TokenType

from salesforce.utils import to_datetime_utc_string

__all__ = ["prepare_query", "parse_soql", "render_soql", "selected_properties"]

_DATETIME = re.compile(
    r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?"
    r"(?:Z|[+-]\d{2}:\d{2})(?![\w:.+-])"
)
_DATETIME_BINDINGS = {"last_modified_after", "last_modified_start", "last_modified_end"}


class _Datetime(exp.Expression):
    """An unquoted, validated SOQL datetime literal."""


class _Soql(Dialect):
    class Tokenizer(Tokenizer):
        QUOTES = ["'"]
        STRING_ESCAPES = ["\\"]

        def tokenize(self, sql):
            tokens = super().tokenize(sql)
            result = []
            index = 0
            while index < len(tokens):
                token = tokens[index]
                match = (
                    _DATETIME.match(sql, token.start)
                    if token.token_type == TokenType.NUMBER
                    else None
                )
                if match is None:
                    result.append(token)
                    index += 1
                    continue
                datetime.fromisoformat(match.group())
                # Combine only lexer tokens, never text inside strings/comments.
                comments = []
                while index < len(tokens) and tokens[index].start < match.end():
                    comments.extend(tokens[index].comments)
                    index += 1
                result.append(
                    Token(
                        TokenType.HEREDOC_STRING,
                        match.group(),
                        line=token.line,
                        col=token.col,
                        start=token.start,
                        end=match.end() - 1,
                        comments=comments,
                    )
                )
            return result

    class Parser(Parser):
        PRIMARY_PARSERS = {
            **Parser.PRIMARY_PARSERS,
            TokenType.HEREDOC_STRING: lambda self, token: self.expression(
                _Datetime(this=token.text), token
            ),
        }

    class Generator(Generator):
        TRANSFORMS = {**Generator.TRANSFORMS, _Datetime: lambda self, e: e.this}


_SUPPORTED_NODES = (
    exp.Select,
    exp.Subquery,
    exp.From,
    exp.Table,
    exp.Identifier,
    exp.Column,
    exp.Where,
    exp.Literal,
    exp.And,
    exp.EQ,
    exp.GT,
    exp.LT,
    exp.Like,
    exp.In,
    _Datetime,
)


def _validate(expression):
    if not isinstance(expression, exp.Select):
        raise ValueError("Expected one SOQL SELECT query")
    for node in expression.walk():
        if not isinstance(node, _SUPPORTED_NODES):
            raise ValueError(f"Unsupported SOQL expression: {type(node).__name__}")
        if isinstance(node, exp.In) and (
            not node.expressions
            or any(not isinstance(item, exp.Literal) for item in node.expressions)
            or node.args.get("field") is not None
            or node.args.get("query") is not None
        ):
            raise ValueError("SOQL IN requires a nonempty list of literal values")
        if isinstance(node, exp.Select):
            if not node.expressions or not isinstance(node.args.get("from_"), exp.From):
                raise ValueError("SOQL SELECT requires properties and a source")
            for projection in node.expressions:
                if not isinstance(projection, (exp.Column, exp.Subquery)):
                    raise ValueError(
                        "SOQL projections must be properties or child queries"
                    )


def parse_soql(query: str) -> exp.Select:
    """Parse a completed SELECT; unsupported SQL constructs fail explicitly."""
    try:
        statements = sqlglot.parse(query, read=_Soql, error_level=ErrorLevel.RAISE)
    except (SqlglotError, ValueError) as error:
        raise ValueError(f"Invalid SOQL query: {error}") from error
    if len(statements) != 1:
        raise ValueError("Expected one SOQL SELECT query")
    expression = statements[0]
    _validate(expression)
    return expression


def prepare_query(template: str, **bindings) -> exp.Select:
    """Populate SDK placeholders, then parse; only UTC dates may use :literal.

    Pass strings without quotes and lists without parentheses. Date bindings
    retain microseconds and accept the existing naive-as-UTC convention.
    """
    fields = list(Formatter().parse(template))
    names = set()
    normalized = dict(bindings)
    for _, name, spec, conversion in fields:
        if name is None:
            continue
        if not name.isidentifier() or conversion or spec not in {"", "literal"}:
            raise ValueError(f"Unsupported SOQL placeholder: {name!r}")
        names.add(name)
        if spec == "literal":
            if name not in _DATETIME_BINDINGS:
                raise ValueError(":literal is restricted to UTC datetime bindings")
        elif name in _DATETIME_BINDINGS:
            raise ValueError(f"Datetime placeholder {name} requires :literal")
    if names != bindings.keys():
        raise ValueError(
            f"SOQL binding mismatch: missing={sorted(names - bindings.keys())}, "
            f"unexpected={sorted(bindings.keys() - names)}"
        )
    for name, value in bindings.items():
        if name in _DATETIME_BINDINGS:
            normalized[name] = to_datetime_utc_string(value)
        elif name == "id" and not isinstance(value, str):
            raise ValueError("id requires a string")
        elif name in {"sobjectlist", "where_isin"} and not isinstance(
            value, (list, tuple)
        ):
            raise ValueError(f"{name} requires a nonempty sequence of strings")
        elif isinstance(value, (list, tuple)):
            if not value or not all(isinstance(item, str) for item in value):
                raise ValueError(f"{name} requires a nonempty sequence of strings")
        elif not isinstance(value, str):
            raise ValueError(f"{name} requires a string or sequence of strings")
    return parse_soql(format_soql(template, **normalized))


def render_soql(expression: exp.Select, *, pretty: bool = False) -> str:
    """Serialize completed SOQL without changing the caller's expression."""
    _validate(expression)
    return expression.sql(
        dialect=_Soql, pretty=pretty, unsupported_level=ErrorLevel.RAISE
    )


def selected_properties(
    expression: exp.Select, *, relationship_path: tuple[str, ...] = ()
) -> list[str]:
    """Return ordered properties for the root or a child relationship query."""
    _validate(expression)
    selected = expression
    for relationship in relationship_path:
        children = [
            projection.this
            for projection in selected.expressions
            if isinstance(projection, exp.Subquery)
            and projection.this.args["from_"].this.name == relationship
        ]
        if len(children) != 1:
            raise ValueError(f"Missing or ambiguous child query: {relationship}")
        selected = children[0]
    return [
        ".".join(part.name for part in projection.parts)
        for projection in selected.expressions
        if isinstance(projection, exp.Column)
    ]
