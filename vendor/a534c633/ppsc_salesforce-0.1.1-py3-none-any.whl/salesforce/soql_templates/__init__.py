"""Packaged SOQL, indexed by API service, entity, and query type.

For example, ``tooling.by_entity.Flow.metadata`` and
``tooling.by_type.metadata.Flow`` reference the same template string.
"""

from importlib.resources import files
from types import SimpleNamespace

__all__ = ["tooling", "rest"]


def _load_service(service: str) -> SimpleNamespace:
    by_entity = {}
    by_type = {}
    for entity in files(__name__).joinpath(service).iterdir():
        if not entity.is_dir():
            continue
        queries = {}
        for path in entity.iterdir():
            if not path.name.endswith(".soql"):
                continue
            query_type = path.name.removesuffix(".soql")
            query = path.read_text(encoding="utf-8")
            queries[query_type] = query
            by_type.setdefault(query_type, {})[entity.name] = query
        by_entity[entity.name] = SimpleNamespace(**queries)
    return SimpleNamespace(
        by_entity=SimpleNamespace(**by_entity),
        by_type=SimpleNamespace(**{
            query_type: SimpleNamespace(**queries)
            for query_type, queries in by_type.items()
        }),
    )


tooling = _load_service("tooling")
rest = _load_service("rest")
