"""Compatibility import for the :mod:`salesforce.soql_templates` package."""

import sys

from salesforce import soql_templates

sys.modules[__name__] = soql_templates
