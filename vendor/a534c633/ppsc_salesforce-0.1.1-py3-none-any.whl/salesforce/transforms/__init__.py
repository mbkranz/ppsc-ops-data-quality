"""Local helpers used by the existing Salesforce transformations."""
