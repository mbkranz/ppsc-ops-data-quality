# Ported from ppsc-pmd-utils at 365422a837716fc17b1ad197369569957ecaeb87.
import pandas as pd

from collections.abc import Collection

from functools import partial

def bfill_if_dataframe(df: pd.DataFrame | pd.Series) -> pd.Series:
    """Back-fill values across all columns, returning a single combined series.

    When a :class:`pandas.DataFrame` is provided, this function walks the
    columns from left to right and uses :meth:`Series.combine_first` to build
    a single series where, for each row, the first non-missing value across
    all columns is taken. If a :class:`pandas.Series` is passed, it is
    returned unchanged.

    This is useful when multiple alternative columns may contain a value for
    the same logical field and you want a single, best-effort series.

    Args:
        df: Input data. Either a DataFrame whose columns should be merged
            left-to-right using back-fill semantics, or a Series that will be
            returned as-is.

    Returns:
        A series containing, for each row, the first non-null value found
        across the input columns (or the original series if ``df`` is already
        a series).
    """

    if isinstance(df, pd.Series):
        return df

    firstcol = df.iloc[:, 0]
    filled = firstcol

    for i, col in enumerate(df.columns):
        if i == 0:
            continue

        # NOTE: DeprecationWarning:
        # C:\Users\kranz-michael\projects\allofus\ppsc-pmd-utils\src\pmd_utils\transforms\pandas.py:127: FutureWarning: The behavior of array concatenation with empty entries is deprecated.
        # In a fut longer exclude em longer exclude empty items when determining the result dtype. To retain the old behavior, exclude the empty entries before the concat operation.

        # NOTE: Deprecation warning:
        # C:\Users\kranz-michael\projects\allofus\ppsc-pmd-utils\scripts\dev\salesforce\entities\transforms\annotations.py:128: FutureWarning: Series.__getitem__ treating keys as positions is deprecated.
        # In a future version, integer keys will always be treated as labels (consistent with DataFrame behavior). To access a value by position, use `ser.iloc[pos]`
        filled = filled.combine_first(df[col])

    return filled

def apply_mapping(source_df, mapping, fillna_function=None):
    source = mapping.get("source", {})
    sourcename = source["name"]
    target = mapping["target"]

    source_field = source_df[sourcename]

    for step in source.get("steps", []):
        params = step.get("params", {})
        if step.get("type"):
            raise NotImplementedError("Step types not implemented")

        # Prepare a callable that wraps step["function"]
        stepfunc = step["function"]
        func = partial(stepfunc, **params)
        source_field = func(source_field)
    if fillna_function:
        source_field = fillna_function(source_field)
    if isinstance(source_field, pd.DataFrame):
        source_field = source_field.squeeze(axis=1)
    target_field = source_field.rename(target["name"])

    return target_field

def not_empty_or_na(data:pd.Series|pd.DataFrame):
    """
    Returns a function that checks if a value is not empty and not NaN.
    This is useful for filtering or applying conditions in DataFrames.
    """

    def _not_empty_or_na(val):

        if isinstance(val, Collection):
            return bool(len(val))
        elif pd.isna(val):
            return False
        else:
            return True

    return data.map(_not_empty_or_na)

def convert_to_pyarrow_dtypes(df):
    """Infer Arrow scalars/collections; stringify incompatible mixed columns.

    The locked helper never returned inferred collection types and attempted
    collection inference for scalar columns. Use Arrow's native inference while
    preserving the dataframe's index, column order, and missing values.
    """
    import pyarrow as pa

    result = df.convert_dtypes(dtype_backend="pyarrow")
    for column in result.columns:
        if result[column].dtype != "object":
            continue
        try:
            array = pa.array(result[column], from_pandas=True)
            result[column] = pd.Series(
                array, index=result.index, dtype=pd.ArrowDtype(array.type)
            )
        except (pa.ArrowInvalid, pa.ArrowTypeError):
            result[column] = result[column].astype("string[pyarrow]")
    return result
