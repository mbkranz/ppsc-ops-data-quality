# Ported from ppsc-pmd-utils at 365422a837716fc17b1ad197369569957ecaeb87.
from pydantic import BaseModel as CoreMetadata

from typing import Optional, Annotated

class Step(CoreMetadata):
    """
    Represents a step in a data processing pipeline.

    TODO: make name required.
    """
    name: str = None
    function: str = None
    script: str = None
    code: str = None
    description: Optional[str] = None
    fields: list[str] = []
    steps: Optional[list[dict]] = None
