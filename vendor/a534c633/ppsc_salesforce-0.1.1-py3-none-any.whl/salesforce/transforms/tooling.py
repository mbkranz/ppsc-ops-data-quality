"""Full entity names at the boundary between native exports and views."""

import pandas as pd

METADATA_PREFIX = "FieldDefinition.Metadata."


def metadata_columns(frame):
    legacy = {
        name: METADATA_PREFIX + name.removeprefix("meta:")
        for name in frame
        if name.startswith("meta:")
    }
    result = frame.rename(
        columns={
            name: qualified
            for name, qualified in legacy.items()
            if qualified not in frame
        }
    )
    for name, qualified in legacy.items():
        if qualified in frame:
            result[qualified] = result[qualified].where(
                result[qualified].notna(), result[name]
            )
            result = result.drop(columns=name)
    return result


def field_columns(frame):
    frame = metadata_columns(frame)
    return frame.rename(
        columns={
            name: "export.notes" if name == "notes" else f"EntityParticle.{name}"
            for name in frame.columns
            if not name.startswith((
                "EntityDefinition.",
                "FieldDefinition.",
                "EntityParticle.",
                "export.",
            ))
        }
    )


def object_columns(frame):
    return frame.rename(
        columns={
            name: "RecordCount.count"
            if name == "limit:count"
            else f"EntityDefinition.{name}"
            for name in frame.columns
            if not name.startswith(("EntityDefinition.", "RecordCount."))
        }
    )


def column(frame, *names):
    """First populated source value, preserving unknowns and the existing index."""
    result = pd.Series(None, index=frame.index, dtype=object)
    for name in names:
        if name in frame:
            result = result.where(result.notna(), frame[name])
    return result
