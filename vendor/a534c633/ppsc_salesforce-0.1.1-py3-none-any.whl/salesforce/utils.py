import datetime
import functools
import json
import logging
import os
import sys
import time
from contextlib import contextmanager


logger = logging.getLogger("salesforce.timing")

def serialize_datetime(obj):
    if isinstance(obj, (datetime.datetime, datetime.date, datetime.time)):
        return obj.isoformat()
    raise TypeError("Type not serializable")


def smart_dumps(obj, **json_kwargs):
    """
    Extends json.dumps to handle unserializable objects

    Currently supports:
    - datetime objects (datetime, date, time)

    """
    if "default" in json_kwargs:
        raise ValueError("Cannot override the default serialization function")

    return json.dumps(obj, default=serialize_datetime, **json_kwargs)


@contextmanager
def timed(label: str):
    """Log the elapsed time of a block, including when it raises."""
    start = time.perf_counter()
    logger.info("START %s", label)
    status = "DONE"
    try:
        yield
    except BaseException:
        status = "FAILED"
        raise
    finally:
        logger.info("%s %s: %.2fs", status, label, time.perf_counter() - start)


def timed_script(func):
    """Decorate a script's main(): configures logging and times the whole run."""

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        logging.basicConfig(
            level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s"
        )
        with timed(f"script {os.path.basename(sys.argv[0])}"):
            return func(*args, **kwargs)

    return wrapper


# From : https://simple-salesforce.readthedocs.io/en/latest/user_guide/helpful_resources.html
# Formatting to SFDC datetime


def to_datetime_utc_string(x: datetime.datetime | str) -> str:
    """Salesforce requires datetime strings to be in ISO-8601 format with UTC timezone.
    This function converts a datetime string to the required format. If needed, it adds the UTC timezone.

    Must be either UTC timezone or naive (no timezone).
    """
    if isinstance(x, str):
        x = datetime.datetime.fromisoformat(x)
    if not isinstance(x, datetime.datetime):
        raise ValueError("Unrecognized datetime format.")
    if x.tzinfo is not None and x.utcoffset() != datetime.timedelta(0):
        raise ValueError(
            "Datetime object must be in UTC timezone or naive (no timezone)."
        )
    return x.replace(tzinfo=datetime.UTC).isoformat()


def chunk_sequence(items, n):
    """Yield slices using the existing batch-size contract."""
    for start in range(0, len(items), n):
        yield items[start : start + n]
