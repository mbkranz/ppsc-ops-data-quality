"""Load the pinned ODCS standard and validate the small PPSC extension profile."""

from __future__ import annotations

import json
from collections.abc import Iterator, Mapping
from functools import lru_cache
from importlib.resources import files
from pathlib import Path
from typing import Any

import yaml
from jsonschema import Draft202012Validator
from open_data_contract_standard.model import (
    CustomProperty,
    OpenDataContractStandard,
    SchemaObject,
    SchemaProperty,
)
from pydantic import BaseModel, ConfigDict, Field, model_validator

API_VERSION = "v3.2.0"


class DecimalType(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    precision: int = Field(ge=1, le=76)
    scale: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_scale(self) -> DecimalType:
        if self.scale > self.precision:
            raise ValueError("Decimal scale must not exceed precision")
        return self


class ContractDiagnostic(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    code: str
    source: str
    message: str


def custom_value(element: SchemaObject | SchemaProperty, vendor: str, name: str) -> Any:
    """Return a declared vendor property, preserving false, zero and explicit NULL."""
    matches = [
        item.value
        for item in element.customProperties or []
        if item.vendor == vendor and item.property == name
    ]
    if len(matches) > 1:
        raise ValueError(f"Duplicate custom property {vendor}.{name}")
    return matches[0] if matches else None


def decimal_type(prop: SchemaProperty) -> DecimalType | None:
    value = custom_value(prop, "ppsc", "decimal")
    declared = any(
        item.vendor == "ppsc" and item.property == "decimal"
        for item in prop.customProperties or []
    )
    return DecimalType.model_validate(value) if declared else None


def property_paths(
    obj: SchemaObject,
) -> Iterator[tuple[tuple[str, ...], SchemaProperty]]:
    """Yield named object properties; array/map contents stay in their type definition."""

    def walk(properties, prefix):
        for prop in properties or []:
            path = (*prefix, prop.name)
            yield path, prop
            yield from walk(prop.properties, path)

    yield from walk(obj.properties, ())


def internal_reference(reference: str) -> str | None:
    """Normalize a local reference; leave external resolution to the caller."""
    if "://" in reference or ("#" in reference and not reference.startswith("#/")):
        return None
    return reference.removeprefix("#/").lstrip("/")


def property_references(contract: OpenDataContractStandard) -> dict[str, str]:
    """Map internal name paths and ID pointers to qualified property names."""
    references = {}

    def walk(properties, prefix, pointer):
        for prop in properties or []:
            name = f"{prefix}.{prop.name}"
            references[name] = name
            target = f"{pointer}/properties/{prop.id}" if pointer and prop.id else None
            if target:
                references[target] = name
            walk(prop.properties, name, target)

    for obj in contract.schema_ or []:
        walk(obj.properties, obj.name, f"schema/{obj.id}" if obj.id else None)
    return references


@lru_cache(maxsize=1)
def _validator() -> Draft202012Validator:
    # Pin the released standard independently: the Python package's bundled
    # schema predates fixes in the v3.2.0 tag (including optional logicalType).
    schema = json.loads(
        files("ppsc_metadata")
        .joinpath("resources/odcs-v3.2.0.json")
        .read_text(encoding="utf-8")
    )
    Draft202012Validator.check_schema(schema)
    return Draft202012Validator(schema)


def _check_elements(contract: OpenDataContractStandard) -> None:
    object_names: set[str] = set()

    def check(element, label):
        keys = [(p.vendor, p.property) for p in element.customProperties or []]
        if len(set(keys)) != len(keys):
            raise ValueError(f"Duplicate custom property on {label}")

    def check_property(prop, label):
        check(prop, label)
        decimal = decimal_type(prop)
        if decimal is not None:
            if prop.logicalType != "number":
                raise ValueError(f"{label}: ppsc.decimal requires logicalType number")
            if (prop.logicalTypeOptions or {}).get("format") in {"f32", "f64"}:
                raise ValueError(f"{label}: decimal and float representations conflict")
        values = [json.dumps(v.value, sort_keys=True) for v in prop.enum or []]
        if len(values) != len(set(values)):
            raise ValueError(f"Duplicate enum value on {label}")
        for entry in prop.enum or []:
            value = entry.value
            kind = prop.logicalType
            valid = (
                kind is None
                or (value is None and prop.required is not True)
                or (
                    kind in {"string", "date", "timestamp", "time"}
                    and isinstance(value, str)
                )
                or (kind == "boolean" and type(value) is bool)
                or (kind == "integer" and type(value) is int)
                or (kind == "number" and type(value) in {int, float})
            )
            if not valid:
                raise ValueError(f"{label}: enum value {value!r} does not match {kind}")
        names = [child.name for child in prop.properties or []]
        if len(names) != len(set(names)):
            raise ValueError(f"Duplicate ODCS property on {label}")
        check_ids(prop.properties or [], label)
        for child in prop.properties or []:
            check_property(child, f"{label}.{child.name}")
        if prop.items is not None:
            check_property(prop.items, f"{label}.items")
        if prop.map is not None:
            check_property(prop.map.key, f"{label}.map.key")
            check_property(prop.map.value, f"{label}.map.value")

    def check_ids(elements, label):
        ids = [element.id for element in elements if element.id is not None]
        if len(ids) != len(set(ids)):
            raise ValueError(f"Duplicate ODCS element id on {label}")

    check_ids(contract.schema_ or [], "schema")
    for obj in contract.schema_ or []:
        if obj.name in object_names:
            raise ValueError(f"Duplicate ODCS object name: {obj.name}")
        object_names.add(obj.name)
        check(obj, obj.name)
        names = [prop.name for prop in obj.properties or []]
        if len(names) != len(set(names)):
            raise ValueError(f"Duplicate ODCS property on {obj.name}")
        check_ids(obj.properties or [], obj.name)
        for prop in obj.properties or []:
            check_property(prop, f"{obj.name}.{prop.name}")


def _check_relationships(contract: OpenDataContractStandard) -> None:
    targets = property_references(contract)
    relationships = []
    for obj in contract.schema_ or []:
        relationships.extend(obj.relationships or [])
        for _, prop in property_paths(obj):
            relationships.extend(prop.relationships or [])
    for relationship in relationships:
        values = relationship.model_dump(mode="json", by_alias=True, exclude_unset=True)
        if isinstance(values.get("from"), list) and len(values["from"]) != len(
            values["to"]
        ):
            raise ValueError("Composite ODCS relationship must have equal key lengths")
        for key in ("from", "to"):
            references = values.get(key, [])
            if isinstance(references, str):
                references = [references]
            for reference in references:
                normalized = internal_reference(reference)
                if normalized is None:
                    # External contract resolution belongs to orchestration; no I/O here.
                    continue
                if normalized not in targets:
                    raise ValueError(
                        f"Unresolved internal ODCS relationship: {reference}"
                    )


def validate_contract(
    document: Mapping[str, Any] | OpenDataContractStandard,
) -> OpenDataContractStandard:
    """Validate standard syntax, model preservation and the declared PPSC profile.

    Does not read files, query services, execute quality rules, or mutate the input.
    Engine compatibility is checked by the selected schema adapter.
    """
    data = (
        document.model_dump(mode="json", by_alias=True, exclude_unset=True)
        if isinstance(document, OpenDataContractStandard)
        else dict(document)
    )
    if data.get("apiVersion") != API_VERSION:
        raise ValueError(f"Expected ODCS apiVersion {API_VERSION}")
    errors = sorted(_validator().iter_errors(data), key=lambda e: str(e.json_path))
    if errors:
        details = "; ".join(f"{e.json_path}: {e.message}" for e in errors)
        raise ValueError(f"Invalid ODCS contract: {details}")
    contract = OpenDataContractStandard.model_validate(data)
    if contract.model_dump(mode="json", by_alias=True, exclude_unset=True) != data:
        raise ValueError("The pinned ODCS Python model cannot preserve this document")
    _check_elements(contract)
    _check_relationships(contract)
    return contract


class _ContractLoader(yaml.SafeLoader):
    """Reject repeated authored keys rather than silently accepting the last one."""


def _mapping(loader, node):
    pairs = loader.construct_pairs(node, deep=True)
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate YAML key: {key!r}")
        result[key] = value
    return result


_ContractLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _mapping
)


def parse_contract(text: str) -> OpenDataContractStandard:
    """Parse verified YAML bytes without reading a file a second time."""
    document = yaml.load(text, Loader=_ContractLoader)
    if not isinstance(document, Mapping):
        raise ValueError("An ODCS contract must be a mapping")
    return validate_contract(document)


def load_contract(path: Path) -> OpenDataContractStandard:
    return parse_contract(path.read_text(encoding="utf-8"))


def contract_yaml(contract: OpenDataContractStandard) -> str:
    """Produce deterministic YAML without writing over an authored file."""
    validated = validate_contract(contract)
    return yaml.safe_dump(
        validated.model_dump(mode="json", by_alias=True, exclude_unset=True),
        sort_keys=True,
        allow_unicode=True,
    )


def vendor_property(vendor: str, name: str, value: Any) -> dict[str, Any]:
    """Construct a standard custom property; this is not another schema model."""
    return CustomProperty(vendor=vendor, property=name, value=value).model_dump(
        mode="json", exclude_unset=True
    )
