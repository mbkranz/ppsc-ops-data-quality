"""Native Ibis projection composition, independent of a source system or runner."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import ibis
import ibis.expr.types as ir
from pydantic import BaseModel, ConfigDict, Field


class ProjectionEvidence(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    target_field: str
    source_entities: tuple[str, ...]
    source_paths: tuple[str, ...]
    description: str
    branches: tuple[dict[str, Any], ...] = ()
    dependencies: tuple[str, ...] = ()


class ProjectionResult(BaseModel):
    model_config = ConfigDict(extra="forbid", arbitrary_types_allowed=True)

    expressions: dict[str, ir.Value]
    deterministic: dict[str, ir.BooleanValue]
    lineage: dict[str, ProjectionEvidence] = Field(default_factory=dict)


def conditional_values(
    before: Mapping[str, ir.Value],
    assignments: Sequence[tuple[ir.BooleanValue, Mapping[str, ir.Value]]],
) -> dict[str, ir.Value]:
    """Compose ordered native CASE values; a selected NULL is an assignment."""
    result = {}
    for field, previous in before.items():
        branches = [
            (guard, values[field]) for guard, values in assignments if field in values
        ]
        result[field] = (
            ibis.cases(*branches, else_=previous) if branches else previous
        ).name(field)
    return result
