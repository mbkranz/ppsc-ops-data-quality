"""Bootstrap an observed ODCS draft from native Salesforce object/particle tables."""

from __future__ import annotations

import math
import re
from collections.abc import Mapping
from datetime import date, datetime
from typing import Any
from uuid import NAMESPACE_URL, uuid5

import pandas as pd
from open_data_contract_standard.model import OpenDataContractStandard
from pydantic import BaseModel, ConfigDict, Field

from ..contracts import (
    API_VERSION,
    ContractDiagnostic,
    DecimalType,
    validate_contract,
    vendor_property,
)

TYPE_NAMES = {
    "boolean": "boolean",
    "checkbox": "boolean",
    "string": "string",
    "text": "string",
    "reference": "string",
    "lookup": "string",
    "master-detail": "string",
    "datetime": "timestamp",
    "date/time": "timestamp",
    "picklist": "string",
    "id": "string",
    "textarea": "string",
    "long text area": "string",
    "text area": "string",
    "integer": "integer",
    "int": "integer",
    "long": "integer",
    "double": "number",
    "number": "number",
    "date": "date",
    "url": "string",
    "currency": "number",
    "percent": "number",
    "complexvalue": "object",
    "phone": "string",
    "multipicklist": "string",
    "picklist (multi-select)": "string",
    "email": "string",
    "address": "object",
    "json": "object",
    "time": "time",
    "base64": "string",
    "combobox": "string",
    "encryptedstring": "string",
    "location": "object",
}


class SalesforceContractRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    contract_id: str = Field(min_length=1)
    name: str = Field(min_length=1)
    org: str = Field(min_length=1)
    version: str = "0.1.0"


class SalesforceContractResult(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    contract: OpenDataContractStandard
    diagnostics: list[ContractDiagnostic]


def _clean(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_clean(v) for v in value]
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if value is None or value is pd.NA or value is pd.NaT:
        return None
    if hasattr(value, "tolist"):
        return _clean(value.tolist())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _first(row, *names):
    return next((row[name] for name in names if row.get(name) is not None), None)


def _field(row, name):
    return _first(row, "EntityParticle." + name, name, "FieldDefinition." + name)


def _integer(value, name):
    result = int(value)
    if isinstance(value, bool) or result != value:
        raise ValueError(f"{name} must be an exact integer, got {value!r}")
    return result


def _stable_id(request, name):
    return str(uuid5(NAMESPACE_URL, request.contract_id + "/" + name))


def _choices(value_set, global_value_sets):
    if not isinstance(value_set, dict):
        return None
    definition = value_set.get("valueSetDefinition")
    if isinstance(definition, dict):
        values = definition.get("value")
    else:
        values = (global_value_sets.get(value_set.get("valueSetName")) or {}).get(
            "customValue"
        )
    if values is None:
        return None
    entries = []
    for item in values:
        value = _first(item, "valueName", "fullName", "value")
        if value is not None:
            entries.append({
                "value": value,
                **({"label": item["label"]} if item.get("label") is not None else {}),
            })
    return entries or None


def build_salesforce_contract(
    request: SalesforceContractRequest,
    *,
    objects: pd.DataFrame,
    fields: pd.DataFrame,
    global_value_sets: Mapping[str, Any] | None = None,
) -> SalesforceContractResult:
    """Build an observed draft without reading files, fetching metadata or writing.

    Accept native export columns, including the explicit EntityParticle prefix
    used by the Salesforce view boundary. Unknown facts stay unknown. This draft
    is evidence for authoring and drift review, never an automatic contract edit.
    """
    diagnostics = []

    def issue(code, source, message):
        diagnostics.append(
            ContractDiagnostic(code=code, source=source, message=message)
        )

    object_rows = {}
    for row in objects.to_dict("records"):
        row = _clean(row)
        name = _first(row, "EntityDefinition.QualifiedApiName", "QualifiedApiName")
        if not isinstance(name, str) or not name:
            raise ValueError("Object export requires QualifiedApiName")
        if name in object_rows:
            raise ValueError(f"Repeated object: {name}")
        object_rows[name] = row
    property_rows = {}
    for position, raw in enumerate(fields.to_dict("records")):
        row = _clean(raw)
        obj = row.get("EntityDefinition.QualifiedApiName")
        parent = row.get("FieldDefinition.QualifiedApiName")
        name = _field(row, "QualifiedApiName")
        if not all(isinstance(v, str) and v for v in (obj, parent, name)):
            raise ValueError(
                "Field export requires entity, definition and particle API names"
            )
        component = _field(row, "IsComponent") is True or name != parent
        full_name = f"{obj}.{parent}.{name}" if component else f"{obj}.{name}"
        if full_name in property_rows:
            raise ValueError(f"Repeated field: {full_name}")
        source = {
            "objectName": obj,
            "fieldName": name,
            "fullName": full_name,
            "parentFieldName": parent if component else None,
            "sourcePath": f"fields.parquet#/rows/{position}",
        }
        for key in (
            "DataType",
            "Description",
            "InlineHelpText",
            "DurableId",
            "RelationshipName",
            "IsPermissionable",
            "IsUpdatable",
            "IsCreatable",
            "IsApiGroupable",
            "IsApiFilterable",
            "IsApiSortable",
            "LastModifiedDate",
            "LastModifiedById",
            "IsNillable",
            "IsUnique",
            "Length",
            "Precision",
            "Scale",
        ):
            source[key] = _field(row, key)
        source["sourceApis"] = [
            "tooling/EntityDefinition",
            "tooling/FieldDefinition",
            "tooling/EntityParticle",
        ]
        if any(
            value is not None
            for key, value in row.items()
            if key.startswith("FieldDefinition.Metadata.")
        ):
            source["sourceApis"].append("tooling/FieldDefinition.Metadata")
        source["DataType"] = _first(
            row, "FieldDefinition.DataType", "EntityParticle.DataType", "DataType"
        )
        for key in ("description", "formula", "defaultValue", "defaultValueFormula"):
            source[key] = row.get("FieldDefinition.Metadata." + key)
        if source["Description"] is None:
            source["Description"] = source["description"]
        if source["InlineHelpText"] is None:
            source["InlineHelpText"] = row.get(
                "FieldDefinition.Metadata.inlineHelpText"
            )
        source["LastModifiedByName"] = row.get("FieldDefinition.LastModifiedBy.Name")
        targets = _field(row, "ReferenceTo") or {}
        source["referenceTargets"] = targets.get("referenceTo") or []
        value_set = row.get("FieldDefinition.Metadata.valueSet")
        choices = _choices(value_set, global_value_sets or {})
        source["choices"] = choices
        native = _field(row, "DataType")
        native_name = str(native or "").split("(")[0].strip().lower()
        kind = TYPE_NAMES.get(native_name)
        prop = {"id": _stable_id(request, full_name), "name": name}
        label = _field(row, "Label")
        if label is not None:
            prop["businessName"] = label
        if kind:
            prop["logicalType"] = kind
        else:
            issue("unknown_type", full_name, f"Unmapped Salesforce type {native!r}")
        nillable, unique = _field(row, "IsNillable"), _field(row, "IsUnique")
        if isinstance(nillable, bool):
            prop["required"] = not nillable
        if isinstance(unique, bool):
            prop["unique"] = unique
        options = {}
        if kind == "string":
            length = _field(row, "Length")
            if length is not None:
                options["maxLength"] = _integer(length, "String length")
            if native_name in {"email", "url", "phone"}:
                options["format"] = {"url": "uri"}.get(native_name, native_name)
        if options:
            prop["logicalTypeOptions"] = options
        custom = [vendor_property("salesforce", "source", source)]
        if kind == "number":
            precision = _first(
                row,
                "EntityParticle.Precision",
                "EntityParticle.Digits",
                "FieldDefinition.Precision",
                "Precision",
                "Digits",
            )
            scale = _field(row, "Scale")
            parsed = re.search(r"\((\d+)\s*,\s*(\d+)\)", str(source["DataType"]))
            if precision is None and parsed:
                precision, scale = map(int, parsed.groups())
            if precision is not None:
                precision = _integer(precision, "Decimal precision")
            if precision not in (None, 0) and scale is not None:
                decimal = DecimalType(
                    precision=precision, scale=_integer(scale, "Decimal scale")
                )
                custom.append(vendor_property("ppsc", "decimal", decimal.model_dump()))
            else:
                issue(
                    "unknown_number_representation",
                    full_name,
                    "Decimal precision/scale are unavailable; engine adapters must require an explicit representation",
                )
        if (
            choices
            and isinstance(value_set, dict)
            and value_set.get("restricted") is True
            and native_name not in {"multipicklist", "picklist (multi-select)"}
        ):
            prop["enum"] = choices
        elif isinstance(value_set, dict) and choices is None:
            issue(
                "unavailable_choices",
                full_name,
                "Picklist metadata or referenced global value set is unavailable",
            )
        prop["customProperties"] = custom
        property_rows[full_name] = (obj, parent, component, prop)

    by_object = {}
    for key, value in property_rows.items():
        by_object.setdefault(value[0], {})[key] = value
    schema = []
    for obj in sorted(
        set(object_rows) | {value[0] for value in property_rows.values()}
    ):
        row = object_rows.get(obj, {})
        item = {
            "id": _stable_id(request, obj),
            "name": obj,
            "logicalType": "object",
            "properties": [],
        }
        label = _first(row, "EntityDefinition.Label", "Label")
        if label is not None:
            item["businessName"] = label
        item["customProperties"] = [vendor_property("salesforce", "source", row)]
        members = by_object.get(obj, {})
        for key, (_, parent, component, prop) in sorted(members.items()):
            parent_prop = members.get(f"{obj}.{parent}")
            if (
                component
                and parent_prop
                and parent_prop[3].get("logicalType") == "object"
            ):
                parent_prop[3].setdefault("properties", []).append(prop)
            else:
                item["properties"].append(prop)
        schema.append(item)
    known = {obj["name"]: obj for obj in schema}
    for full_name, (obj, _, _, prop) in property_rows.items():
        source = prop["customProperties"][0]["value"]
        targets = source["referenceTargets"]
        if len(targets) == 1:
            target = targets[0]
            target_field = property_rows.get(f"{target}.Id")
            if target in known and target_field:
                prop["relationships"] = [
                    {
                        "type": "foreignKey",
                        "to": f"schema/{known[target]['id']}/properties/{target_field[3]['id']}",
                    }
                ]
            else:
                issue(
                    "unresolved_relationship",
                    full_name,
                    "Reference target Id is absent from the saved catalog; native targets are retained",
                )
        elif targets:
            issue(
                "polymorphic_relationship",
                full_name,
                "Several native reference targets require a consumer binding; no foreign key was invented",
            )
    document = {
        "apiVersion": API_VERSION,
        "kind": "DataContract",
        "id": request.contract_id,
        "name": request.name,
        "version": request.version,
        "status": "draft",
        "schema": schema,
        "customProperties": [vendor_property("salesforce", "org", request.org)],
    }
    return SalesforceContractResult(
        contract=validate_contract(document), diagnostics=diagnostics
    )
