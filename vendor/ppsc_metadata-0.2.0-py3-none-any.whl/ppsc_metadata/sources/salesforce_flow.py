"""Compile a supported native Salesforce Flow slice into composable Ibis values.

Native metadata is evidence, not a second authored query language. The caller
binds relationships, BEFORE/lookup state, eligibility and the org-local DATE.
Only the requested control/dependency closure is interpreted. Loops, side-effect
actions and sequential writes within that closure fail explicitly.
"""

from __future__ import annotations

import operator
import re
from collections import defaultdict
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from functools import reduce
from typing import Any

import ibis
import ibis.expr.operations as ops
import ibis.expr.types as ir
from pydantic import BaseModel, ConfigDict, Field, model_validator
from sqlglot import exp, parse

from ..projections import ProjectionEvidence, ProjectionResult, conditional_values


class UnsupportedFlowError(ValueError):
    """Requested native semantics cannot be represented faithfully."""


class FlowRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    object_name: str = Field(min_length=1)
    fields: tuple[str, ...] = Field(min_length=1)
    before_prefix: str = Field(min_length=1)
    target_reference: str = Field(min_length=1)
    path_type: str = "AsyncAfterCommit"
    resource_aliases: dict[str, str] = Field(default_factory=dict)
    formula_aliases: dict[str, str] = Field(default_factory=dict)

    @model_validator(mode="after")
    def unique_fields(self):
        if len(set(self.fields)) != len(self.fields):
            raise ValueError("Select each output field once")
        aliases = [*self.resource_aliases.values(), *self.formula_aliases.values()]
        if len(set(aliases)) != len(aliases):
            raise ValueError("Resource aliases must be unique")
        return self


@dataclass(frozen=True)
class _Paths:
    # Native decision occurrences (name, selected rule index; None = default).
    updates: list[tuple[str, tuple[tuple[str, int | None], ...]]]
    lookups: dict[str, list[tuple[tuple[str, int | None], ...]]]
    elements: dict[str, tuple[str, int, dict]]


def _paths(metadata: Mapping[str, Any], request: FlowRequest) -> _Paths:
    elements = {}
    for kind, collection in metadata.items():
        if kind in {"formulas", "variables", "constants", "choices"} or not isinstance(
            collection, list
        ):
            continue
        for index, node in enumerate(collection):
            if not isinstance(node, dict) or not node.get("name"):
                continue
            if node["name"] in elements:
                raise UnsupportedFlowError(f"Repeated Flow element {node['name']}")
            elements[node["name"]] = (kind, index, node)
    start = metadata.get("start") or {}
    entries = [
        path
        for path in start.get("scheduledPaths") or []
        if path.get("pathType") == request.path_type
    ]
    if len(entries) != 1:
        raise UnsupportedFlowError(f"Expected one {request.path_type} entry path")
    root = (entries[0].get("connector") or {}).get("targetReference")
    parents = defaultdict(set)
    targets = set()
    for name, (kind, _, node) in elements.items():
        connectors = [
            node.get("connector"),
            node.get("defaultConnector"),
            node.get("faultConnector"),
        ]
        connectors.extend(rule.get("connector") for rule in node.get("rules") or [])
        for connector in connectors:
            if connector and connector.get("targetReference"):
                parents[connector["targetReference"]].add(name)
        if kind == "recordUpdates" and node.get("object") == request.object_name:
            if any(
                a.get("field") in request.fields
                for a in node.get("inputAssignments") or []
            ):
                targets.add(name)
    closure = set(targets)
    pending = list(targets)
    while pending:
        for parent in parents[pending.pop()]:
            if parent not in closure:
                closure.add(parent)
                pending.append(parent)
    updates, lookups = [], {}

    def walk(name, path, stack):
        if name not in closure:
            return
        if name in stack or name not in elements:
            raise UnsupportedFlowError(f"Cyclic or unresolved Flow connector {name}")
        kind, _, node = elements[name]
        if node.get("faultConnector"):
            raise UnsupportedFlowError(f"Fault handling in requested closure: {name}")
        if kind == "decisions":
            for index, rule in enumerate(node.get("rules") or []):
                walk(
                    (rule.get("connector") or {}).get("targetReference"),
                    (*path, (name, index)),
                    (*stack, name),
                )
            walk(
                (node.get("defaultConnector") or {}).get("targetReference"),
                (*path, (name, None)),
                (*stack, name),
            )
        elif kind == "recordLookups":
            lookups.setdefault(name, []).append(path)
            walk(
                (node.get("connector") or {}).get("targetReference"),
                path,
                (*stack, name),
            )
        elif kind == "recordUpdates":
            if node.get("connector"):
                raise UnsupportedFlowError(
                    f"Sequential writes require an explicit state model: {name}"
                )
            updates.append((name, path))
        else:
            raise UnsupportedFlowError(
                f"Unsupported requested Flow element {kind}/{name}"
            )

    walk(root, (), ())
    assigned = {
        a.get("field")
        for name, _ in updates
        for a in elements[name][2].get("inputAssignments") or []
    }
    missing = set(request.fields) - assigned
    if missing:
        raise UnsupportedFlowError(
            f"No reachable assignment for requested fields: {sorted(missing)}"
        )
    return _Paths(updates, lookups, elements)


def _column(request: FlowRequest, reference: str) -> str:
    if reference.startswith("$Record."):
        return reference.removeprefix("$Record.")
    resource, separator, field = reference.partition(".")
    if separator:
        return f"{request.resource_aliases.get(resource, resource)}.{field}"
    return request.formula_aliases.get(reference, reference)


def _value(value: Mapping[str, Any], reference) -> ir.Value:
    active = [(key, item) for key, item in value.items() if item is not None]
    if not active:
        return ibis.null()
    if len(active) != 1:
        raise UnsupportedFlowError(f"Ambiguous native Flow value {value}")
    key, item = active[0]
    if key == "elementReference":
        return reference(item)
    if key in {"stringValue", "booleanValue", "numberValue"}:
        return ibis.literal(item)
    if key in {"dateValue", "dateTimeValue", "timeValue"}:
        return ibis.literal(item).cast(
            {"dateValue": "date", "dateTimeValue": "timestamp", "timeValue": "time"}[
                key
            ]
        )
    raise UnsupportedFlowError(f"Unsupported Flow value {key}")


def _condition(item, reference, *, field=None):
    if (
        item.get("conditions")
        or item.get("aggregationOperator")
        or item.get("aggregationField")
    ):
        raise UnsupportedFlowError(
            "Nested or aggregate native conditions need an adapter"
        )
    left = reference(item["leftValueReference"]) if field is None else field
    right_value = item.get("rightValue") if field is None else item.get("value")
    if right_value is None:
        raise UnsupportedFlowError("A native condition requires an explicit value")
    right = _value(right_value, reference)
    operation = item.get("operator")
    if operation == "IsNull":
        value = right_value.get("booleanValue")
        if type(value) is not bool:
            raise UnsupportedFlowError("IsNull requires a Boolean operand")
        return left.isnull() if value else left.notnull()
    operations = {
        "EqualTo": operator.eq,
        "NotEqualTo": operator.ne,
        "GreaterThan": operator.gt,
        "GreaterThanOrEqualTo": operator.ge,
        "LessThan": operator.lt,
        "LessThanOrEqualTo": operator.le,
    }
    if operation not in operations:
        raise UnsupportedFlowError(f"Unsupported native comparison {operation}")
    if right.type().is_null():
        if operation not in {"EqualTo", "NotEqualTo"}:
            raise UnsupportedFlowError("NULL ordering is unsupported")
        return left.isnull() if operation == "EqualTo" else left.notnull()
    return operations[operation](left, right).fill_null(False)


def _logic(logic: str | None, conditions: list[ir.BooleanValue]) -> ir.BooleanValue:
    if not conditions:
        return ibis.literal(True)
    if (logic or "and").lower() in {"and", "or"}:
        return reduce(
            operator.and_ if (logic or "and").lower() == "and" else operator.or_,
            conditions,
        )
    expression = _native_expression(logic)

    def visit(node):
        if isinstance(node, exp.Paren):
            return visit(node.this)
        if isinstance(node, exp.And):
            return visit(node.this) & visit(node.expression)
        if isinstance(node, exp.Or):
            return visit(node.this) | visit(node.expression)
        if isinstance(node, exp.Not):
            return ~visit(node.this)
        if (
            isinstance(node, exp.Literal)
            and node.is_int
            and 1 <= int(node.this) <= len(conditions)
        ):
            return conditions[int(node.this) - 1]
        raise UnsupportedFlowError(f"Unsupported native conditionLogic {logic!r}")

    return visit(expression)


def _reference(record, request, name):
    column = _column(request, name)
    if column not in record.columns:
        raise UnsupportedFlowError(f"Unbound native reference {name}")
    return record[column]


def _guard(record, request, paths, metadata, eligibility):
    result = eligibility(record).fill_null(False)
    for name, selected in paths:
        rules = metadata[name][2].get("rules") or []
        previous = ibis.literal(False)
        for index, rule in enumerate(rules):
            if rule.get("doesRequireRecordChangedToMeetCriteria"):
                raise UnsupportedFlowError(
                    "Changed-to-meet decision rules require event BEFORE inputs"
                )
            test = _logic(
                rule.get("conditionLogic"),
                [
                    _condition(c, lambda ref: _reference(record, request, ref))
                    for c in rule.get("conditions") or []
                ],
            )
            if selected == index:
                result = result & ~previous & test
                break
            previous = previous | test
        if selected is None:
            result = result & ~previous
    return result


def _known_reference(record, request, reference, *, existence=False):
    column = _column(request, reference)
    resource, _, field = reference.partition(".")
    key = (
        "__exists_known." + request.resource_aliases.get(resource, resource)
        if existence and field == "Id" and not reference.startswith("$Record.")
        else "__known." + column
    )
    return record[key] if key in record.columns else ibis.literal(True)


def _true(value):
    return isinstance(value.op(), ops.Literal) and value.op().value is True


def _all_known(values):
    return reduce(
        operator.and_,
        (value for value in values if not _true(value)),
        ibis.literal(True),
    )


def _guard_known(record, request, path, elements):
    known = []
    for name, selected in path:
        rules = elements[name][2].get("rules") or []
        for rule in rules if selected is None else rules[: selected + 1]:
            for condition in rule.get("conditions") or []:
                known.append(
                    _known_reference(
                        record,
                        request,
                        condition["leftValueReference"],
                        existence=condition.get("operator") == "IsNull",
                    )
                )
                for reference in _references(condition.get("rightValue") or {}):
                    known.append(_known_reference(record, request, reference))
    return _all_known(known)


def _native_expression(text):
    expressions = parse(text)
    if len(expressions) != 1 or expressions[0] is None:
        raise UnsupportedFlowError(
            "Native expressions must contain exactly one expression"
        )
    return expressions[0]


def _formula(expression, reference, today):
    rewritten = re.sub(
        r"\{!([^}]+)\}",
        lambda match: '"' + match[1].replace('"', '""') + '"',
        expression,
    )
    tree = _native_expression(rewritten)

    def visit(node):
        if isinstance(node, exp.Paren):
            return visit(node.this)
        if isinstance(node, (exp.Column, exp.Identifier)):
            return reference(node.name)
        if isinstance(node, exp.Literal) and node.is_number:
            return ibis.literal(
                float(node.this) if "." in node.this else int(node.this)
            )
        if (
            isinstance(node, exp.Anonymous)
            and node.name.upper() == "TODAY"
            and not node.expressions
        ):
            return today
        if isinstance(node, exp.Floor):
            return visit(node.this).floor()
        if isinstance(node, (exp.Add, exp.Sub, exp.Mul, exp.Div)):
            left, right = visit(node.this), visit(node.expression)
            if (
                isinstance(node, exp.Sub)
                and left.type().is_date()
                and right.type().is_date()
            ):
                return left.delta(right, unit="day")
            return {
                exp.Add: operator.add,
                exp.Sub: operator.sub,
                exp.Mul: operator.mul,
                exp.Div: operator.truediv,
            }[type(node)](left, right)
        raise UnsupportedFlowError(
            f"Unsupported native formula node {type(node).__name__}"
        )

    return visit(tree)


def _references(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in {"elementReference", "leftValueReference"} and isinstance(
                item, str
            ):
                yield item
            else:
                yield from _references(item)
    elif isinstance(value, list):
        for item in value:
            yield from _references(item)


def _selected_assignments(paths, request):
    return [
        assignment
        for name, _ in paths.updates
        for assignment in paths.elements[name][2].get("inputAssignments") or []
        if assignment.get("field") in request.fields
    ]


def _lookup_fields(paths, request):
    needed = defaultdict(set)
    used = _selected_assignments(paths, request)
    used.extend(paths.elements[name][2] for name in paths.lookups)
    used.extend(
        paths.elements[name][2] for _, path in paths.updates for name, _ in path
    )
    for ref in _references(used):
        resource, separator, field = ref.partition(".")
        if separator and resource in paths.lookups:
            needed[resource].add(field)
    return needed


def flow_context(
    record: ir.Table,
    sources: Mapping[str, ir.Table],
    metadata: Mapping[str, Any],
    request: FlowRequest,
    *,
    flow_run_date: ir.DateValue,
    eligibility: Callable[[ir.Table], ir.BooleanValue],
) -> ir.Table:
    """Bind native lookups/formulas without executing or changing event grain.

    Eligibility is a caller-supplied function of the current relation, so its
    references remain valid as joins add resources. Native first-row ambiguity is
    retained through per-value determinism columns, never a fabricated sort.
    """
    paths = _paths(metadata, request)
    needed = _lookup_fields(paths, request)
    reserved = "__ppsc_flow_row"
    if reserved in record.columns:
        raise ValueError(f"Reserved compiler column: {reserved}")
    record = record.mutate(**{reserved: ibis.row_number().over(ibis.window())})
    for name, incoming in paths.lookups.items():
        _, _, lookup = paths.elements[name]
        if (
            lookup.get("getFirstRecordOnly") is not True
            or lookup.get("storeOutputAutomatically") is not True
        ):
            raise UnsupportedFlowError(
                f"Only automatic first-record lookups are supported: {name}"
            )
        if lookup.get("outputAssignments"):
            raise UnsupportedFlowError(f"Explicit lookup output assignments: {name}")
        if lookup.get("object") not in sources:
            raise UnsupportedFlowError(f"Unbound lookup object {lookup.get('object')}")
        candidate = sources[lookup["object"]].alias(name)
        marker = "__ppsc_match"
        if marker in candidate.columns:
            raise ValueError(f"Reserved compiler column: {marker}")
        fields = sorted(
            needed[name]
            | {"Id"}
            | ({lookup["sortField"]} if lookup.get("sortField") else set())
        )
        if any(field not in candidate.columns for field in fields):
            raise UnsupportedFlowError(f"Unbound selected lookup field in {name}")
        if any(
            item.get("field") not in candidate.columns
            for item in lookup.get("filters") or []
        ):
            raise UnsupportedFlowError(f"Unbound lookup filter field in {name}")
        guard = reduce(
            operator.or_,
            [
                _guard(record, request, path, paths.elements, eligibility)
                for path in incoming
            ],
        )
        dependency_known = _all_known(
            [_guard_known(record, request, path, paths.elements) for path in incoming]
            + [
                _known_reference(record, request, ref)
                for ref in _references(lookup.get("filters") or [])
            ]
        )
        candidate = candidate.mutate(**{marker: ibis.literal(1)})
        # Rebind filters after adding the marker: Ibis relation identity matters.
        predicate = _logic(
            lookup.get("filterLogic"),
            [
                _condition(
                    c,
                    lambda ref: _reference(record, request, ref),
                    field=candidate[c["field"]],
                )
                for c in lookup.get("filters") or []
            ],
        )
        alias = request.resource_aliases.get(name, name)
        joined = record.left_join(candidate, [predicate, guard]).select(
            record,
            **{f"{alias}.{field}": candidate[field] for field in fields},
            **{marker: candidate[marker]},
            __ppsc_lookup_known=dependency_known,
        )
        window = ibis.window(group_by=joined[reserved])
        count = joined[marker].sum().over(window).fill_null(0)
        sort = lookup.get("sortField")
        if sort:
            order = lookup.get("sortOrder")
            if order not in {"Asc", "Desc"}:
                raise UnsupportedFlowError(
                    f"Unsupported lookup ordering {name}: {order}"
                )
            value = joined[f"{alias}.{sort}"]
            ordered = (
                value.asc(nulls_first=True)
                if order == "Asc"
                else value.desc(nulls_first=False)
            )
            ranking = ibis.window(group_by=joined[reserved], order_by=ordered)
            ties = (
                joined[marker]
                .sum()
                .over(ibis.window(group_by=[joined[reserved], value]))
                .fill_null(0)
            )
        else:
            ranking, ties = window, count
        additions = {
            f"{alias}.match_count": count,
            "__ppsc_rank": ibis.row_number().over(ranking),
        }
        if not _true(dependency_known):
            additions[f"__exists_known.{alias}"] = joined.__ppsc_lookup_known
        for field in fields:
            known = _all_known([
                ibis.literal(True)
                if _true(dependency_known)
                else joined.__ppsc_lookup_known,
                ibis.literal(True) if field == sort else ties <= 1,
            ])
            if not _true(known):
                additions[f"__known.{alias}.{field}"] = known
            # Id is retained as existence evidence; other ambiguous values stay NULL.
            if field != "Id" and not _true(known):
                additions[f"{alias}.{field}"] = known.ifelse(
                    joined[f"{alias}.{field}"],
                    ibis.null().cast(joined[f"{alias}.{field}"].type()),
                )
        ranked = joined.mutate(**additions)
        record = ranked.filter(ranked["__ppsc_rank"] == 0).drop(
            marker, "__ppsc_rank", "__ppsc_lookup_known"
        )
    formulas = {formula["name"]: formula for formula in metadata.get("formulas") or []}
    references = set(_references(_selected_assignments(paths, request)))
    pending = [ref for ref in references if ref in formulas]
    completed = set()

    def add_formula(name, stack):
        nonlocal record
        if name in completed:
            return
        if name in stack:
            raise UnsupportedFlowError(f"Cyclic formula {name}")
        formula = formulas[name]
        for ref in re.findall(r"\{!([^}]+)\}", formula["expression"]):
            if ref in formulas:
                add_formula(ref, (*stack, name))
        value = _formula(
            formula["expression"],
            lambda ref: _reference(record, request, ref),
            flow_run_date,
        )
        column = _column(request, name)
        known = _all_known([
            _known_reference(record, request, reference)
            for reference in re.findall(r"\{!([^}]+)\}", formula["expression"])
        ])
        additions = {column: value}
        if not _true(known):
            additions["__known." + column] = known
        record = record.mutate(**additions)
        completed.add(name)

    for name in pending:
        add_formula(name, ())
    return record.drop(reserved).alias("Flow_Context")


def flow_lineage(
    metadata: Mapping[str, Any], request: FlowRequest
) -> dict[str, ProjectionEvidence]:
    paths = _paths(metadata, request)
    evidence = {}
    for field in request.fields:
        entities, locations, branches, dependencies = [], [], [], []
        for name, path in paths.updates:
            _, index, node = paths.elements[name]
            for assignment_index, assignment in enumerate(
                node.get("inputAssignments") or []
            ):
                if assignment.get("field") != field:
                    continue
                entities.append("FlowRecordUpdate." + name)
                pointer = f"/Metadata/recordUpdates/{index}/inputAssignments/{assignment_index}"
                locations.append(pointer)
                dependencies.extend(_references(assignment))
                for decision, _ in path:
                    _, decision_index, decision_node = paths.elements[decision]
                    locations.append(f"/Metadata/decisions/{decision_index}")
                    dependencies.extend(_references(decision_node))
                branches.append({
                    "rule_id": f"{name}/{field}",
                    "source_path": pointer,
                    "decision_path": [
                        {"element": decision, "rule": selected}
                        for decision, selected in path
                    ],
                })
        evidence[field] = ProjectionEvidence(
            target_field=f"{request.object_name}.{field}",
            source_entities=tuple(dict.fromkeys(entities)),
            source_paths=tuple(dict.fromkeys(locations)),
            description=f"Native Flow assignments to {request.object_name}.{field}; retain BEFORE when unassigned",
            branches=tuple(branches),
            dependencies=tuple(dict.fromkeys(dependencies)),
        )
    return evidence


def flow_assignments(
    record: ir.Table,
    metadata: Mapping[str, Any],
    request: FlowRequest,
    *,
    eligibility: Callable[[ir.Table], ir.BooleanValue],
) -> ProjectionResult:
    """Construct requested CASE expressions and independent determinism evidence."""
    paths = _paths(metadata, request)
    before = {field: record[request.before_prefix + field] for field in request.fields}
    assignments = []
    known_assignments = []
    route_known = {field: ibis.literal(True) for field in request.fields}
    for name, path in paths.updates:
        _, _, node = paths.elements[name]
        filters = node.get("filters") or []
        if (
            node.get("filterLogic", "and").lower() != "and"
            or len(filters) != 1
            or filters[0].get("field") != "Id"
            or filters[0].get("operator") != "EqualTo"
            or (filters[0].get("value") or {}).get("elementReference")
            != request.target_reference
        ):
            raise UnsupportedFlowError(
                f"Update does not bind the selected BEFORE target: {name}"
            )
        guard = _guard(record, request, path, paths.elements, eligibility)
        values, known = {}, {}
        for assignment in node.get("inputAssignments") or []:
            field = assignment.get("field")
            if field not in request.fields:
                continue
            if field in values:
                raise UnsupportedFlowError(f"Repeated assignment {name}.{field}")
            native = assignment.get("value")
            if native is None:
                raise UnsupportedFlowError(f"Missing assignment value {name}.{field}")
            values[field] = _value(
                native, lambda ref: _reference(record, request, ref)
            ).cast(before[field].type())
            reference = native.get("elementReference")
            column = "__known." + _column(request, reference) if reference else ""
            known[field] = (
                record[column] if column in record.columns else ibis.literal(True)
            )
            route_known[field] = _all_known([
                route_known[field],
                _guard_known(record, request, path, paths.elements),
            ])
        assignments.append((guard, values))
        known_assignments.append((guard, known))
    expressions = conditional_values(before, assignments)
    deterministic = conditional_values(
        {field: ibis.literal(True) for field in request.fields}, known_assignments
    )
    deterministic = {
        field: _all_known([known, route_known[field]]).fill_null(False)
        for field, known in deterministic.items()
    }
    return ProjectionResult(
        expressions={
            field: value
            if _true(route_known[field])
            else route_known[field]
            .ifelse(value, ibis.null().cast(value.type()))
            .name(field)
            for field, value in expressions.items()
        },
        deterministic=deterministic,
        lineage=flow_lineage(metadata, request),
    )
