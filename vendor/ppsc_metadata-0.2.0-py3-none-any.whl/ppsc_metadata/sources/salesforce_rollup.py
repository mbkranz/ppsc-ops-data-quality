"""A narrow native COUNT rollup adapter; no display SQL is executed."""

from __future__ import annotations

import operator
from collections.abc import Mapping
from functools import reduce
from typing import Any

import ibis
import ibis.expr.types as ir
from pydantic import BaseModel, ConfigDict, Field


class CountRollupRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    output_field: str = Field(min_length=1)
    child_object: str = Field(min_length=1)
    parent_key: str = "Id"


def count_rollup(
    parent: ir.Table,
    child: ir.Table,
    metadata: Mapping[str, Any],
    request: CountRollupRequest,
) -> ir.Table:
    """Return one count per input parent row, retaining duplicates and zero children.

    This adapter supports literal, conjunctive native filters only. The caller
    owns snapshots, deletion policy and the explicit parent-key binding.
    """
    if metadata.get("summaryOperation") != "count":
        raise ValueError("The native COUNT adapter requires summaryOperation=count")
    prefix = request.child_object + "."
    foreign_key = metadata.get("summaryForeignKey", "")
    if not foreign_key.startswith(prefix) or "." in foreign_key.removeprefix(prefix):
        raise ValueError("Bind a direct native child foreign key explicitly")
    key = foreign_key.removeprefix(prefix)
    child = child.alias("Rollup_Children")
    predicates = []
    operations = {
        "equals": operator.eq,
        "notEqual": operator.ne,
        "greaterThan": operator.gt,
        "greaterOrEqual": operator.ge,
        "lessThan": operator.lt,
        "lessOrEqual": operator.le,
    }
    for item in metadata.get("summaryFilterItems") or []:
        if (
            item.get("valueField")
            or item.get("valueSetName")
            or item.get("operation") not in operations
        ):
            raise ValueError("Unsupported native rollup filter")
        name = item.get("field", "")
        if not name.startswith(prefix):
            raise ValueError("Rollup filter must name a bound child field")
        value = item.get("value")
        if type(value) not in {str, int, float, bool}:
            raise ValueError("Rollup filter requires a scalar literal")
        predicates.append(
            operations[item["operation"]](
                child[name.removeprefix(prefix)], ibis.literal(value)
            ).fill_null(False)
        )
    marker, identity = "__ppsc_child_match", "__ppsc_parent_row"
    if (
        identity in parent.columns
        or marker in parent.columns
        or marker in child.columns
        or request.output_field in parent.columns
    ):
        raise ValueError("Rollup helper/output column collision")
    child = child.filter(reduce(operator.and_, predicates)) if predicates else child
    child = child.mutate(**{marker: ibis.literal(1)})
    parent = parent.mutate(**{identity: ibis.row_number().over(ibis.window())})
    joined = parent.left_join(child, parent[request.parent_key] == child[key]).select(
        parent, child[marker]
    )
    return (
        joined.group_by(*parent.columns)
        .aggregate(**{request.output_field: joined[marker].sum().fill_null(0)})
        .drop(identity)
    )
